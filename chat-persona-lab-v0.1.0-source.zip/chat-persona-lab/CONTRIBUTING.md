# Contributing

Use Python 3.11 or later. Core development requires no runtime dependencies.

```sh
python -m unittest discover -s tests -v
python scripts/check_public.py
```

Keep pull requests focused and explain the observable behavior, relevant tests,
and any privacy consequences. Use fictional data in tests, screenshots, issues,
and examples. Never attach chat exports, databases, `.env`, provider keys, or
desktop account details. Mock desktop adapters in CI; do not send real messages.

Changes to contact isolation, recipient binding, approval, send uncertainty,
provider selection, or redaction need regression tests. Preserve the rule that
uncertain sends are never automatically retried. Do not expand live messaging
capabilities without documenting the changed behavior and its test limits.

For release preparation, use `scripts/build_release.py` rather than compressing
your working directory. Read [the release guide](docs/RELEASING.md).
