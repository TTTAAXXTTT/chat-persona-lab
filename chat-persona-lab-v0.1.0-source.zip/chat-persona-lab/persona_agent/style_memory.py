from __future__ import annotations

import math
import re
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Iterable, Mapping


# Only neutral discourse markers may leave the local style compiler.  Arbitrary
# n-grams are intentionally forbidden: even a frequent phrase can contain a
# person's name, a private fact or language copied from another contact.
SAFE_PHRASE_CANDIDATES = (
    "哈哈哈",
    "哈哈",
    "okok",
    "好的",
    "好",
    "嗯嗯",
    "嗯",
    "可以",
    "行",
    "收到",
    "知道了",
    "没事",
    "没问题",
    "等一下",
    "稍等",
    "我看下",
    "我看看",
    "在的",
    "真的",
    "确实",
    "对",
    "是的",
)

_EMOJI_RE = re.compile(
    "["
    "\U0001F1E6-\U0001F1FF"
    "\U0001F300-\U0001FAFF"
    "\U00002600-\U000027BF"
    "]"
)
_SPACE_RE = re.compile(r"\s+")
_PHRASE_NEIGHBOR = r"A-Za-z0-9_\u4e00-\u9fff"
_SAFE_PHRASE_PATTERNS = {
    phrase: re.compile(
        rf"(?<![{_PHRASE_NEIGHBOR}]){re.escape(phrase)}(?![{_PHRASE_NEIGHBOR}])",
        re.IGNORECASE,
    )
    for phrase in SAFE_PHRASE_CANDIDATES
}


@dataclass(frozen=True, slots=True)
class SafePhraseUsage:
    phrase: str
    occurrence_count: int
    contact_count: int

    def to_payload(self) -> dict[str, int | str]:
        return {
            "phrase": self.phrase,
            "occurrence_count": self.occurrence_count,
            "contact_count": self.contact_count,
        }


@dataclass(frozen=True, slots=True)
class StyleFingerprint:
    """Anonymous aggregate derived only from the user's own messages.

    The object deliberately contains no contact key, source path, message sample
    or arbitrary extracted phrase.  It is therefore safe to share between local
    contact scopes as style guidance, while raw history remains isolated.
    """

    version: str
    source_contact_count: int
    self_message_count: int
    metrics: dict[str, int | float]
    safe_phrases: tuple[SafePhraseUsage, ...]

    def to_prompt_payload(self) -> dict[str, Any]:
        """Return the JSON-serializable, anonymous model-context representation."""

        return {
            "version": self.version,
            "source_contact_count": self.source_contact_count,
            "self_message_count": self.self_message_count,
            "metrics": dict(self.metrics),
            "safe_phrases": [item.to_payload() for item in self.safe_phrases],
            "usage_rule": (
                "仅用于模仿总体表达节奏，不代表任何当前事实、关系、意图或承诺"
            ),
        }


def _ratio(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 0.0


def _percentile(values: list[int], fraction: float) -> int:
    if not values:
        return 0
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, math.ceil(len(ordered) * fraction) - 1))
    return int(ordered[index])


def _normalized_content(value: object) -> str:
    return _SPACE_RE.sub(" ", str(value or "")).strip()


def build_style_fingerprint(
    rows: Iterable[Mapping[str, Any]],
    *,
    minimum_phrase_contacts: int = 2,
    max_safe_phrases: int = 12,
) -> StyleFingerprint:
    """Compile anonymous style statistics from ``Store.style_source_messages``.

    Expected input fields are ``contact_key``, ``relationship``, ``content`` and
    ``source_file``.  Only ``contact_key`` (for k-anonymity counting) and
    ``content`` (for aggregate measurements) are consulted.  Identifiers,
    relationships, paths and message samples are never copied to the result.

    A safe allow-listed phrase is emitted only when it occurs in at least
    ``minimum_phrase_contacts`` distinct contacts.  This prevents a phrase used
    in one relationship from becoming global memory.
    """

    if minimum_phrase_contacts < 2:
        raise ValueError("minimum_phrase_contacts 必须至少为 2")
    if max_safe_phrases < 0:
        raise ValueError("max_safe_phrases 不能为负数")

    messages: list[str] = []
    contacts: set[str] = set()
    phrase_occurrences: Counter[str] = Counter()
    phrase_contacts: dict[str, set[str]] = defaultdict(set)

    for row in rows:
        contact_key = str(row.get("contact_key") or "").strip()
        content = _normalized_content(row.get("content"))
        if not contact_key or not content:
            continue
        contacts.add(contact_key)
        messages.append(content)
        for phrase in SAFE_PHRASE_CANDIDATES:
            count = len(_SAFE_PHRASE_PATTERNS[phrase].findall(content))
            if count:
                phrase_occurrences[phrase] += count
                phrase_contacts[phrase].add(contact_key)

    lengths = [len(message) for message in messages]
    total = len(messages)
    metrics: dict[str, int | float] = {
        "median_message_chars": int(statistics.median(lengths)) if lengths else 0,
        "p90_message_chars": _percentile(lengths, 0.9),
        "average_message_chars": round(statistics.fmean(lengths), 2) if lengths else 0.0,
        "very_short_message_ratio": _ratio(sum(length <= 4 for length in lengths), total),
        "short_message_ratio": _ratio(sum(length <= 12 for length in lengths), total),
        "long_message_ratio": _ratio(sum(length > 80 for length in lengths), total),
        "ends_with_period_ratio": _ratio(
            sum(message.endswith(("。", ".")) for message in messages), total
        ),
        "contains_question_ratio": _ratio(
            sum("?" in message or "？" in message for message in messages), total
        ),
        "contains_exclamation_ratio": _ratio(
            sum("!" in message or "！" in message for message in messages), total
        ),
        "contains_ellipsis_ratio": _ratio(
            sum("……" in message or "..." in message or "。。。" in message for message in messages),
            total,
        ),
        "contains_laughter_ratio": _ratio(
            sum("哈哈" in message for message in messages), total
        ),
        "contains_emoji_ratio": _ratio(
            sum(bool(_EMOJI_RE.search(message)) for message in messages), total
        ),
    }

    safe_phrases = [
        SafePhraseUsage(
            phrase=phrase,
            occurrence_count=phrase_occurrences[phrase],
            contact_count=len(phrase_contacts[phrase]),
        )
        for phrase in SAFE_PHRASE_CANDIDATES
        if len(phrase_contacts[phrase]) >= minimum_phrase_contacts
    ]
    safe_phrases.sort(
        key=lambda item: (
            item.contact_count,
            item.occurrence_count,
            len(item.phrase),
            item.phrase,
        ),
        reverse=True,
    )

    return StyleFingerprint(
        version="style-fingerprint-v1",
        source_contact_count=len(contacts),
        self_message_count=total,
        metrics=metrics,
        safe_phrases=tuple(safe_phrases[:max_safe_phrases]),
    )
