from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
import hashlib
from typing import Any


def wechat_account_scope(nickname: str, account_id: str = "") -> str:
    """Return a non-reversible local namespace for one observed WeChat account.

    A stable account identifier is included when the adapter can verify one, so
    two accounts sharing a nickname cannot reuse each other's identity approvals.
    """

    normalized = nickname.strip()
    if not normalized:
        return ""
    normalized_id = account_id.strip()
    return "wechat-nickname-sha256:" + hashlib.sha256(
        f"{normalized}\x1f{normalized_id}".encode("utf-8")
    ).hexdigest()


@dataclass(slots=True)
class ProfileItem:
    sheet: str
    row: int
    cells: list[str]

    @property
    def text(self) -> str:
        return " | ".join(cell for cell in self.cells if cell)


@dataclass(slots=True)
class ChatMessage:
    timestamp: datetime
    sender_name: str
    sender_id: str
    content: str
    is_self: bool
    source_file: str
    source_index: int


@dataclass(slots=True)
class ParsedExport:
    conversation_name: str
    conversation_id: str
    self_account: str
    source_file: str
    messages: list[ChatMessage] = field(default_factory=list)


@dataclass(slots=True)
class ExamplePair:
    source_key: str
    contact_key: str
    timestamp: datetime
    incoming_messages: list[str]
    reply_messages: list[str]

    @property
    def incoming_text(self) -> str:
        return "\n".join(self.incoming_messages)


@dataclass(slots=True)
class IncomingMessage:
    external_id: str
    contact_name: str
    contact_key: str
    text: str
    timestamp: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AdapterEnvelope:
    """Untrusted event emitted by a multi-conversation desktop adapter.

    Unlike :class:`IncomingMessage`, an envelope deliberately has no
    ``contact_key``.  The service must validate the account, conversation type,
    sender role and stable adapter identity, then resolve an explicitly approved
    local identity binding before the event can enter the draft pipeline.
    """

    event_id: str
    account_scope: str
    adapter_kind: str
    external_identity: str
    identity_quality: str
    adapter_alias: str
    chat_type: str
    sender_role: str
    message_type: str
    text: str
    timestamp: datetime
    releasable: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class RiskDecision:
    level: str
    action: str
    reasons: list[str]


@dataclass(slots=True)
class ModelDraft:
    messages: list[str]
    confidence: float
    needs_user_input: bool
    uncertainties: list[str]
    raw: dict[str, Any] = field(default_factory=dict)
    # The client snapshots the selected model at generation start. This field
    # lets downstream storage record that actual model even if the UI switches
    # the selection while the request is in flight.
    used_model: str | None = None
