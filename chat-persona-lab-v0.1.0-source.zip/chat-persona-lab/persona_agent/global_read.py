from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import os
import threading
import time
import uuid
from collections import Counter, deque
from datetime import datetime
from pathlib import Path
from typing import Callable

from .adapters import IncomingCallback, SendBlockedError
from .models import AdapterEnvelope, wechat_account_scope


class WxAuto4GlobalReadonlyAdapter:
    """Experimental free multi-conversation scanner for an isolated desktop.

    wxauto4's free package exposes session-list unread counts, not a durable
    message event stream.  This adapter therefore establishes an unread-count
    watermark at startup, opens only positive deltas, verifies the active chat is
    a one-to-one friend, and parses exactly that many newest incoming bubbles.
    Any ambiguity stops the scanner instead of guessing.

    The adapter is deliberately incapable of sending.  It is intended for a
    dedicated Windows VM/desktop because selecting sessions may focus WeChat.
    """

    def __init__(
        self,
        *,
        expected_version: str,
        expected_account_nickname: str,
        parking_chat: str,
        poll_seconds: float = 1.5,
        state_dir: Path | None = None,
    ) -> None:
        expected_account_nickname = expected_account_nickname.strip()
        parking_chat = parking_chat.strip()
        if not expected_account_nickname:
            raise ValueError("全局只读扫描必须配置预期登录账号昵称")
        if not parking_chat:
            raise ValueError("全局只读扫描必须配置停车会话")
        if not 0.5 <= poll_seconds <= 30:
            raise ValueError("全局只读扫描间隔必须在 0.5—30 秒之间")
        self.expected_version = expected_version.strip()
        self.expected_account_nickname = expected_account_nickname
        self.parking_chat = parking_chat
        self.poll_seconds = float(poll_seconds)
        self.state_dir = state_dir.resolve() if state_dir is not None else None

        self.callback: IncomingCallback | None = None
        self.wx = None
        self._message_parser: Callable[[object, object], object] | None = None
        self._chat_box = None
        self._stop = threading.Event()
        self._runner: threading.Thread | None = None
        self._ui_lock = threading.RLock()
        self._stopped = True
        self._online: bool | None = None
        self._account: dict[str, str | bool] = {}
        self._unread_watermarks: dict[str, int] = {}
        self._seen_event_ids: set[str] = set()
        self._seen_event_order: deque[str] = deque()
        self._startup_stage = "idle"
        self._startup_duration_ms = 0
        self._last_poll_duration_ms = 0
        self._poll_count = 0
        self._foreground_switches = 0
        self._baseline_session_count = 0
        self._baseline_unread_count = 0
        self._accepted_event_count = 0
        self._filtered_group_count = 0
        self._filtered_nontext_count = 0
        self._filtered_self_count = 0
        self._ambiguous_alias_count = 0
        self._dropped_unstable_count = 0
        self._last_event: str | None = None
        self._last_error = ""
        # Free wxauto4 exposes no stable friend ID. A random generation keeps
        # approvals scoped to this scanner run, so a recycled UIA runtime ID can
        # never inherit a contact binding after restart.
        self._run_generation = ""

    def configure_bindings(self, bindings: dict[str, dict[str, str]]) -> None:
        if bindings:
            raise RuntimeError("全局只读扫描不接受发送白名单绑定")

    def destination_matches(
        self, contact_key: str, contact_name: str, adapter_alias: str
    ) -> bool:
        return False

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        raise SendBlockedError("全局扫描适配器永久只读；外部发送接口未被调用")

    @staticmethod
    def _clean_mapping(value: object) -> dict[str, str]:
        if not isinstance(value, dict):
            raise RuntimeError("wxauto4 返回了无效的信息结构")
        return {
            str(key).strip(): str(item).strip()
            for key, item in value.items()
            if str(key).strip() and item is not None
        }

    @staticmethod
    def _first_value(mapping: dict[str, str], keys: tuple[str, ...]) -> str:
        for key in keys:
            value = mapping.get(key, "").strip()
            if value:
                return value
        return ""

    def _verify_account(self) -> None:
        if self.wx is None:
            raise RuntimeError("wxauto4 未初始化")
        is_online = getattr(self.wx, "IsOnline", None)
        get_my_info = getattr(self.wx, "GetMyInfo", None)
        if not callable(is_online) or not callable(get_my_info):
            raise RuntimeError("wxauto4 缺少账号在线或身份核验接口")
        self._online = bool(is_online())
        if not self._online:
            raise RuntimeError("目标微信账号当前未在线")
        info = self._clean_mapping(get_my_info())
        actual = self._first_value(
            info, ("nickname", "昵称", "name", "NickName", "display_name")
        )
        if not actual:
            raise RuntimeError("GetMyInfo 未返回可核验的账号昵称")
        if actual != self.expected_account_nickname:
            raise RuntimeError(
                "微信登录账号不匹配："
                f"预期 {self.expected_account_nickname}，实际 {actual}"
            )
        account_id = self._first_value(
            info, ("wxid", "微信号", "wechat_id", "account", "id")
        )
        if not account_id:
            raise RuntimeError("GetMyInfo 未返回稳定微信号，无法锁定登录账号")
        previous_account_id = str(self._account.get("wechat_id", "") or "")
        if previous_account_id and previous_account_id != account_id:
            raise RuntimeError("微信登录账号 ID 已变化，扫描已停止")
        self._account = {
            "nickname": actual,
            "wechat_id": account_id,
            "verified": True,
        }

    @staticmethod
    def _session_name(session: object) -> str:
        for attribute in ("name", "Name", "nickname", "title"):
            value = getattr(session, attribute, None)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return ""

    @staticmethod
    def _session_bool(session: object, *names: str) -> bool:
        for name in names:
            value = getattr(session, name, None)
            if isinstance(value, bool):
                return value
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in {"1", "true", "yes", "on"}:
                    return True
                if normalized in {"0", "false", "no", "off", ""}:
                    return False
        return False

    @staticmethod
    def _session_unread_count(session: object) -> int:
        for name in ("new_count", "newCount", "unread_count", "unread"):
            value = getattr(session, name, None)
            if isinstance(value, bool):
                continue
            try:
                count = int(value)
            except (TypeError, ValueError):
                continue
            return max(0, count)
        return 0

    @staticmethod
    def _session_runtime_identity(session: object) -> str:
        """Extract a run-scoped UIA identity without reading message content."""

        control = getattr(session, "control", None)
        for candidate in (control, session):
            if candidate is None:
                continue
            get_runtime_id = getattr(candidate, "GetRuntimeId", None)
            if callable(get_runtime_id):
                try:
                    raw = get_runtime_id()
                except Exception:
                    raw = None
                if isinstance(raw, (tuple, list)) and raw:
                    return "uia:" + ",".join(str(part) for part in raw)
            raw = getattr(candidate, "runtimeid", None)
            if isinstance(raw, (tuple, list)) and raw:
                return "uia:" + ",".join(str(part) for part in raw)
            if isinstance(raw, str) and raw.strip():
                return f"uia:{raw.strip()}"
        return ""

    def _sessions(self) -> list[object]:
        if self.wx is None:
            raise RuntimeError("wxauto4 未初始化")
        get_session = getattr(self.wx, "GetSession", None)
        if not callable(get_session):
            raise RuntimeError("wxauto4 缺少 GetSession，无法扫描未读会话")
        sessions = get_session()
        if not isinstance(sessions, (list, tuple)):
            raise RuntimeError("wxauto4 GetSession 未返回会话列表")
        return list(sessions)

    def _snapshot_unread(self) -> tuple[dict[str, int], set[str]]:
        sessions = self._sessions()
        names = [self._session_name(item) for item in sessions]
        counts = Counter(name for name in names if name)
        ambiguous = {name for name, count in counts.items() if count > 1}
        snapshot: dict[str, int] = {}
        for session, name in zip(sessions, names):
            if not name or name in ambiguous:
                continue
            is_new = self._session_bool(session, "isnew", "is_new")
            count = self._session_unread_count(session) if is_new else 0
            snapshot[name] = count
        return snapshot, ambiguous

    def _chat_info(self) -> dict[str, str]:
        if self.wx is None or not callable(getattr(self.wx, "ChatInfo", None)):
            raise RuntimeError("wxauto4 缺少 ChatInfo，无法排除群聊")
        return self._clean_mapping(self.wx.ChatInfo())

    def _wait_for_chat(
        self, expected_alias: str, *, timeout_seconds: float = 5.0
    ) -> dict[str, str]:
        deadline = time.monotonic() + timeout_seconds
        last_name = ""
        while True:
            info = self._chat_info()
            last_name = info.get("chat_name", "").strip()
            if last_name == expected_alias:
                return info
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"微信未能切换到精确会话 {expected_alias}，实际 {last_name or '<空>'}"
                )
            if self._stop.wait(0.1):
                raise RuntimeError("等待微信切换时扫描已停止")

    def _open_session(self, session: object, alias: str) -> dict[str, str]:
        click = getattr(session, "click", None)
        if callable(click):
            click()
        else:
            if self.wx is None or not callable(getattr(self.wx, "ChatWith", None)):
                raise RuntimeError("会话对象不可点击且 wxauto4 缺少 ChatWith")
            self.wx.ChatWith(alias, exact=True)
        self._foreground_switches += 1
        return self._wait_for_chat(alias)

    def _park(self) -> None:
        info = self._chat_info()
        if info.get("chat_name", "").strip() == self.parking_chat:
            return
        if self.wx is None or not callable(getattr(self.wx, "ChatWith", None)):
            raise RuntimeError("wxauto4 缺少 ChatWith，无法切换到停车会话")
        self.wx.ChatWith(self.parking_chat, exact=True)
        self._foreground_switches += 1
        self._wait_for_chat(self.parking_chat)

    @staticmethod
    def _control_identity(control: object) -> str:
        runtime_id = getattr(control, "runtimeid", None)
        if runtime_id is None:
            runtime_id = getattr(control, "RuntimeId", None)
        if isinstance(runtime_id, (tuple, list)):
            return "uia:" + ",".join(str(part) for part in runtime_id)
        return f"uia:{runtime_id}" if runtime_id not in (None, "") else ""

    def _message_controls(self) -> list[tuple[str, object]]:
        if self._chat_box is None:
            raise RuntimeError("wxauto4 ChatBox 未初始化")
        msgbox = getattr(self._chat_box, "msgbox", None)
        get_children = getattr(msgbox, "GetChildren", None)
        if not callable(get_children):
            raise RuntimeError("wxauto4 缺少只读消息控件接口")
        controls = get_children()
        if not isinstance(controls, (list, tuple)):
            raise RuntimeError("wxauto4 消息控件接口未返回列表")
        output: list[tuple[str, object]] = []
        for control in controls:
            if str(getattr(control, "ControlTypeName", "")) != "ListItemControl":
                continue
            identity = self._control_identity(control)
            if identity:
                output.append((identity, control))
        return output

    def _parse_control(self, control: object) -> object:
        if self._message_parser is None or self._chat_box is None:
            raise RuntimeError("wxauto4 消息解析器未初始化")
        return self._message_parser(control, self._chat_box)

    def _collect_unread_texts(
        self, alias: str, session_identity: str, unread_delta: int
    ) -> list[AdapterEnvelope]:
        if unread_delta <= 0:
            return []
        remaining = unread_delta
        collected: list[tuple[str, object]] = []
        # Only parse from the bottom.  A generous finite window prevents one
        # malformed history item from turning this into an unbounded full-history
        # traversal.
        controls = self._message_controls()
        scan_limit = min(len(controls), max(40, unread_delta * 8))
        for control_identity, control in reversed(controls[-scan_limit:]):
            try:
                message = self._parse_control(control)
            except Exception:
                continue
            attr = str(getattr(message, "attr", "")).strip().lower()
            if attr == "self":
                self._filtered_self_count += 1
                continue
            if attr != "friend":
                continue
            remaining -= 1
            message_type = str(getattr(message, "type", "")).strip().lower()
            if message_type != "text":
                self._filtered_nontext_count += 1
            else:
                text = str(getattr(message, "content", "") or "").strip()
                if text:
                    collected.append((control_identity, message))
            if remaining == 0:
                break
        if remaining != 0:
            raise RuntimeError(
                f"会话 {alias} 的未读数为 {unread_delta}，但消息窗口只能核对"
                f" {unread_delta - remaining} 条新入站；扫描已停止"
            )

        account_id = str(self._account.get("wechat_id", "") or "").strip()
        if not account_id:
            raise RuntimeError("GetMyInfo 未返回稳定微信号，无法建立账号身份作用域")
        account_scope = wechat_account_scope(
            self.expected_account_nickname, account_id
        )
        external_identity = "session-uia-sha256:" + hashlib.sha256(
            (
                f"{account_scope}\x1f{alias}\x1f{session_identity}\x1f"
                f"{self._run_generation}"
            ).encode("utf-8")
        ).hexdigest()
        envelopes: list[AdapterEnvelope] = []
        for control_identity, message in reversed(collected):
            message_id = str(getattr(message, "id", "") or "").strip()
            message_hash = str(getattr(message, "hash", "") or "").strip()
            local_token = message_id or message_hash or control_identity
            if not local_token:
                self._dropped_unstable_count += 1
                continue
            text = str(getattr(message, "content", "") or "").strip()
            event_id = hashlib.sha256(
                (
                    f"{account_scope}\x1f{alias}\x1f{self._run_generation}\x1f"
                    f"{local_token}\x1f{text}"
                ).encode("utf-8")
            ).hexdigest()
            envelopes.append(
                AdapterEnvelope(
                    event_id=event_id,
                    account_scope=account_scope,
                    adapter_kind="wxauto4_global_readonly",
                    external_identity=external_identity,
                    identity_quality="uia_runtime",
                    adapter_alias=alias,
                    chat_type="friend",
                    sender_role="friend",
                    message_type="text",
                    text=text,
                    timestamp=datetime.now(),
                    # A positive unread delta plus a concrete message/UI identity
                    # makes the event releasable for this read-only PoC.  It is not
                    # represented as a platform message ID in metadata.
                    releasable=True,
                    metadata={
                        "account_nickname": self.expected_account_nickname,
                        "account_wechat_id": account_id,
                        "session_identity": session_identity,
                        "adapter_run_generation": self._run_generation,
                        "message_id": message_id,
                        "message_hash": message_hash,
                        "control_identity": control_identity,
                        "unread_delta": unread_delta,
                        "event_identity_scope": "local-uia-session",
                        "platform_message_id": None,
                    },
                )
            )
        return envelopes

    def _remember_event(self, event_id: str) -> bool:
        if event_id in self._seen_event_ids:
            return False
        self._seen_event_ids.add(event_id)
        self._seen_event_order.append(event_id)
        while len(self._seen_event_order) > 20_000:
            expired = self._seen_event_order.popleft()
            self._seen_event_ids.discard(expired)
        return True

    def _state_path(self, name: str) -> Path | None:
        return self.state_dir / name if self.state_dir is not None else None

    @staticmethod
    def _write_json_atomic(path: Path, payload: object) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            with temporary.open("x", encoding="utf-8", newline="\n") as handle:
                json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    def _write_scan_intent(
        self, alias: str, session_identity: str, unread_delta: int
    ) -> None:
        path = self._state_path("scan-intent.json")
        if path is None:
            return
        self._write_json_atomic(
            path,
            {
                "schema": 1,
                "account_nickname": self.expected_account_nickname,
                "adapter": "wxauto4_global_readonly",
                "alias": alias,
                "session_identity": session_identity,
                "unread_delta": unread_delta,
                "started_at": datetime.now().astimezone().isoformat(),
            },
        )

    def _write_spool(self, envelopes: list[AdapterEnvelope]) -> None:
        path = self._state_path("captured-spool.json")
        if path is None:
            return
        self._write_json_atomic(
            path,
            {
                "schema": 1,
                "adapter": "wxauto4_global_readonly",
                "envelopes": [
                    {
                        "event_id": item.event_id,
                        "account_scope": item.account_scope,
                        "adapter_kind": item.adapter_kind,
                        "external_identity": item.external_identity,
                        "identity_quality": item.identity_quality,
                        "adapter_alias": item.adapter_alias,
                        "chat_type": item.chat_type,
                        "sender_role": item.sender_role,
                        "message_type": item.message_type,
                        "text": item.text,
                        "timestamp": item.timestamp.isoformat(),
                        "releasable": item.releasable,
                        "metadata": item.metadata,
                    }
                    for item in envelopes
                ],
            },
        )

    def _clear_durable_capture(self) -> None:
        for name in ("captured-spool.json", "scan-intent.json"):
            path = self._state_path(name)
            if path is not None:
                path.unlink(missing_ok=True)

    def _recover_durable_capture(self) -> None:
        intent_path = self._state_path("scan-intent.json")
        spool_path = self._state_path("captured-spool.json")
        if spool_path is not None and spool_path.exists():
            try:
                raw = json.loads(spool_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as error:
                raise RuntimeError("持久捕获缓存损坏，已拒绝继续扫描") from error
            if not isinstance(raw, dict) or raw.get("schema") != 1:
                raise RuntimeError("持久捕获缓存版本无效，已拒绝继续扫描")
            items = raw.get("envelopes")
            if not isinstance(items, list):
                raise RuntimeError("持久捕获缓存缺少消息列表")
            account_id = str(self._account.get("wechat_id", "") or "").strip()
            expected_scope = wechat_account_scope(
                self.expected_account_nickname, account_id
            )
            for raw_item in items:
                if not isinstance(raw_item, dict):
                    raise RuntimeError("持久捕获缓存包含无效消息")
                try:
                    metadata = raw_item["metadata"]
                    if not isinstance(metadata, dict):
                        raise TypeError("metadata")
                    envelope = AdapterEnvelope(
                        event_id=str(raw_item["event_id"]),
                        account_scope=str(raw_item["account_scope"]),
                        adapter_kind=str(raw_item["adapter_kind"]),
                        external_identity=str(raw_item["external_identity"]),
                        identity_quality=str(raw_item["identity_quality"]),
                        adapter_alias=str(raw_item["adapter_alias"]),
                        chat_type=str(raw_item["chat_type"]),
                        sender_role=str(raw_item["sender_role"]),
                        message_type=str(raw_item["message_type"]),
                        text=str(raw_item["text"]),
                        timestamp=datetime.fromisoformat(str(raw_item["timestamp"])),
                        releasable=bool(raw_item["releasable"]),
                        metadata=dict(metadata),
                    )
                except (KeyError, TypeError, ValueError) as error:
                    raise RuntimeError("持久捕获缓存消息结构无效") from error
                if (
                    envelope.account_scope != expected_scope
                    or envelope.adapter_kind != "wxauto4_global_readonly"
                ):
                    raise RuntimeError("持久捕获缓存的微信账号或适配器不匹配")
                if self.callback is None:
                    raise RuntimeError("全局只读回调已失效")
                self.callback(envelope)
                self._remember_event(envelope.event_id)
            self._clear_durable_capture()
            return
        if intent_path is not None and intent_path.exists():
            alias = "<未知会话>"
            try:
                raw_intent = json.loads(intent_path.read_text(encoding="utf-8"))
                if isinstance(raw_intent, dict):
                    alias = str(raw_intent.get("alias") or alias)[:200]
            except (OSError, json.JSONDecodeError):
                pass
            raise RuntimeError(
                f"上次扫描在会话 {alias} 点开后、消息持久化前中断；"
                "请先人工核对该会话，再使用启动器确认恢复"
            )

    def _poll_once(self) -> None:
        with self._ui_lock:
            started = time.monotonic()
            self._verify_account()
            sessions = self._sessions()
            names = [self._session_name(item) for item in sessions]
            counts = Counter(name for name in names if name)
            ambiguous = {name for name, count in counts.items() if count > 1}
            self._ambiguous_alias_count += len(ambiguous)
            if ambiguous:
                aliases = "、".join(sorted(ambiguous)[:5])
                raise RuntimeError(
                    f"会话列表出现重复备注名（{aliases}）；身份不唯一，扫描已停止"
                )
            candidates: list[tuple[object, str, str, int, int]] = []
            observed: dict[str, int] = {}
            for session, alias in zip(sessions, names):
                if not alias or alias in ambiguous or alias == self.parking_chat:
                    continue
                is_new = self._session_bool(session, "isnew", "is_new")
                current = self._session_unread_count(session) if is_new else 0
                previous = self._unread_watermarks.get(alias, 0)
                observed[alias] = current
                if is_new and current > 0 and current > previous:
                    session_identity = self._session_runtime_identity(session)
                    if not session_identity:
                        self._dropped_unstable_count += current - previous
                        raise RuntimeError(
                            f"会话 {alias} 缺少 UIA 身份，禁止点开并清除未读"
                        )
                    candidates.append(
                        (session, alias, session_identity, current - previous, current)
                    )

            # Opening a conversation can rebuild the session-list UI controls.
            # Process at most one captured control per poll and re-enumerate before
            # touching the next candidate, avoiding stale UI references.
            for session, alias, session_identity, delta, current in candidates[:1]:
                # Re-read the live marker immediately before crossing the click
                # boundary. This narrows (but cannot eliminate) the free UI
                # scanner's unread-count race.
                latest_is_new = self._session_bool(session, "isnew", "is_new")
                latest_current = (
                    self._session_unread_count(session) if latest_is_new else 0
                )
                previous = self._unread_watermarks.get(alias, 0)
                if not latest_is_new or latest_current <= previous:
                    raise RuntimeError(
                        f"会话 {alias} 的未读状态在点开前发生变化；扫描已停止"
                    )
                current = latest_current
                delta = latest_current - previous
                self._write_scan_intent(alias, session_identity, delta)
                info = self._open_session(session, alias)
                chat_type = info.get("chat_type", "").strip().lower()
                if chat_type != "friend":
                    self._filtered_group_count += 1
                    self._park()
                    self._unread_watermarks[alias] = 0
                    self._clear_durable_capture()
                    continue
                envelopes = self._collect_unread_texts(
                    alias, session_identity, delta
                )
                # Leave the active conversation as soon as parsing completes, so
                # later arrivals can become unread in the parked session instead
                # of being silently consumed while database callbacks run.
                self._park()
                self._unread_watermarks[alias] = 0
                self._write_spool(envelopes)
                for envelope in envelopes:
                    if not self._remember_event(envelope.event_id):
                        continue
                    if self.callback is None:
                        raise RuntimeError("全局只读回调已失效")
                    self.callback(envelope)
                    self._accepted_event_count += 1
                    self._last_event = datetime.now().astimezone().isoformat(
                        timespec="seconds"
                    )
                self._clear_durable_capture()

            for alias, current in observed.items():
                if alias not in {candidate[1] for candidate in candidates}:
                    self._unread_watermarks[alias] = current
            self._poll_count += 1
            self._last_poll_duration_ms = int((time.monotonic() - started) * 1000)

    def start(self, callback: IncomingCallback) -> None:
        installed_version = importlib.metadata.version("wxauto4")
        if self.expected_version and installed_version != self.expected_version:
            raise RuntimeError(
                f"wxauto4 版本不匹配：需要 {self.expected_version}，当前 {installed_version}"
            )
        module = importlib.import_module("wxauto4")
        self.callback = callback
        self._stop.clear()
        self._stopped = False
        self.wx = None
        self._chat_box = None
        self._message_parser = None
        self._online = None
        self._account = {}
        self._runner = None
        self._last_error = ""
        self._run_generation = uuid.uuid4().hex
        self._unread_watermarks.clear()
        self._seen_event_ids.clear()
        self._seen_event_order.clear()
        self._startup_stage = "constructing_wechat"
        self._startup_duration_ms = 0
        self._last_poll_duration_ms = 0
        self._poll_count = 0
        self._foreground_switches = 0
        self._baseline_session_count = 0
        self._baseline_unread_count = 0
        self._accepted_event_count = 0
        self._filtered_group_count = 0
        self._filtered_nontext_count = 0
        self._filtered_self_count = 0
        self._ambiguous_alias_count = 0
        self._dropped_unstable_count = 0
        self._last_event = None
        started = time.monotonic()
        try:
            self.wx = module.WeChat(ads=False, resize=False)
            for method_name in (
                "GetSession",
                "ChatWith",
                "ChatInfo",
                "GetMyInfo",
                "IsOnline",
            ):
                if not callable(getattr(self.wx, method_name, None)):
                    raise RuntimeError(f"wxauto4 缺少必需方法: {method_name}")
            self._chat_box = getattr(self.wx, "ChatBox", None)
            parser = getattr(module, "parse_msg", None)
            if not callable(parser):
                parser_module = importlib.import_module("wxauto4.msgs.msg")
                parser = getattr(parser_module, "parse_msg", None)
            if not callable(parser):
                raise RuntimeError("wxauto4 缺少消息解析器 parse_msg")
            self._message_parser = parser
            msgbox = getattr(self._chat_box, "msgbox", None)
            if not callable(getattr(msgbox, "GetChildren", None)):
                raise RuntimeError("wxauto4 缺少只读消息控件接口")
            self._startup_stage = "verifying_account"
            self._verify_account()
            self._startup_stage = "recovering_durable_capture"
            self._recover_durable_capture()
            self._startup_stage = "building_unread_watermark"
            snapshot, ambiguous = self._snapshot_unread()
            self._unread_watermarks = snapshot
            self._baseline_session_count = len(snapshot)
            self._baseline_unread_count = sum(snapshot.values())
            self._ambiguous_alias_count = len(ambiguous)
            if ambiguous:
                aliases = "、".join(sorted(ambiguous)[:5])
                raise RuntimeError(
                    f"会话列表存在重复备注名（{aliases}），无法建立唯一身份基线"
                )
            if self._baseline_unread_count:
                raise RuntimeError(
                    "启动基线仍有未读消息；为避免静默漏读，请先在微信中将所有"
                    "需要接管的一对一会话处理为已读，再重新启动"
                )
            self._startup_stage = "parking"
            self._park()
            self._startup_stage = "running"
            self._startup_duration_ms = int((time.monotonic() - started) * 1000)
            self._runner = threading.Thread(
                target=self._run,
                name="wxauto4-global-readonly-scanner",
                daemon=True,
            )
            self._runner.start()
        except Exception as error:
            self._startup_duration_ms = int((time.monotonic() - started) * 1000)
            self._last_error = str(error)[:500]
            self.callback = None
            self.wx = None
            self._chat_box = None
            self._message_parser = None
            self._stopped = True
            raise

    def _run(self) -> None:
        while not self._stop.wait(self.poll_seconds):
            try:
                self._poll_once()
            except Exception as error:
                self._last_error = str(error)[:500]
                self._stopped = True
                self.callback = None
                self._stop.set()
                break

    def stop(self) -> None:
        self._stop.set()
        self._stopped = True
        self.callback = None
        if self._runner and self._runner is not threading.current_thread():
            self._runner.join(timeout=3)
        self.wx = None
        self._chat_box = None
        self._message_parser = None

    def health(self) -> dict[str, object]:
        running = bool(
            self._runner and self._runner.is_alive() and not self._stopped
        )
        return {
            "mode": "wxauto4_global_readonly",
            "running": running,
            "online": self._online,
            "account": dict(self._account),
            "read_only": True,
            "send_capable": False,
            "requires_isolated_desktop": True,
            "supports_muted_chats": False,
            "identity_quality": "uia_runtime",
            "identity_stability": "current_wechat_ui_session_only",
            "adapter_run_generation": self._run_generation,
            "platform_message_ids": False,
            "capture_guarantee": "best_effort_ui_unread_scan",
            "startup_stage": self._startup_stage,
            "startup_duration_ms": self._startup_duration_ms,
            "baseline_session_count": self._baseline_session_count,
            "baseline_unread_count": self._baseline_unread_count,
            "last_poll_duration_ms": self._last_poll_duration_ms,
            "poll_count": self._poll_count,
            "foreground_switches": self._foreground_switches,
            "accepted_event_count": self._accepted_event_count,
            "filtered_group_count": self._filtered_group_count,
            "filtered_nontext_count": self._filtered_nontext_count,
            "filtered_self_count": self._filtered_self_count,
            "ambiguous_alias_count": self._ambiguous_alias_count,
            "dropped_unstable_count": self._dropped_unstable_count,
            "durable_capture_enabled": self.state_dir is not None,
            "pending_scan_intent": bool(
                (path := self._state_path("scan-intent.json")) and path.exists()
            ),
            "pending_captured_spool": bool(
                (path := self._state_path("captured-spool.json")) and path.exists()
            ),
            "last_event": self._last_event,
            "last_error": self._last_error,
        }
