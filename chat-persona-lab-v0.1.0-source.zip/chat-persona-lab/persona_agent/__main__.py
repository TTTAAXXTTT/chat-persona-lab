from __future__ import annotations

import argparse
import json
from pathlib import Path

from .adapters import build_adapter
from .chat_parser import export_summary, parse_export
from .config import AppConfig
from .deepseek import DeepSeekClient, FakeDraftModel
from .retrieval import ProfileRetriever
from .server import run_server
from .service import PersonaService
from .style_memory import build_style_fingerprint
from .store import Store
from .xlsx_profile import load_profile_items


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Chat Persona Lab — 聊语实验室")
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--analyze-only", action="store_true", help="只解析并输出数量摘要，不启动服务")
    parser.add_argument(
        "--offline-fake-model",
        action="store_true",
        help="使用不会联网的固定测试模型；仅用于验证审批流程",
    )
    return parser.parse_args()


def main() -> None:
    args = _arguments()
    config = AppConfig.from_root(args.project_root)
    config.validate(require_api=not args.offline_fake_model and not args.analyze_only)
    config.data_dir.mkdir(parents=True, exist_ok=True)

    profile_items = load_profile_items(config.profile_xlsx_path, config.profile_sheet_prefixes)
    store = Store(config.db_path)
    active_sources: list[Path] = []
    if config.profile_xlsx_path.exists():
        active_sources.append(config.profile_xlsx_path)
        store.record_knowledge_source(
            config.profile_xlsx_path,
            kind="profile_xlsx",
            item_count=len(profile_items),
            metadata={
                "sheet_count": len({item.sheet for item in profile_items}),
                "sheets": sorted({item.sheet for item in profile_items}),
            },
        )
    summaries: list[dict[str, object]] = []
    missing: list[str] = []
    for path in config.chat_export_files:
        if not path.exists():
            missing.append(str(path))
            continue
        active_sources.append(path)
        export = parse_export(path)
        store.import_export(export)
        summary = export_summary(export)
        summaries.append(summary)
        store.record_knowledge_source(
            path,
            kind="chat_export",
            item_count=len(export.messages),
            metadata={
                "conversation": export.conversation_name,
                "message_count": summary["message_count"],
                "self_message_count": summary["self_message_count"],
                "other_message_count": summary["other_message_count"],
                "example_pair_count": summary["example_pair_count"],
            },
        )
    store.prune_knowledge_manifest(active_sources)
    style_fingerprint = build_style_fingerprint(store.style_source_messages())

    if args.analyze_only:
        print(
            json.dumps(
                {
                    "profile_items": len(profile_items),
                    "configured_export_count": len(config.chat_export_files),
                    "database_counts": store.counts(),
                    "knowledge_sources": store.knowledge_summary(),
                    "style_fingerprint": style_fingerprint.to_prompt_payload(),
                    "exports": summaries,
                    "missing_files": missing,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        if missing or not config.chat_export_files:
            raise SystemExit(2)
        return

    model = FakeDraftModel() if args.offline_fake_model else DeepSeekClient(config)
    adapter = build_adapter(config)
    service = PersonaService(
        config=config,
        store=store,
        model=model,
        profile_retriever=ProfileRetriever(profile_items),
        adapter=adapter,
        style_fingerprint=style_fingerprint,
    )

    def start_service_after_http_bind() -> None:
        print(f"聊语实验室管理页面已启动：http://{config.host}:{config.port}")
        print("微信监听正在后台初始化；状态和错误可在管理页面查看。")
        print(
            f"供应商：{getattr(model, 'provider_name', 'offline')}；"
            f"模型：{model.model_name}；适配器：{config.adapter_mode}；"
            f"外发：{config.send_enabled}"
        )
        print(
            f"资料：{len({item.sheet for item in profile_items})} 个工作表；"
            f"{len(summaries)} 份聊天；"
            f"匿名风格指纹覆盖 {style_fingerprint.self_message_count} 条本人消息。"
        )
        if missing:
            print(f"警告：有 {len(missing)} 个聊天文件未找到。")
        service.start_background()

    try:
        run_server(
            service,
            store,
            config.host,
            config.port,
            Path(__file__).resolve().parent / "web",
            on_bound=start_service_after_http_bind,
        )
    except KeyboardInterrupt:
        pass
    finally:
        service.stop()


if __name__ == "__main__":
    main()
