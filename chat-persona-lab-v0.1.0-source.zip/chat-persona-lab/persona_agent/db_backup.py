from __future__ import annotations

import argparse
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

from .config import AppConfig


def backup_database(source_path: Path, backup_dir: Path) -> Path | None:
    """Create and verify a consistent SQLite online backup.

    The source may be open in another process and using WAL mode.  SQLite's
    backup API copies one coherent snapshot, unlike copying only the main file.
    """

    source = source_path.resolve()
    if not source.exists():
        return None
    if not source.is_file():
        raise RuntimeError(f"数据库路径不是普通文件: {source}")
    destination_dir = backup_dir.resolve()
    destination_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    destination = destination_dir / f"persona-agent-pre-global-{stamp}.sqlite3"
    if destination == source:
        raise RuntimeError("数据库备份目标不能与源文件相同")

    try:
        with closing(
            sqlite3.connect(f"{source.as_uri()}?mode=ro", uri=True, timeout=20)
        ) as source_connection:
            with closing(
                sqlite3.connect(destination, timeout=20)
            ) as target_connection:
                source_connection.backup(target_connection)
                target_connection.commit()
                result = target_connection.execute("PRAGMA integrity_check").fetchone()
                if not result or str(result[0]).lower() != "ok":
                    raise RuntimeError("数据库备份完整性检查失败")
    except Exception:
        # This path was generated in this function and did not pass integrity
        # validation, so it must never be presented as a recoverable backup.
        destination.unlink(missing_ok=True)
        raise
    return destination


def main() -> None:
    parser = argparse.ArgumentParser(description="创建全局只读模式启动前数据库备份")
    parser.add_argument("project_root", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    config = AppConfig.from_root(root)
    destination = backup_database(config.db_path, config.data_dir / "backups")
    if destination is None:
        print("数据库尚不存在；本次无需备份。")
    else:
        print(f"数据库一致性备份已创建：{destination}")


if __name__ == "__main__":
    main()
