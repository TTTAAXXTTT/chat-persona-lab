from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .models import ChatMessage, ExamplePair, ParsedExport


MESSAGE_RE = re.compile(
    r"^\[(?P<timestamp>[^\]]+)]\s+"
    r"(?P<sender_name>.*?)\((?P<sender_id>[^()]*)\)"
    r"(?:\s+\[avatar=[^\]]+])?:\s?(?P<content>.*)$"
)
HEADER_RE = re.compile(r"^(会话|账号|会话头像|时间范围|消息类型|导出时间):\s*(.*)$")
NON_TEXT_MARKERS = re.compile(
    r"^\[(图片|视频|语音|文件|位置|名片|动画表情|系统消息|通话|小程序|链接|聊天记录)(?:[^\]]*)]$"
)
SENSITIVE_EXAMPLE = re.compile(
    r"wxid_|https?://|密码|验证码|身份证|护照|银行卡|家庭住址|具体地址|"
    r"api[_-]?key|access[_-]?token|密钥|微信号|(?:我的)?账号(?:是|为|[:：])|"
    r"(?:住在|位于|地址(?:是|在|为|[:：]))[^，。；;\n]{2,60}(?:路|街|巷|道|号)|"
    r"(?<!\d)(?:\+?86[-\s]?)?1[3-9](?:[-\s]?\d){9}(?!\d)|"
    r"(?<!\d)\d{7,}(?!\d)",
    re.I,
)
UNRELIABLE_EXAMPLE = re.compile(r"喝多了|喝醉了|酒后|气话|上头了|正在发火|别当真")


def _conversation_header(value: str) -> tuple[str, str]:
    match = re.match(r"^(.*?)\s*\(([^()]*)\)\s*$", value)
    if not match:
        return value.strip(), ""
    return match.group(1).strip(), match.group(2).strip()


def parse_export(path: Path) -> ParsedExport:
    headers: dict[str, str] = {}
    messages: list[ChatMessage] = []
    pending: ChatMessage | None = None
    source_index = 0

    for raw_line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        header = HEADER_RE.match(raw_line)
        if header and not messages:
            headers[header.group(1)] = header.group(2).strip()
            continue
        match = MESSAGE_RE.match(raw_line)
        if match:
            if pending is not None:
                messages.append(pending)
            source_index += 1
            sender_name = match.group("sender_name").strip()
            sender_id = match.group("sender_id").strip()
            self_account = headers.get("账号", "")
            pending = ChatMessage(
                timestamp=datetime.strptime(match.group("timestamp"), "%Y-%m-%d %H:%M:%S"),
                sender_name=sender_name,
                sender_id=sender_id,
                content=match.group("content").strip(),
                is_self=sender_id == self_account or sender_name == self_account,
                source_file=str(path.resolve()),
                source_index=source_index,
            )
        elif pending is not None and raw_line.strip():
            pending.content = f"{pending.content}\n{raw_line.strip()}".strip()
    if pending is not None:
        messages.append(pending)

    if not headers.get("会话", "").strip():
        raise ValueError(f"聊天导出缺少有效会话标识: {path.name}")
    if not headers.get("账号", "").strip():
        raise ValueError(f"聊天导出缺少本人账号标识: {path.name}")
    conversation_name, conversation_id = _conversation_header(headers["会话"])
    if not conversation_name or not conversation_id:
        raise ValueError(f"聊天导出的会话名称或 ID 为空: {path.name}")
    return ParsedExport(
        conversation_name=conversation_name,
        conversation_id=conversation_id,
        self_account=headers.get("账号", ""),
        source_file=str(path.resolve()),
        messages=messages,
    )


@dataclass(slots=True)
class _Turn:
    is_self: bool
    start: datetime
    end: datetime
    messages: list[str]


def _is_usable_text(value: str) -> bool:
    text = value.strip()
    return bool(text) and not NON_TEXT_MARKERS.fullmatch(text)


def _is_example_text(value: str) -> bool:
    text = value.strip()
    return (
        _is_usable_text(text)
        and len(text) <= 500
        and not SENSITIVE_EXAMPLE.search(text)
        and not UNRELIABLE_EXAMPLE.search(text)
    )


def group_turns(messages: list[ChatMessage], gap_seconds: int = 180) -> list[_Turn]:
    turns: list[_Turn] = []
    for message in messages:
        if not _is_usable_text(message.content):
            continue
        if (
            turns
            and turns[-1].is_self == message.is_self
            and (message.timestamp - turns[-1].end).total_seconds() <= gap_seconds
        ):
            turns[-1].messages.append(message.content)
            turns[-1].end = message.timestamp
        else:
            turns.append(
                _Turn(
                    is_self=message.is_self,
                    start=message.timestamp,
                    end=message.timestamp,
                    messages=[message.content],
                )
            )
    return turns


def build_example_pairs(export: ParsedExport, max_response_gap_hours: int = 8) -> list[ExamplePair]:
    turns = group_turns(export.messages)
    examples: list[ExamplePair] = []
    for index in range(len(turns) - 1):
        incoming = turns[index]
        reply = turns[index + 1]
        if incoming.is_self or not reply.is_self:
            continue
        if (reply.start - incoming.end).total_seconds() > max_response_gap_hours * 3600:
            continue
        if not all(_is_example_text(value) for value in incoming.messages + reply.messages):
            continue
        digest = hashlib.sha256(
            (
                f"{export.source_file}|{index}|{incoming.start.isoformat()}|"
                f"{reply.start.isoformat()}|{incoming.messages!r}|{reply.messages!r}"
            ).encode("utf-8")
        ).hexdigest()
        examples.append(
            ExamplePair(
                source_key=digest,
                contact_key=export.conversation_id,
                timestamp=incoming.start,
                incoming_messages=incoming.messages,
                reply_messages=reply.messages,
            )
        )
    return examples


def export_summary(export: ParsedExport) -> dict[str, object]:
    self_count = sum(1 for message in export.messages if message.is_self)
    non_text = sum(1 for message in export.messages if not _is_usable_text(message.content))
    return {
        "conversation": export.conversation_name,
        "conversation_id": export.conversation_id,
        "message_count": len(export.messages),
        "self_message_count": self_count,
        "other_message_count": len(export.messages) - self_count,
        "non_text_marker_count": non_text,
        "example_pair_count": len(build_example_pairs(export)),
        "start": export.messages[0].timestamp.isoformat() if export.messages else None,
        "end": export.messages[-1].timestamp.isoformat() if export.messages else None,
    }
