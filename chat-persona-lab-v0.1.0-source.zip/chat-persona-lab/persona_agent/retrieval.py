from __future__ import annotations

import math
import re
from typing import Any

from .models import ProfileItem
from .xlsx_profile import SECTION_CONTEXT_PREFIX


def _tokens(text: str) -> set[str]:
    normalized = re.sub(r"\s+", " ", text.lower()).strip()
    chinese = [char for char in normalized if "\u4e00" <= char <= "\u9fff"]
    grams = {"".join(chinese[index : index + 2]) for index in range(max(0, len(chinese) - 1))}
    words = set(re.findall(r"[a-z0-9_]{2,}", normalized))
    return grams | words


def _score(query: set[str], candidate: str) -> float:
    candidate_tokens = _tokens(candidate)
    if not query or not candidate_tokens:
        return 0.0
    overlap = len(query & candidate_tokens)
    if not overlap:
        return 0.0
    return overlap / math.sqrt(len(query) * len(candidate_tokens))


class ProfileRetriever:
    GLOBAL_PREFIXES = ("02", "03", "04", "05", "07", "12", "13")
    # These sheets are useful, but must only enter a request after a semantic
    # match.  In particular, identity and state rows are never fixed anchors.
    SEMANTIC_PREFIXES = ("00", "01", "06")
    RELATIONSHIP_PREFIXES = {
        "亲近朋友": ("09",),
        "普通朋友": ("09",),
        "亲密对象": ("10",),
        "工作同事": ("08",),
        "客户/业务方": ("08", "11"),
        "陌生人": ("11",),
    }
    LOCAL_POLICY_PREFIXES = ("14",)
    _IDENTITY_DENY_MARKERS = (
        "绝不主动提及",
        "不主动提及",
        "只在本人授权",
        "本人已授权",
        "仅供本人",
    )
    _TABLE_HEADER_FIRST_CELLS = {
        "模块",
        "原则",
        "维度",
        "字段",
        "状态",
        "步骤",
        "编号",
        "时间",
        "样本类型",
        "优先级",
        "训练项",
    }

    def __init__(self, items: list[ProfileItem]):
        # Keep the complete local corpus.  Eligibility is decided per request so
        # confirmed rows in sheet 15 are not lost and private rows remain local.
        self.items = list(items)

    @staticmethod
    def _original_cells(item: ProfileItem) -> list[str]:
        return [
            cell
            for cell in item.cells
            if cell and not cell.startswith(SECTION_CONTEXT_PREFIX)
        ]

    @classmethod
    def _is_structured_row(cls, item: ProfileItem) -> bool:
        cells = cls._original_cells(item)
        if len(cells) < 2:
            return False
        return cells[0] not in cls._TABLE_HEADER_FIRST_CELLS

    @classmethod
    def _confirmed_sheet_15_row(cls, item: ProfileItem) -> bool:
        return item.sheet.startswith("15") and "已确认" in cls._original_cells(item)

    @classmethod
    def _identity_row_may_be_used(cls, item: ProfileItem) -> bool:
        if not item.sheet.startswith("01"):
            return True
        cells = cls._original_cells(item)
        # The sheet's disclosure-policy cells are authoritative.  A denial may
        # contain additional conditions, so inspect complete cells rather than
        # relying on a fixed column across different sections.
        for cell in cells:
            normalized = cell.replace(" ", "")
            if normalized == "否" or normalized.startswith("否，"):
                return False
            if any(marker in normalized for marker in cls._IDENTITY_DENY_MARKERS):
                return False
        return True

    @classmethod
    def _eligible_for_request(
        cls,
        item: ProfileItem,
        allowed_prefixes: tuple[str, ...],
    ) -> bool:
        if not cls._is_structured_row(item):
            return False
        if item.sheet.startswith(cls.LOCAL_POLICY_PREFIXES):
            return False
        if item.sheet.startswith("15"):
            return cls._confirmed_sheet_15_row(item)
        if not item.sheet.startswith(allowed_prefixes):
            return False
        return cls._identity_row_may_be_used(item)

    def search(
        self,
        query: str,
        relationship: str = "待确认",
        limit: int = 14,
    ) -> list[ProfileItem]:
        if limit <= 0:
            return []
        allowed_prefixes = (
            self.GLOBAL_PREFIXES
            + self.SEMANTIC_PREFIXES
            + self.RELATIONSHIP_PREFIXES.get(relationship, ())
        )
        scoped_items = [
            item
            for item in self.items
            if self._eligible_for_request(item, allowed_prefixes)
        ]
        query_tokens = _tokens(query)
        scored = sorted(
            ((item, _score(query_tokens, item.text)) for item in scoped_items),
            key=lambda pair: pair[1],
            reverse=True,
        )
        selected: list[ProfileItem] = [
            item for item, score in scored if score > 0
        ][: max(4, limit - 6)]

        # Stable style and safety anchors are always included. Sensitive identity sheets
        # are excluded earlier by configuration.
        anchors = [
            item
            for item in scoped_items
            if (
                (item.sheet.startswith("04") and item.row in {7, 10, 11, 12, 13, 29, 34, 35})
                or (item.sheet.startswith("12") and item.row in {7, 8, 11})
                or (item.sheet.startswith("13") and item.row in {16, 18, 19})
            )
        ]
        seen = {(item.sheet, item.row) for item in selected}
        for item in anchors:
            if (item.sheet, item.row) not in seen:
                selected.append(item)
                seen.add((item.sheet, item.row))
            if len(selected) >= limit:
                break
        return selected[:limit]


def retrieve_examples(
    query: str,
    examples: list[dict[str, Any]],
    limit: int = 6,
) -> list[dict[str, Any]]:
    query_tokens = _tokens(query)
    scored: list[tuple[float, int, dict[str, Any]]] = []
    for recency_rank, example in enumerate(examples):
        incoming_text = "\n".join(example["incoming"])
        semantic = _score(query_tokens, incoming_text)
        if semantic <= 0:
            continue
        recency = 1.0 / (1.0 + recency_rank / 100.0)
        total = semantic * 0.9 + recency * 0.1
        scored.append((total, recency_rank, example))
    scored.sort(key=lambda item: (item[0], -item[1]), reverse=True)
    return [example for _, _, example in scored[:limit]]
