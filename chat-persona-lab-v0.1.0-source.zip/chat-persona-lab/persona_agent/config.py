from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse


MODEL_PROVIDERS = {"deepseek_official", "opencode_go"}
DEEPSEEK_V4_MODELS = {"deepseek-v4-flash", "deepseek-v4-pro"}
OPENCODE_GO_BASE_URL = "https://opencode.ai/zen/go/v1"


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            os.environ.setdefault(key, value)


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _split(value: str | None, separator: str = ",") -> tuple[str, ...]:
    if not value:
        return ()
    return tuple(item.strip() for item in value.split(separator) if item.strip())


@dataclass(frozen=True, slots=True)
class AppConfig:
    project_root: Path
    data_dir: Path
    db_path: Path
    profile_xlsx_path: Path
    chat_export_files: tuple[Path, ...]
    profile_sheet_prefixes: tuple[str, ...]
    deepseek_api_key: str
    deepseek_base_url: str
    deepseek_model: str
    deepseek_json_mode: bool
    temperature: float
    max_tokens: int
    host: str
    port: int
    adapter_mode: str
    contact_whitelist: tuple[str, ...]
    private_terms: tuple[str, ...]
    send_enabled: bool
    allow_cloud_processing: bool
    api_context_char_budget: int
    debounce_seconds: float
    draft_ttl_seconds: int
    wx_account_nickname: str
    wx_live_validated: bool
    wx_test_account_mode: bool
    wx_live_unlock: str
    wxauto4_expected_version: str
    wxautox4_expected_version: str
    allow_custom_model_endpoint: bool
    inbox_path: Path
    outbox_path: Path
    # Provider-specific fields are optional so existing direct AppConfig
    # construction and the legacy DEEPSEEK_* environment remain compatible.
    model_provider: str = "deepseek_official"
    opencode_go_api_key: str = ""
    cloud_provider_ack: str = ""
    # Explicit single-recipient binding, supplied by local configuration.
    wx_send_contact_key: str = ""
    wx_polling_send_unlock: str = ""
    # Free multi-conversation scanning is a separate, strictly read-only mode.
    # It intentionally does not reuse CONTACT_WHITELIST or any send capability.
    wx_global_parking_chat: str = "文件传输助手"
    wx_global_poll_seconds: float = 1.5

    @classmethod
    def from_root(cls, project_root: Path) -> "AppConfig":
        root = project_root.resolve()
        _load_env_file(root / ".env")
        model_provider = os.getenv("MODEL_PROVIDER", "deepseek_official").strip().lower()
        data_dir = Path(os.getenv("DATA_DIR", str(root / "data"))).resolve()
        profile_default = str(root / "profile.xlsx")
        file_values = _split(os.getenv("CHAT_EXPORT_FILES"), ";")
        chat_dir = os.getenv("CHAT_EXPORT_DIR", "").strip()
        if not file_values and chat_dir:
            file_values = tuple(str(path) for path in sorted(Path(chat_dir).glob("*_messages.txt")))
        return cls(
            project_root=root,
            data_dir=data_dir,
            db_path=Path(os.getenv("DB_PATH", str(data_dir / "persona_agent.sqlite3"))).resolve(),
            profile_xlsx_path=Path(os.getenv("PROFILE_XLSX_PATH", profile_default)),
            chat_export_files=tuple(Path(value) for value in file_values),
            profile_sheet_prefixes=_split(
                os.getenv(
                    "PROFILE_SHEET_PREFIXES",
                    "00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15",
                )
            ),
            deepseek_api_key=os.getenv("DEEPSEEK_API_KEY", "").strip(),
            deepseek_base_url=(
                OPENCODE_GO_BASE_URL
                if model_provider == "opencode_go"
                else os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/")
            ),
            deepseek_model=os.getenv("DEEPSEEK_MODEL", "deepseek-v4-flash").strip(),
            deepseek_json_mode=_as_bool(os.getenv("DEEPSEEK_JSON_MODE"), True),
            temperature=float(os.getenv("DEEPSEEK_TEMPERATURE", "0.55")),
            max_tokens=int(os.getenv("DEEPSEEK_MAX_TOKENS", "700")),
            host=os.getenv("APP_HOST", "127.0.0.1"),
            port=int(os.getenv("APP_PORT", "8765")),
            adapter_mode=os.getenv("CHAT_ADAPTER", "jsonl").strip().lower(),
            contact_whitelist=_split(os.getenv("CONTACT_WHITELIST")),
            private_terms=_split(os.getenv("PRIVATE_TERMS")),
            send_enabled=_as_bool(os.getenv("SEND_ENABLED"), False),
            allow_cloud_processing=_as_bool(os.getenv("ALLOW_CLOUD_PROCESSING"), False),
            api_context_char_budget=int(os.getenv("API_CONTEXT_CHAR_BUDGET", "18000")),
            debounce_seconds=float(os.getenv("DEBOUNCE_SECONDS", "2.5")),
            draft_ttl_seconds=int(os.getenv("DRAFT_TTL_SECONDS", "1800")),
            wx_account_nickname=os.getenv("WX_ACCOUNT_NICKNAME", "").strip(),
            wx_live_validated=_as_bool(os.getenv("WX_LIVE_VALIDATED"), False),
            wx_test_account_mode=_as_bool(os.getenv("WX_TEST_ACCOUNT_MODE"), False),
            wx_live_unlock=os.getenv("WX_LIVE_UNLOCK", "").strip(),
            wxauto4_expected_version=os.getenv(
                "WXAUTO4_EXPECTED_VERSION", "41.1.2"
            ).strip(),
            wxautox4_expected_version=os.getenv(
                "WXAUTOX4_EXPECTED_VERSION", "41.1.1.post1"
            ).strip(),
            allow_custom_model_endpoint=_as_bool(
                os.getenv("ALLOW_CUSTOM_MODEL_ENDPOINT"), False
            ),
            inbox_path=Path(os.getenv("INBOX_PATH", str(data_dir / "inbox.jsonl"))).resolve(),
            outbox_path=Path(os.getenv("OUTBOX_PATH", str(data_dir / "outbox.jsonl"))).resolve(),
            model_provider=model_provider,
            opencode_go_api_key=os.getenv("OPENCODE_GO_API_KEY", "").strip(),
            cloud_provider_ack=os.getenv("CLOUD_PROVIDER_ACK", "").strip().lower(),
            wx_send_contact_key=os.getenv("WX_SEND_CONTACT_KEY", "").strip(),
            wx_polling_send_unlock=os.getenv(
                "WX_POLLING_SEND_UNLOCK", ""
            ).strip(),
            wx_global_parking_chat=os.getenv(
                "WX_GLOBAL_PARKING_CHAT", "文件传输助手"
            ).strip(),
            wx_global_poll_seconds=float(
                os.getenv("WX_GLOBAL_POLL_SECONDS", "1.5")
            ),
        )

    def validate(self, require_api: bool = False) -> None:
        if self.model_provider not in MODEL_PROVIDERS:
            raise ValueError(
                "MODEL_PROVIDER 只允许 deepseek_official 或 opencode_go。"
            )
        if self.deepseek_model not in DEEPSEEK_V4_MODELS:
            raise ValueError(
                "模型只允许 deepseek-v4-flash 或 deepseek-v4-pro。"
            )
        if self.host not in {"127.0.0.1", "localhost"}:
            raise ValueError("首版只允许绑定本机回环地址。")
        if self.adapter_mode not in {
            "jsonl",
            "mock",
            "wxautox4",
            "wxauto4_polling",
            "wxauto4_global_readonly",
        }:
            raise ValueError(f"未知 CHAT_ADAPTER: {self.adapter_mode}")
        if self.adapter_mode in {"wxautox4", "wxauto4_polling"} and not self.contact_whitelist:
            raise ValueError("启用真实微信适配器前必须配置 CONTACT_WHITELIST。")
        if self.adapter_mode in {"wxautox4", "wxauto4_polling"} and not self.wx_account_nickname:
            raise ValueError("启用真实微信适配器前必须配置 WX_ACCOUNT_NICKNAME 锁定登录账号。")
        if self.adapter_mode == "wxauto4_global_readonly" and not self.wx_account_nickname:
            raise ValueError("启用全局只读扫描前必须配置 WX_ACCOUNT_NICKNAME 锁定登录账号。")
        if self.adapter_mode == "wxauto4_global_readonly" and self.send_enabled:
            raise ValueError("全局扫描适配器是只读采集层，禁止配置 SEND_ENABLED=true。")
        if self.adapter_mode == "wxauto4_global_readonly" and self.contact_whitelist:
            raise ValueError(
                "全局只读扫描不使用 CONTACT_WHITELIST；请留空，身份会先进入隔离确认。"
            )
        if self.adapter_mode == "wxauto4_global_readonly" and not self.wx_global_parking_chat:
            raise ValueError("全局只读扫描必须配置 WX_GLOBAL_PARKING_CHAT。")
        if not 0.5 <= self.wx_global_poll_seconds <= 30:
            raise ValueError("WX_GLOBAL_POLL_SECONDS 必须在 0.5—30 秒之间。")
        if self.adapter_mode == "wxauto4_polling" and len(self.contact_whitelist) != 1:
            raise ValueError("免费微信读取模式必须且只能配置一个联系人。")
        if len(set(self.contact_whitelist)) != len(self.contact_whitelist):
            raise ValueError("CONTACT_WHITELIST 不能包含重复备注名。")
        if not 8_000 <= self.api_context_char_budget <= 60_000:
            raise ValueError("API_CONTEXT_CHAR_BUDGET 必须在 8000—60000 之间。")
        if not 0 <= self.debounce_seconds <= 30:
            raise ValueError("DEBOUNCE_SECONDS 必须在 0—30 秒之间。")
        if not 60 <= self.draft_ttl_seconds <= 86_400:
            raise ValueError("DRAFT_TTL_SECONDS 必须在 60—86400 秒之间。")
        if self.model_provider == "opencode_go":
            if self.deepseek_base_url != OPENCODE_GO_BASE_URL:
                raise ValueError("OpenCode Go API 地址必须使用程序内置固定地址。")
        else:
            endpoint = urlparse(self.deepseek_base_url)
            if not self.allow_custom_model_endpoint and (
                endpoint.scheme != "https" or endpoint.hostname != "api.deepseek.com"
            ):
                raise ValueError("默认只允许官方 HTTPS DeepSeek API 地址。")
        if self.adapter_mode in {"wxautox4", "wxauto4_polling"} and self.send_enabled:
            if not self.wx_test_account_mode:
                raise ValueError("首版真实微信外发只允许测试账号验收模式。")
            if not self.wx_live_validated:
                raise ValueError("测试账号读取与联系人绑定预检尚未完成。")
            if self.wx_live_unlock != "ENABLE_REAL_WECHAT_SEND":
                raise ValueError("真实微信外发缺少显式 WX_LIVE_UNLOCK。")
        if self.adapter_mode == "wxauto4_polling" and self.send_enabled:
            if not self.wx_send_contact_key:
                raise ValueError("免费微信外发必须显式配置 WX_SEND_CONTACT_KEY。")
            if self.wx_polling_send_unlock != "ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT":
                raise ValueError("免费微信外发缺少专用解锁短语。")
        if require_api and self.model_provider == "opencode_go":
            if not self.opencode_go_api_key:
                raise ValueError(
                    "缺少 OPENCODE_GO_API_KEY。请写入本机 .env，不要发到聊天中。"
                )
            if self.cloud_provider_ack != "opencode_go":
                raise ValueError(
                    "切换云端处理方后尚未确认；请设置 CLOUD_PROVIDER_ACK=opencode_go。"
                )
        elif require_api and not self.deepseek_api_key:
            raise ValueError("缺少 DEEPSEEK_API_KEY。请写入本机 .env，不要发到聊天中。")
        if require_api and not self.allow_cloud_processing:
            raise ValueError("云端处理尚未授权；请先阅读隐私说明再显式开启。")
