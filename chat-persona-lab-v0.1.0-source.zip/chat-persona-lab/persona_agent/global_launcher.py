"""Explicit entry point for the foreground, experimental read-only scanner."""
from pathlib import Path
import os

from .config import AppConfig
from .db_backup import backup_database


def readonly_overrides() -> dict[str, str]:
    return {
        'CHAT_ADAPTER': 'wxauto4_global_readonly',
        'SEND_ENABLED': 'false',
        'CONTACT_WHITELIST': ' ',
        'WX_LIVE_VALIDATED': 'false',
        'WX_TEST_ACCOUNT_MODE': 'false',
        'WX_LIVE_UNLOCK': ' ',
        'WX_SEND_CONTACT_KEY': ' ',
        'WX_POLLING_SEND_UNLOCK': ' ',
    }


def main() -> None:
    root = Path.cwd()
    config = AppConfig.from_root(root)
    print('全局只读扫描会持续切换微信会话，只能在专用虚拟机或副机运行。')
    print('请先停止其他实例，并清零所有可见、可计数的会话未读。')
    if input('完成后输入“已清零”继续：').strip() != '已清零':
        raise SystemExit('已取消。')
    backup_database(config.db_path, config.data_dir / 'backups')
    os.environ.update(readonly_overrides())
    from .__main__ import main as run
    run()


if __name__ == '__main__':
    main()
