from __future__ import annotations

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from .models import ProfileItem


MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
DOC_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
SECTION_CONTEXT_PREFIX = "章节："


def _shared_strings(archive: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    values: list[str] = []
    for item in root.findall(f"{{{MAIN_NS}}}si"):
        values.append("".join(node.text or "" for node in item.iter(f"{{{MAIN_NS}}}t")))
    return values


def _sheet_targets(archive: zipfile.ZipFile) -> list[tuple[str, str]]:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    rel_map = {
        rel.attrib["Id"]: rel.attrib["Target"]
        for rel in relationships.findall(f"{{{PKG_REL_NS}}}Relationship")
    }
    output: list[tuple[str, str]] = []
    for sheet in workbook.findall(f".//{{{MAIN_NS}}}sheet"):
        rel_id = sheet.attrib[f"{{{DOC_REL_NS}}}id"]
        target = rel_map[rel_id].replace("\\", "/")
        if target.startswith("/"):
            target = target.lstrip("/")
        elif not target.startswith("xl/"):
            target = f"xl/{target}"
        output.append((sheet.attrib["name"], target))
    return output


def _column_index(cell_reference: str) -> int:
    letters = re.match(r"[A-Z]+", cell_reference)
    if not letters:
        return 0
    value = 0
    for char in letters.group(0):
        value = value * 26 + (ord(char) - 64)
    return value - 1


def _cell_text(cell: ET.Element, shared: list[str]) -> str:
    cell_type = cell.attrib.get("t", "")
    if cell_type == "inlineStr":
        return "".join(node.text or "" for node in cell.iter(f"{{{MAIN_NS}}}t"))
    value_node = cell.find(f"{{{MAIN_NS}}}v")
    value = "" if value_node is None else (value_node.text or "")
    if cell_type == "s" and value:
        try:
            return shared[int(value)]
        except (ValueError, IndexError):
            return value
    if cell_type == "b":
        return "是" if value == "1" else "否"
    return value


def load_profile_items(
    path: Path,
    allowed_prefixes: tuple[str, ...] = (),
) -> list[ProfileItem]:
    """Load every populated profile row while preserving its local section.

    ``allowed_prefixes`` is retained for API compatibility, but filtering is no
    longer performed while reading the workbook.  Loading and disclosure are
    deliberately separate operations: all 16 sheets stay available locally,
    while :class:`ProfileRetriever` decides which rows are safe and relevant for
    a particular model request.

    A one-cell row is retained as an item and becomes the section context for
    subsequent structured rows.  The context is appended as a synthetic final
    cell prefixed with ``章节：`` so existing ``ProfileItem`` consumers remain
    compatible and the original column positions are unchanged.
    """
    if not path.exists():
        raise FileNotFoundError(f"人格档案不存在: {path}")
    # Compatibility argument only.  Local ingestion is intentionally complete.
    _ = allowed_prefixes
    items: list[ProfileItem] = []
    with zipfile.ZipFile(path) as archive:
        shared = _shared_strings(archive)
        for sheet_name, target in _sheet_targets(archive):
            root = ET.fromstring(archive.read(target))
            section_context = ""
            for row in root.findall(f".//{{{MAIN_NS}}}row"):
                row_number = int(row.attrib.get("r", "0") or 0)
                indexed: dict[int, str] = {}
                for cell in row.findall(f"{{{MAIN_NS}}}c"):
                    text = re.sub(r"\s+", " ", _cell_text(cell, shared)).strip()
                    if text:
                        indexed[_column_index(cell.attrib.get("r", "A1"))] = text
                if not indexed:
                    continue
                width = max(indexed) + 1
                cells = [indexed.get(index, "") for index in range(width)]
                populated = [cell for cell in cells if cell]
                if len(populated) == 1:
                    section_context = populated[0]
                    items.append(ProfileItem(sheet=sheet_name, row=row_number, cells=cells))
                    continue
                if section_context:
                    cells.append(f"{SECTION_CONTEXT_PREFIX}{section_context}")
                items.append(ProfileItem(sheet=sheet_name, row=row_number, cells=cells))
    return items
