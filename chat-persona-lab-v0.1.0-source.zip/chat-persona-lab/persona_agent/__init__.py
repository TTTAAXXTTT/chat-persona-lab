"""Local, approval-gated WeChat persona reply assistant."""

__version__ = "0.1.0"
