from __future__ import annotations

import hashlib
import json
import queue
import threading
import time
from datetime import datetime
from typing import Any

from .adapters import ChatAdapter, SendBlockedError
from .config import AppConfig
from .deepseek import DraftModel
from .models import AdapterEnvelope, IncomingMessage, ModelDraft, wechat_account_scope
from .policy import RiskEngine
from .retrieval import ProfileRetriever, retrieve_examples
from .style_memory import StyleFingerprint
from .store import Store


class PersonaService:
    _GLOBAL_READONLY_MODES = {
        "wxauto4_global_readonly",
        # Test-only compatibility name used by the adapter contract suite.
        "global_private_capture",
    }
    _GLOBAL_INCOMING_SOURCES = {
        "wxauto4_global_readonly",
        "global_private_capture",
    }
    def __init__(
        self,
        *,
        config: AppConfig,
        store: Store,
        model: DraftModel,
        profile_retriever: ProfileRetriever,
        adapter: ChatAdapter,
        style_fingerprint: StyleFingerprint | None = None,
    ):
        self.config = config
        self.store = store
        self.model = model
        self.profile_retriever = profile_retriever
        self.style_fingerprint = style_fingerprint
        self.adapter = adapter
        self.risk_engine = RiskEngine()
        self._queue: queue.Queue[IncomingMessage | None] = queue.Queue(maxsize=1000)
        self._worker: threading.Thread | None = None
        self._started = False
        self._lifecycle_lock = threading.Lock()
        self._startup_status = "stopped"
        self._startup_error = ""
        self._startup_thread: threading.Thread | None = None
        self._stop_requested = False
        self._worker_errors = 0
        self._last_worker_error = ""
        self._recovery: dict[str, int] = {}
        self._approval_lock = threading.Lock()
        self._live_send_capable = bool(
            config.send_enabled
            and config.adapter_mode in {"wxautox4", "wxauto4_polling"}
        )
        # A real-WeChat process always starts paused.  This state is memory-only,
        # so every restart safely returns the visible send switch to OFF.
        self._runtime_send_enabled = bool(
            config.send_enabled and not self._live_send_capable
        )

    def start(self) -> None:
        if not self._claim_start():
            return
        self._start_claimed()

    def start_background(self) -> None:
        """Start workers and the UI adapter without blocking the HTTP server."""
        if not self._claim_start():
            return
        thread = threading.Thread(
            target=self._background_start,
            name="service-startup",
            daemon=True,
        )
        with self._lifecycle_lock:
            self._startup_thread = thread
        thread.start()

    def _claim_start(self) -> bool:
        with self._lifecycle_lock:
            if self._startup_status in {"starting", "running"}:
                return False
            if self._worker is not None and self._worker.is_alive():
                raise RuntimeError(
                    "上一个草稿 worker 仍在退出；为避免并发生成，当前拒绝重新启动"
                )
            self._startup_status = "starting"
            self._startup_error = ""
            self._stop_requested = False
            return True

    def _background_start(self) -> None:
        try:
            self._start_claimed()
        except Exception:
            # The failure is retained in state() so the local page remains useful.
            return

    def _start_claimed(self) -> None:
        try:
            self._recovery = self.store.recover_incomplete()
            if self.config.adapter_mode in {"wxautox4", "wxauto4_polling"}:
                bindings: dict[str, dict[str, str]] = {}
                for alias in self.config.contact_whitelist:
                    contact = self.store.contact_for_alias(alias)
                    if contact is None:
                        raise ValueError(f"微信备注名尚未绑定联系人: {alias}")
                    if (
                        self.config.send_enabled
                        and self.config.adapter_mode == "wxauto4_polling"
                        and str(contact["contact_key"])
                        != self.config.wx_send_contact_key
                    ):
                        raise ValueError(
                            "当前数据库联系人绑定与 WX_SEND_CONTACT_KEY 不一致，已拒绝启动外发"
                        )
                    if self.config.send_enabled and (
                        not bool(contact["enabled"])
                        or not bool(contact["live_read_enabled"])
                    ):
                        raise ValueError("唯一发送目标已停用或未开启自动读取")
                    bindings[alias] = {
                        "contact_key": str(contact["contact_key"]),
                        "display_name": str(contact["display_name"]),
                    }
                self.adapter.configure_bindings(bindings)
            with self._lifecycle_lock:
                if self._stop_requested:
                    raise RuntimeError("服务启动已取消")
                self._worker = threading.Thread(
                    target=self._work, name="draft-worker", daemon=True
                )
                self._started = True
            self._worker.start()
            for recovered in self.store.received_incoming():
                try:
                    self.enqueue(recovered)
                except Exception as error:
                    self._worker_errors += 1
                    self._last_worker_error = f"恢复消息失败: {error}"[:500]
                    break
            self._start_adapter_with_retry()
            with self._lifecycle_lock:
                if self._stop_requested:
                    raise RuntimeError("服务启动已取消")
                self._startup_status = "running"
        except Exception as error:
            self._stop_components()
            with self._lifecycle_lock:
                if self._stop_requested:
                    self._startup_status = "stopped"
                    self._startup_error = ""
                else:
                    self._startup_status = "failed"
                    self._startup_error = str(error)[:500]
            raise

    def _start_adapter_with_retry(self) -> None:
        attempts = 3 if self.config.adapter_mode in self._GLOBAL_READONLY_MODES else 1
        last_error: Exception | None = None
        for attempt in range(attempts):
            try:
                self.adapter.start(self.receive_adapter_event)
                return
            except Exception as error:
                last_error = error
                try:
                    self.adapter.stop()
                except Exception:
                    pass
                if attempt + 1 >= attempts:
                    break
                # Only the isolated read-only acquisition mode reconnects.  The
                # delay is bounded and interruptible; send-capable adapters keep
                # their existing single-attempt, fail-closed startup behavior.
                delay = 0.05 * (2**attempt)
                deadline = time.monotonic() + delay
                while time.monotonic() < deadline:
                    with self._lifecycle_lock:
                        if self._stop_requested:
                            raise RuntimeError("服务启动已取消") from error
                    time.sleep(min(0.01, max(0.0, deadline - time.monotonic())))
        if last_error is None:
            raise RuntimeError("消息适配器未能启动")
        raise last_error

    def stop(self) -> None:
        with self._approval_lock:
            self._runtime_send_enabled = False
        with self._lifecycle_lock:
            self._stop_requested = True
            startup_thread = self._startup_thread
        self._stop_components()
        if (
            startup_thread is not None
            and startup_thread is not threading.current_thread()
            and startup_thread.is_alive()
        ):
            startup_thread.join(timeout=3)
        with self._lifecycle_lock:
            if startup_thread is None or not startup_thread.is_alive():
                self._startup_status = "stopped"
                self._startup_error = ""

    def _stop_components(self) -> None:
        with self._lifecycle_lock:
            if not self._started:
                return
            self._started = False
            worker = self._worker
        try:
            self.adapter.stop()
        except Exception as error:
            self._worker_errors += 1
            self._last_worker_error = f"停止消息适配器失败: {error}"[:500]
        finally:
            if worker is not None and worker.is_alive():
                try:
                    self._queue.put(None, timeout=0.5)
                except queue.Full:
                    pass
                worker.join(timeout=3)

    def require_ready(self) -> None:
        with self._lifecycle_lock:
            status = self._startup_status
            error = self._startup_error
        if status != "running":
            detail = f"：{error}" if status == "failed" and error else ""
            raise RuntimeError(f"微信监听服务当前状态为 {status}{detail}")

    def _accept_incoming(self, incoming: IncomingMessage) -> bool:
        source = str(incoming.metadata.get("source", "direct-test"))
        known = self.store.contact_for_key(incoming.contact_key)
        if source in self._GLOBAL_INCOMING_SOURCES:
            chat_type = str(incoming.metadata.get("chat_type", "")).strip().lower()
            peer_type = str(incoming.metadata.get("peer_type", "friend")).strip().lower()
            if chat_type != "friend" or peer_type != "friend":
                return False
            if known is None:
                raise ValueError("全局微信消息缺少已批准的联系人身份绑定")
        if known is None and source in {"wxautox4", "wxauto4_polling"}:
            raise ValueError("微信消息缺少已确认的联系人绑定")
        if known is None and source == "jsonl":
            raise ValueError("JSONL 消息必须提供已存在的 contact_key")
        if known is not None:
            incoming.contact_name = str(known["display_name"])
            if source not in {"manual-test", "direct-test"} and (
                not bool(known["enabled"]) or not bool(known["live_read_enabled"])
            ):
                return False
        if not self.store.register_incoming(incoming):
            return False
        return True

    def receive_adapter_event(self, event: IncomingMessage | AdapterEnvelope) -> bool:
        """Route legacy bound events and untrusted global envelopes separately."""

        if isinstance(event, IncomingMessage):
            return self.enqueue(event)
        if isinstance(event, AdapterEnvelope):
            return self._route_adapter_envelope(event)
        raise TypeError("消息适配器返回了未知事件类型")

    @staticmethod
    def _clean_envelope_value(value: object, *, field: str, limit: int = 500) -> str:
        if not isinstance(value, str):
            raise ValueError(f"{field} 必须是字符串")
        cleaned = value.strip()
        if not cleaned or len(cleaned) > limit or any(ord(char) < 32 for char in cleaned):
            raise ValueError(f"{field} 为空、过长或包含控制字符")
        return cleaned

    def _route_adapter_envelope(self, envelope: AdapterEnvelope) -> bool:
        event_id = self._clean_envelope_value(
            envelope.event_id, field="event_id", limit=1000
        )
        account_scope = self._clean_envelope_value(
            envelope.account_scope, field="account_scope", limit=200
        )
        adapter_kind = self._clean_envelope_value(
            envelope.adapter_kind, field="adapter_kind", limit=100
        ).lower()
        external_identity = self._clean_envelope_value(
            envelope.external_identity, field="external_identity", limit=1000
        )
        identity_quality = self._clean_envelope_value(
            envelope.identity_quality, field="identity_quality", limit=50
        ).lower()
        adapter_alias = self._clean_envelope_value(
            envelope.adapter_alias, field="adapter_alias", limit=200
        )
        chat_type = self._clean_envelope_value(
            envelope.chat_type, field="chat_type", limit=50
        ).lower()
        sender_role = self._clean_envelope_value(
            envelope.sender_role, field="sender_role", limit=50
        ).lower()
        message_type = self._clean_envelope_value(
            envelope.message_type, field="message_type", limit=50
        ).lower()
        if not isinstance(envelope.text, str) or len(envelope.text) > 4000:
            raise ValueError("适配器消息正文必须是至多 4000 字的字符串")
        text = envelope.text.strip()
        if not isinstance(envelope.timestamp, datetime):
            raise ValueError("适配器消息 timestamp 必须是 datetime")
        if not isinstance(envelope.metadata, dict):
            raise ValueError("适配器 metadata 必须是 JSON 对象")
        try:
            json.dumps(envelope.metadata, ensure_ascii=False)
        except (TypeError, ValueError) as error:
            raise ValueError("适配器 metadata 必须可安全编码为 JSON") from error

        # Rebuild a normalized copy so storage and downstream hashes never depend
        # on whitespace/casing quirks supplied by a third-party driver.
        normalized = AdapterEnvelope(
            event_id=event_id,
            account_scope=account_scope,
            adapter_kind=adapter_kind,
            external_identity=external_identity,
            identity_quality=identity_quality,
            adapter_alias=adapter_alias,
            chat_type=chat_type,
            sender_role=sender_role,
            message_type=message_type,
            text=text,
            timestamp=envelope.timestamp,
            releasable=bool(envelope.releasable),
            metadata=dict(envelope.metadata),
        )
        observed_account_id = str(
            normalized.metadata.get("account_wechat_id", "") or ""
        ).strip()
        expected_scope = wechat_account_scope(
            self.config.wx_account_nickname, observed_account_id
        )
        observed_nickname = str(normalized.metadata.get("account_nickname", "")).strip()
        if (
            (
                adapter_kind == "wxauto4_global_readonly"
                and not observed_account_id
            )
            or not expected_scope
            or account_scope != expected_scope
            or observed_nickname != self.config.wx_account_nickname
        ):
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="account_mismatch",
                identity_key=None,
                releasable=False,
                retain_text=False,
            )
            return False
        if adapter_kind != self.config.adapter_mode:
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="adapter_kind_mismatch",
                identity_key=None,
                releasable=False,
                retain_text=False,
            )
            return False
        if chat_type != "friend":
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="excluded_chat_type",
                identity_key=None,
                releasable=False,
                retain_text=False,
            )
            return False
        if sender_role != "friend" or message_type != "text" or not text:
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="excluded_message_kind",
                identity_key=None,
                releasable=False,
                retain_text=False,
            )
            return False
        if identity_quality not in {"stable", "provider", "alias_only", "uia_runtime"}:
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="unsupported_identity_quality",
                identity_key=None,
                releasable=False,
                retain_text=False,
            )
            return False

        if adapter_kind == "wxauto4_global_readonly":
            session_identity = str(
                normalized.metadata.get("session_identity", "") or ""
            ).strip()
            run_generation = str(
                normalized.metadata.get("adapter_run_generation", "") or ""
            ).strip()
            expected_external_identity = ""
            if session_identity and run_generation:
                expected_external_identity = "session-uia-sha256:" + hashlib.sha256(
                    (
                        f"{account_scope}\x1f{adapter_alias}\x1f{session_identity}\x1f"
                        f"{run_generation}"
                    ).encode("utf-8")
                ).hexdigest()
            if (
                identity_quality != "uia_runtime"
                or not expected_external_identity
                or external_identity != expected_external_identity
            ):
                self.store.quarantine_adapter_envelope(
                    normalized,
                    reason="unstable_session_identity",
                    identity_key=None,
                    releasable=False,
                    retain_text=False,
                )
                return False

        event_key = self.store.adapter_event_key(normalized)
        if self.store.quarantined_event(event_key) is not None:
            return False

        identity = self.store.observe_adapter_identity(normalized)
        identity_key = str(identity["identity_key"])
        if str(identity["status"]) != "approved":
            self.store.quarantine_adapter_envelope(
                normalized,
                reason=(
                    "identity_conflict"
                    if str(identity["status"]) == "conflict"
                    else "unbound_identity"
                ),
                identity_key=identity_key,
                releasable=bool(normalized.releasable),
                retain_text=True,
            )
            return False
        if identity_quality == "alias_only":
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="identity_quality_manual_only",
                identity_key=identity_key,
                releasable=bool(normalized.releasable),
                retain_text=True,
            )
            return False
        if (
            str(identity["adapter_alias"]) != adapter_alias
            or str(identity["last_seen_alias"]) != adapter_alias
        ):
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="identity_alias_drift",
                identity_key=identity_key,
                releasable=False,
                retain_text=True,
            )
            return False
        contact_key = str(identity.get("contact_key") or "")
        contact = self.store.contact_for_key(contact_key) if contact_key else None
        if contact is None or not bool(contact["enabled"]) or not bool(
            contact["live_read_enabled"]
        ):
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="contact_disabled",
                identity_key=identity_key,
                releasable=bool(normalized.releasable),
                retain_text=True,
            )
            return False
        if str(contact["adapter_alias"] or "") != adapter_alias:
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="identity_contact_alias_mismatch",
                identity_key=identity_key,
                releasable=False,
                retain_text=True,
            )
            return False
        if not normalized.releasable:
            self.store.quarantine_adapter_envelope(
                normalized,
                reason="unstable_event_identity",
                identity_key=identity_key,
                releasable=False,
                retain_text=True,
            )
            return False

        # Binding an identity deliberately affects only future observations.
        # A replay of an event that was already quarantined must never bypass the
        # operator's explicit per-event release/reject decision.
        if self.store.quarantined_event(event_key) is not None:
            return False

        incoming = IncomingMessage(
            external_id=self.store.global_incoming_id(event_key),
            contact_name=str(contact["display_name"]),
            contact_key=contact_key,
            text=text,
            timestamp=normalized.timestamp,
            metadata={
                **dict(normalized.metadata),
                "source": "wxauto4_global_readonly",
                "chat_type": "friend",
                "peer_type": "friend",
                "adapter_kind": adapter_kind,
                "adapter_alias": adapter_alias,
                "identity_key": identity_key,
                "account_scope": account_scope,
                "external_identity": external_identity,
                "identity_quality": identity_quality,
            },
        )
        return self.enqueue(incoming)

    def enqueue(self, incoming: IncomingMessage) -> bool:
        if not self._accept_incoming(incoming):
            return False
        incoming.metadata["_accepted_monotonic"] = time.monotonic()
        try:
            self._queue.put_nowait(incoming)
        except queue.Full:
            self.store.release_incoming(incoming.external_id)
            self._worker_errors += 1
            self._last_worker_error = "内存队列已满；消息已保存在数据库并等待自动回捞"
        return True

    def _work(self) -> None:
        while True:
            incoming = self._queue.get()
            if incoming is None:
                return
            try:
                accepted_at = float(incoming.metadata.get("_accepted_monotonic", 0.0))
                remaining = self.config.debounce_seconds - (time.monotonic() - accepted_at)
                if remaining > 0:
                    self._stop_wait(remaining)
                self._generate_claimed(incoming)
            except Exception as error:
                # The per-message process stores generation failures. This last guard
                # prevents one bad event from terminating the listener worker.
                self._worker_errors += 1
                self._last_worker_error = str(error)[:500]
                retries = int(incoming.metadata.get("_worker_retries", 0))
                self.store.release_incoming(incoming.external_id)
                if retries < 1:
                    incoming.metadata["_worker_retries"] = retries + 1
                    try:
                        self.enqueue(incoming)
                    except Exception as retry_error:
                        self._last_worker_error = f"{error}; 重试入队失败: {retry_error}"[:500]
            finally:
                self._refill_received()

    def _refill_received(self) -> None:
        """Move database-backed overflow back into the FIFO as capacity returns."""
        available = max(0, self._queue.maxsize - self._queue.qsize())
        if not available:
            return
        for recovered in self.store.received_incoming(limit=min(available, 50)):
            if not self.enqueue(recovered):
                continue

    @staticmethod
    def _stop_wait(seconds: float) -> None:
        # Short debounce only; this intentionally does not perform network work.
        threading.Event().wait(seconds)

    def process(self, incoming: IncomingMessage) -> str | None:
        if not self._accept_incoming(incoming):
            return None
        return self._generate_claimed(incoming)

    def _generate_claimed(self, incoming: IncomingMessage) -> str | None:
        risk = self.risk_engine.assess(incoming.text)
        if risk.action == "blocked":
            return self.store.create_draft(
                incoming,
                ModelDraft(
                    messages=[],
                    confidence=1.0,
                    needs_user_input=True,
                    uncertainties=["命中强制人工接管条件"],
                ),
                risk,
                model="policy-engine",
                status="blocked",
            )

        contact = self.store.contact_for_key(incoming.contact_key) or {
            "relationship": "待确认"
        }
        relationship = str(contact.get("relationship", "待确认"))
        profile_items = self.profile_retriever.search(incoming.text, relationship)
        same_contact_examples = self.store.examples_for_contact(incoming.contact_key)
        examples = retrieve_examples(incoming.text, same_contact_examples)
        recent_context = self.store.recent_context(
            incoming.contact_key,
            before_timestamp=incoming.timestamp,
            window_hours=72,
        )
        if (
            recent_context
            and recent_context[-1].get("sender_role") == "other"
            and recent_context[-1].get("content") == incoming.text
        ):
            recent_context = recent_context[:-1]
        selected_model = self.model.model_name
        try:
            model_draft = self.model.generate(
                contact_name=incoming.contact_name,
                relationship=relationship,
                incoming_text=incoming.text,
                current_message_time=incoming.timestamp.isoformat(),
                recent_context=recent_context,
                profile_items=profile_items,
                examples=examples,
                risk=risk,
                private_terms=[
                    str(item["display_name"])
                    for item in self.store.list_contacts()
                    if item.get("display_name")
                ]
                + [
                    str(item["adapter_alias"])
                    for item in self.store.list_contacts()
                    if item.get("adapter_alias")
                ]
                    + list(self.config.private_terms),
                style_fingerprint=(
                    self.style_fingerprint.to_prompt_payload()
                    if self.style_fingerprint is not None
                    else None
                ),
            )
            safe, output_reasons = self.risk_engine.generated_text_safe(model_draft.messages)
            used_model = model_draft.used_model or selected_model
            if not safe:
                model_draft.uncertainties.extend(output_reasons)
                return self.store.create_draft(
                    incoming,
                    model_draft,
                    risk,
                    model=used_model,
                    status="blocked",
                    error="草稿输出命中人工接管规则",
                )
            return self.store.create_draft(
                incoming,
                model_draft,
                risk,
                model=used_model,
                status="pending",
            )
        except Exception as error:
            return self.store.create_draft(
                incoming,
                ModelDraft(
                    messages=[],
                    confidence=0.0,
                    needs_user_input=True,
                    uncertainties=["模型生成失败，请检查本机配置"],
                ),
                risk,
                model=selected_model,
                status="generation_error",
                error=str(error)[:2000],
            )

    def submit_manual_incoming(
        self,
        contact_key: str,
        text: str,
        contact_name: str = "",
    ) -> str:
        contact_key = contact_key.strip()
        contact_name = contact_name.strip()
        text = text.strip()
        if not text:
            raise ValueError("消息内容不能为空")
        if len(text) > 4000:
            raise ValueError("单条测试消息不能超过 4000 个字符")
        known = self.store.contact_for_key(contact_key) if contact_key else None
        if known is not None:
            contact_name = str(known["display_name"])
        elif contact_name:
            contact_key = "manual:" + hashlib.sha256(
                contact_name.encode("utf-8")
            ).hexdigest()[:24]
        else:
            raise ValueError("请选择联系人；无历史数据时可填写测试联系人名称")
        seed = f"manual|{contact_key}|{datetime.now().isoformat()}|{text}"
        incoming = IncomingMessage(
            external_id=hashlib.sha256(seed.encode("utf-8")).hexdigest(),
            contact_name=contact_name,
            contact_key=contact_key,
            text=text,
            timestamp=datetime.now(),
            metadata={"source": "manual-test"},
        )
        if not self.enqueue(incoming):
            raise RuntimeError("重复的测试消息已忽略")
        return incoming.external_id

    @staticmethod
    def _normalize_messages(messages: list[str]) -> list[str]:
        if not isinstance(messages, list) or not all(
            isinstance(value, str) for value in messages
        ):
            raise ValueError("确认发送时 messages 必须是字符串数组")
        normalized = [" ".join(value.split()).strip() for value in messages]
        normalized = [value for value in normalized if value]
        if not 1 <= len(normalized) <= 3:
            raise ValueError("确认发送时必须保留 1—3 条非空短消息")
        if any(len(value) > 500 for value in normalized):
            raise ValueError("单条消息不能超过 500 个字符")
        return normalized

    def approve(
        self,
        draft_id: str,
        messages: list[str],
        destination_confirmation: str = "",
    ) -> dict[str, Any]:
        messages = self._normalize_messages(messages)
        with self._approval_lock:
            return self._approve_locked(
                draft_id,
                messages,
                destination_confirmation.strip(),
            )

    def _approve_locked(
        self,
        draft_id: str,
        messages: list[str],
        destination_confirmation: str,
    ) -> dict[str, Any]:
        draft = self.store.get_draft(draft_id)
        if draft["status"] != "pending":
            raise RuntimeError(f"草稿当前状态为 {draft['status']}，不能重复确认")
        safe, reasons = self.risk_engine.generated_text_safe(messages)
        if not safe:
            raise ValueError("编辑后的内容命中人工接管规则：" + "；".join(reasons))
        contact = self.store.contact_for_key(str(draft["contact_key"]))
        if self._live_send_capable and not self._runtime_send_enabled:
            raise PermissionError("真实发送开关当前关闭；草稿仍保留在待确认队列")
        if self._live_send_capable:
            if str(draft.get("incoming_source", "")) != self.config.adapter_mode:
                raise PermissionError("只有真实微信收到的草稿可以外发；手工模拟草稿永不外发")
            if contact is None or not bool(contact["enabled"]):
                self._runtime_send_enabled = False
                raise PermissionError("发送目标联系人不存在或已停用")
            if not bool(contact["live_read_enabled"]):
                self._runtime_send_enabled = False
                raise PermissionError("发送目标未启用真实微信读取，已拒绝外发")
            adapter_alias = str(contact.get("adapter_alias") or "")
            if adapter_alias not in self.config.contact_whitelist:
                self._runtime_send_enabled = False
                raise PermissionError("发送目标备注名不在当前唯一白名单内")
            if destination_confirmation != adapter_alias:
                raise PermissionError(f"请准确输入收件人备注名 {adapter_alias} 后再发送")
            if self.config.adapter_mode == "wxauto4_polling" and (
                str(draft["contact_key"]) != self.config.wx_send_contact_key
                or (adapter_alias,) != self.config.contact_whitelist
            ):
                self._runtime_send_enabled = False
                raise PermissionError("免费微信外发仅允许显式配置并完成验收的唯一目标")
        if not self.store.claim_draft_for_approval(draft_id, messages, datetime.min):
            current = self.store.get_draft(draft_id)
            raise RuntimeError(f"草稿已失效，当前状态为 {current['status']}")

        if not self.config.send_enabled:
            self.store.transition_draft(draft_id, ("approved",), "approved_not_sent")
            return self.store.get_draft(draft_id)

        if contact is None or not bool(contact["enabled"]):
            if self._live_send_capable:
                self._runtime_send_enabled = False
            self.store.transition_draft(
                draft_id,
                ("approved",),
                "send_blocked",
                error="联系人不存在或已停用；没有执行发送",
            )
            return self.store.get_draft(draft_id)
        if not self.adapter.destination_matches(
            str(contact["contact_key"]),
            str(contact["display_name"]),
            str(contact.get("adapter_alias") or ""),
        ):
            if self._live_send_capable:
                self._runtime_send_enabled = False
            self.store.transition_draft(
                draft_id,
                ("approved",),
                "send_blocked",
                error="联系人绑定在启动后发生变化；没有执行发送，请重启后重试",
            )
            return self.store.get_draft(draft_id)
        if not self.store.transition_draft(draft_id, ("approved",), "sending"):
            raise RuntimeError("发送状态锁定失败")
        current_index: int | None = None
        confirmed_count = 0
        try:
            self.store.prepare_send_attempts(draft_id, str(draft["send_key"]), messages)
            for index, text in enumerate(messages):
                current_index = index
                if not self.store.transition_send_attempt(
                    draft_id, index, "prepared", "attempting"
                ):
                    raise RuntimeError("逐条发送状态锁定失败")
                self.adapter.send_text(
                    str(draft["contact_key"]),
                    draft["contact_name"],
                    text,
                    f"{draft['send_key']}:{index}",
                )
                if not self.store.transition_send_attempt(
                    draft_id, index, "attempting", "confirmed"
                ):
                    raise RuntimeError("发送结果写入失败")
                confirmed_count += 1
                self.store.append_outgoing_message(
                    draft_id=draft_id,
                    contact_key=str(draft["contact_key"]),
                    message_index=index,
                    content=text,
                )
            final_status = (
                "outbox_written" if self.config.adapter_mode == "jsonl" else "sent"
            )
            self.store.transition_draft(draft_id, ("sending",), final_status)
        except SendBlockedError as error:
            # The adapter guarantees that this exception is only raised before
            # crossing its external SendMsg call boundary.  This attempt is known
            # not to have sent and therefore must not be labelled "uncertain".
            if self._live_send_capable:
                self._runtime_send_enabled = False
            if current_index is not None:
                self.store.transition_send_attempt(
                    draft_id,
                    current_index,
                    "attempting",
                    "blocked",
                    error=str(error)[:2000],
                )
            blocked_status = "partial_sent" if confirmed_count else "send_blocked"
            self.store.transition_draft(
                draft_id,
                ("sending",),
                blocked_status,
                error=str(error)[:2000],
            )
        except Exception as error:
            # Never retry an uncertain send automatically.
            if self._live_send_capable:
                self._runtime_send_enabled = False
            if current_index is not None:
                self.store.transition_send_attempt(
                    draft_id,
                    current_index,
                    "attempting",
                    "uncertain",
                    error=str(error)[:2000],
                )
            if confirmed_count:
                failure_status = "partial_sent"
            else:
                failure_status = "uncertain" if current_index is not None else "send_blocked"
            self.store.transition_draft(
                draft_id,
                ("sending",),
                failure_status,
                error=str(error)[:2000],
            )
        return self.store.get_draft(draft_id)

    def set_runtime_send_enabled(self, enabled: bool) -> bool:
        """Set the memory-only real-send switch without approving any draft."""
        if not isinstance(enabled, bool):
            raise ValueError("enabled 必须是 JSON boolean")
        with self._approval_lock:
            if enabled and not self._live_send_capable:
                raise PermissionError("当前启动方式不具备真实微信发送能力")
            self._runtime_send_enabled = enabled if self._live_send_capable else False
            return self._runtime_send_enabled

    def bind_adapter_identity(
        self,
        *,
        identity_key: str,
        expected_alias: str,
        contact_key: str | None,
        display_name: str,
        relationship: str,
        create_new: bool,
        enable_live_read: bool,
    ) -> dict[str, Any]:
        self._require_global_readonly_mode()
        return self.store.bind_adapter_identity(
            identity_key=identity_key,
            expected_alias=expected_alias,
            contact_key=contact_key,
            display_name=display_name,
            relationship=relationship,
            create_new=create_new,
            enable_live_read=enable_live_read,
        )

    def release_quarantined_event(self, event_key: str) -> dict[str, Any]:
        self._require_global_readonly_mode()
        self.require_ready()
        incoming, created = self.store.promote_quarantined_event(event_key.strip())
        # Also try to claim a previously promoted-but-not-yet-queued `received`
        # row. register_incoming is an atomic status claim, so repeated clicks or
        # concurrent releases still enqueue at most once.
        queued = self.enqueue(incoming)
        return {
            "event_key": event_key.strip(),
            "incoming_id": incoming.external_id,
            "created": created,
            "queued": queued,
        }

    def reject_quarantined_event(self, event_key: str) -> bool:
        self._require_global_readonly_mode()
        event_key = event_key.strip()
        if not event_key:
            raise ValueError("隔离消息 event_key 不能为空")
        return self.store.reject_quarantined_event(event_key)

    def _require_global_readonly_mode(self) -> None:
        if self.config.adapter_mode not in self._GLOBAL_READONLY_MODES:
            raise PermissionError("身份隔离操作只允许在全局只读采集模式中执行")

    def reject(self, draft_id: str) -> dict[str, Any]:
        if not self.store.transition_draft(draft_id, ("pending",), "rejected"):
            raise RuntimeError("只有待确认草稿可以拒绝")
        return self.store.get_draft(draft_id)

    def select_model(self, model_name: str) -> str:
        selector = getattr(self.model, "select_model", None)
        if not callable(selector):
            raise RuntimeError("当前模型客户端不支持运行时切换")
        selector(model_name)
        return self.model.model_name

    def state(self) -> dict[str, Any]:
        with self._lifecycle_lock:
            startup_status = self._startup_status
            startup_error = self._startup_error
        try:
            adapter_health = self.adapter.health()
        except Exception as error:
            adapter_health = {
                "mode": self.config.adapter_mode,
                "running": False,
                "last_error": f"读取适配器状态失败: {error}"[:500],
            }
        if (
            self._live_send_capable
            and self._runtime_send_enabled
            and not bool(adapter_health.get("running"))
        ):
            with self._approval_lock:
                self._runtime_send_enabled = False
        knowledge = self.store.knowledge_summary()
        if self.style_fingerprint is not None:
            knowledge["style_fingerprint"] = {
                "version": self.style_fingerprint.version,
                "source_contact_count": self.style_fingerprint.source_contact_count,
                "self_message_count": self.style_fingerprint.self_message_count,
            }
        return {
            "counts": self.store.counts(),
            "knowledge": knowledge,
            "adapter": adapter_health,
            "service": {"status": startup_status, "startup_error": startup_error},
            "model": self.model.model_name,
            "provider": str(getattr(self.model, "provider_name", "offline")),
            "available_models": list(
                getattr(self.model, "available_models", (self.model.model_name,))
            ),
            "api_key_configured": bool(
                getattr(
                    self.model,
                    "api_key_configured",
                    bool(self.config.deepseek_api_key),
                )
            ),
            # Compatibility alias: send_enabled remains the immutable process
            # capability.  New clients use send_capable/runtime_send_enabled.
            "send_enabled": self.config.send_enabled,
            "send_capable": self._live_send_capable,
            "runtime_send_enabled": self._runtime_send_enabled,
            "send_target": (
                {
                    "account_nickname": self.config.wx_account_nickname,
                    "adapter_alias": (
                        self.config.contact_whitelist[0]
                        if len(self.config.contact_whitelist) == 1
                        else ""
                    ),
                    "contact_key": (
                        self.config.wx_send_contact_key
                        if self.config.adapter_mode == "wxauto4_polling"
                        else ""
                    ),
                }
                if self.config.send_enabled
                and self.config.adapter_mode in {"wxauto4_polling", "wxautox4"}
                else None
            ),
            "approval_required": True,
            "queue_size": self._queue.qsize(),
            "worker_errors": self._worker_errors,
            "last_worker_error": self._last_worker_error,
            "recovery": self._recovery,
            "per_draft_confirmation_required": True,
        }
