from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import os
import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import AppConfig
from .models import AdapterEnvelope, IncomingMessage


AdapterEvent = IncomingMessage | AdapterEnvelope
IncomingCallback = Callable[[AdapterEvent], object]


class SendBlockedError(PermissionError):
    """The adapter rejected a send before invoking the external send operation."""


class SendUncertainError(RuntimeError):
    """The external send operation was invoked but its outcome is not confirmed."""


class ChatAdapter(ABC):
    def configure_bindings(self, bindings: dict[str, dict[str, str]]) -> None:
        if bindings:
            raise RuntimeError("当前适配器不接受微信联系人绑定")

    def destination_matches(
        self,
        contact_key: str,
        contact_name: str,
        adapter_alias: str,
    ) -> bool:
        return True

    @abstractmethod
    def start(self, callback: IncomingCallback) -> None: ...

    @abstractmethod
    def stop(self) -> None: ...

    @abstractmethod
    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None: ...

    @abstractmethod
    def health(self) -> dict[str, object]: ...


class MockAdapter(ChatAdapter):
    def __init__(self):
        self.callback: IncomingCallback | None = None
        self.sent: list[dict[str, str]] = []

    def start(self, callback: IncomingCallback) -> None:
        self.callback = callback

    def stop(self) -> None:
        self.callback = None

    def emit(self, incoming: IncomingMessage) -> None:
        if self.callback is None:
            raise RuntimeError("MockAdapter 尚未启动")
        self.callback(incoming)

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        self.sent.append(
            {
                "contact_key": contact_key,
                "contact_name": contact_name,
                "text": text,
                "send_key": send_key,
            }
        )

    def health(self) -> dict[str, object]:
        return {"mode": "mock", "running": self.callback is not None, "sent_count": len(self.sent)}


class JsonlFileAdapter(ChatAdapter):
    def __init__(self, inbox_path: Path, outbox_path: Path, poll_seconds: float = 0.7):
        self.inbox_path = inbox_path
        self.outbox_path = outbox_path
        self.poll_seconds = poll_seconds
        self.callback: IncomingCallback | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._write_lock = threading.Lock()
        self._malformed_lines = 0
        self._callback_failures = 0
        self._truncations = 0
        self._replacements = 0
        self._last_error = ""

    def start(self, callback: IncomingCallback) -> None:
        self.callback = callback
        self._stop.clear()
        self.inbox_path.parent.mkdir(parents=True, exist_ok=True)
        self.inbox_path.touch(exist_ok=True)
        self.outbox_path.parent.mkdir(parents=True, exist_ok=True)
        self._thread = threading.Thread(target=self._run, name="jsonl-inbox", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        offset = 0
        file_identity: tuple[int, int] | None = None
        while not self._stop.is_set():
            try:
                with self.inbox_path.open("r", encoding="utf-8-sig") as handle:
                    stat = os.fstat(handle.fileno())
                    current_identity = (int(stat.st_dev), int(stat.st_ino))
                    if file_identity is not None and current_identity != file_identity:
                        offset = 0
                        self._replacements += 1
                    file_identity = current_identity
                    if stat.st_size < offset:
                        offset = 0
                        self._truncations += 1
                    handle.seek(offset)
                    while True:
                        line_start = handle.tell()
                        line = handle.readline()
                        if not line:
                            break
                        if not line.endswith("\n"):
                            # A writer may still be appending this JSON object. Keep
                            # the offset before the partial line and retry later.
                            offset = line_start
                            break
                        next_offset = handle.tell()
                        if not line.strip():
                            offset = next_offset
                            continue
                        try:
                            payload = json.loads(line)
                            if not isinstance(payload, dict):
                                raise ValueError("JSONL 每行必须是 JSON 对象")
                            contact_name = str(payload["contact_name"]).strip()
                            contact_key = str(payload["contact_key"]).strip()
                            text = str(payload["text"]).strip()
                            if not contact_name or not contact_key or not text:
                                raise ValueError("JSONL 联系人、contact_key 和文本不能为空")
                            external_id = str(
                                payload.get("external_id")
                                or hashlib.sha256(
                                    (
                                        f"{self.inbox_path.resolve()}|{current_identity}|"
                                        f"{line_start}|{line}"
                                    ).encode("utf-8")
                                ).hexdigest()
                            )
                            raw_timestamp = payload.get("timestamp")
                            if raw_timestamp is not None and not isinstance(
                                raw_timestamp, str
                            ):
                                raise ValueError("timestamp 必须是 ISO 时间字符串")
                            incoming = IncomingMessage(
                                external_id=external_id,
                                contact_name=contact_name,
                                contact_key=contact_key,
                                text=text,
                                timestamp=datetime.fromisoformat(raw_timestamp)
                                if raw_timestamp
                                else datetime.now(),
                                metadata={"source": "jsonl"},
                            )
                        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
                            self._malformed_lines += 1
                            self._last_error = str(error)[:300]
                            offset = next_offset
                            continue
                        try:
                            if self.callback:
                                self.callback(incoming)
                        except Exception as error:
                            # Backpressure or a transient callback failure must not
                            # consume the line; it will be retried with the same ID.
                            self._callback_failures += 1
                            self._last_error = str(error)[:300]
                            offset = line_start
                            break
                        offset = next_offset
            except OSError as error:
                self._last_error = str(error)[:300]
            self._stop.wait(self.poll_seconds)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        record = {
            "contact_key": contact_key,
            "contact_name": contact_name,
            "text": text,
            "send_key": send_key,
            "timestamp": datetime.now().isoformat(),
            "mode": "local-outbox-only",
        }
        with self._write_lock, self.outbox_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def health(self) -> dict[str, object]:
        return {
            "mode": "jsonl",
            "running": bool(self._thread and self._thread.is_alive()),
            "inbox": str(self.inbox_path),
            "outbox": str(self.outbox_path),
            "malformed_lines": self._malformed_lines,
            "callback_failures": self._callback_failures,
            "truncations": self._truncations,
            "replacements": self._replacements,
            "last_error": self._last_error,
        }


class WxAutoX4Adapter(ChatAdapter):
    """Fail-closed live adapter for wxautox4 Plus.

    Each allowed contact is listened to in a dedicated ``Chat`` child window.  The
    same child object is retained for sending, so an outgoing message never relies
    on the mutable active conversation in the shared WeChat main window.
    """

    def __init__(
        self,
        whitelist: tuple[str, ...],
        expected_version: str,
        expected_account_nickname: str,
    ):
        if not whitelist:
            raise ValueError("真实微信适配器必须配置非空白名单")
        if not expected_account_nickname.strip():
            raise ValueError("真实微信适配器必须配置预期登录账号昵称")
        self.whitelist = set(whitelist)
        self.expected_version = expected_version
        self.expected_account_nickname = expected_account_nickname.strip()
        self.bindings: dict[str, dict[str, str]] = {}
        self._alias_by_key: dict[str, str] = {}
        self.callback: IncomingCallback | None = None
        self.wx = None
        self._runner: threading.Thread | None = None
        self._child_chats: dict[str, object] = {}
        self._send_lock = threading.Lock()
        self._state_lock = threading.RLock()
        self._seen_send_keys: set[str] = set()
        self._stopped = True
        self._online: bool | None = None
        self._account: dict[str, str | bool] = {}
        self._dropped_unstable = 0
        self._last_event: str | None = None
        self._last_error = ""

    def configure_bindings(self, bindings: dict[str, dict[str, str]]) -> None:
        if set(bindings) != self.whitelist:
            raise ValueError("微信白名单与联系人显式绑定不一致")
        contact_keys = [value["contact_key"] for value in bindings.values()]
        if len(set(contact_keys)) != len(contact_keys):
            raise ValueError("多个微信备注名不能绑定同一联系人")
        self.bindings = dict(bindings)
        self._alias_by_key = {
            value["contact_key"]: alias for alias, value in bindings.items()
        }

    def destination_matches(
        self,
        contact_key: str,
        contact_name: str,
        adapter_alias: str,
    ) -> bool:
        bound_alias = self._alias_by_key.get(contact_key)
        binding = self.bindings.get(bound_alias or "")
        return bool(
            binding
            and bound_alias == adapter_alias
            and binding["display_name"] == contact_name
        )

    def start(self, callback: IncomingCallback) -> None:
        if set(self.bindings) != self.whitelist:
            raise RuntimeError("启动 wxautox4 前必须完成联系人显式绑定")
        if self._runner and self._runner.is_alive() and not self._stopped:
            raise RuntimeError("wxautox4 适配器已在运行")
        installed_version = importlib.metadata.version("wxautox4")
        if self.expected_version and installed_version != self.expected_version:
            raise RuntimeError(
                f"wxautox4 版本不匹配：需要 {self.expected_version}，当前 {installed_version}"
            )
        module = importlib.import_module("wxautox4")
        with self._state_lock:
            self.callback = callback
            self._stopped = False
            self._online = None
            self._account = {}
            self._child_chats.clear()
            self._last_event = None
            self._last_error = ""
        try:
            # Passing the nickname selects the intended account when multiple
            # desktop WeChat instances are open.  GetMyInfo below independently
            # verifies that the selected window belongs to that account.
            self.wx = module.WeChat(nickname=self.expected_account_nickname)
            for method_name in ("AddListenChat", "KeepRunning"):
                if not callable(getattr(self.wx, method_name, None)):
                    raise RuntimeError(f"wxautox4 缺少必需方法: {method_name}")
            self._verify_online_account()
            for nickname in sorted(self.whitelist):
                listen_result = self.wx.AddListenChat(nickname, self._on_message)
                child = self._child_from_listen_result(nickname, listen_result)
                self._validate_child_chat(nickname, child)
                self._child_chats[nickname] = child
            self._runner = threading.Thread(
                target=self._run_listener,
                name="wxautox4-listener",
                daemon=True,
            )
            self._runner.start()
        except Exception as error:
            self._last_error = str(error)[:300]
            self._cleanup_listeners()
            with self._state_lock:
                self.callback = None
                self._stopped = True
                self._child_chats.clear()
            self.wx = None
            raise

    @staticmethod
    def _clean_mapping(value: object) -> dict[str, str]:
        if not isinstance(value, dict):
            raise RuntimeError("wxautox4 返回了无效的信息结构")
        return {
            str(key).strip(): str(item).strip()
            for key, item in value.items()
            if str(key).strip() and item is not None
        }

    @staticmethod
    def _first_value(mapping: dict[str, str], keys: tuple[str, ...]) -> str:
        for key in keys:
            value = mapping.get(key, "").strip()
            if value:
                return value
        return ""

    def _verify_online_account(self) -> None:
        if self.wx is None:
            raise RuntimeError("wxautox4 未初始化")
        is_online = getattr(self.wx, "IsOnline", None)
        if not callable(is_online):
            raise RuntimeError("wxautox4 缺少 IsOnline，无法核验登录状态")
        online = bool(is_online())
        self._online = online
        if not online:
            raise RuntimeError("目标微信账号当前未在线")

        get_my_info = getattr(self.wx, "GetMyInfo", None)
        if not callable(get_my_info):
            raise RuntimeError("wxautox4 缺少 GetMyInfo，无法核验发送账号")
        raw_info = self._clean_mapping(get_my_info())
        actual_nickname = self._first_value(
            raw_info,
            ("nickname", "昵称", "name", "NickName", "display_name"),
        )
        if not actual_nickname:
            raise RuntimeError("GetMyInfo 未返回可核验的账号昵称")
        if actual_nickname != self.expected_account_nickname:
            raise RuntimeError(
                "微信登录账号不匹配："
                f"预期 {self.expected_account_nickname}，实际 {actual_nickname}"
            )
        account_id = self._first_value(
            raw_info,
            ("wxid", "微信号", "wechat_id", "account", "id"),
        )
        if not account_id:
            raise RuntimeError("GetMyInfo 未返回稳定微信号，已拒绝使用真实适配器")
        previous_account_id = str(self._account.get("wechat_id", "") or "")
        if previous_account_id and account_id != previous_account_id:
            raise RuntimeError("微信登录账号 ID 已变化，已拒绝继续读取或发送")
        self._account = {
            "nickname": actual_nickname,
            "wechat_id": account_id,
            "verified": True,
        }

    @staticmethod
    def _is_child_chat(value: object) -> bool:
        return bool(
            value is not None
            and callable(getattr(value, "ChatInfo", None))
            and callable(getattr(value, "SendMsg", None))
        )

    def _child_from_listen_result(self, nickname: str, result: object) -> object:
        # Current official documentation returns Chat directly on success and a
        # false WxResponse on failure.  Some builds return a successful
        # WxResponse instead, so GetSubWindow is a safe compatibility fallback.
        if self._is_child_chat(result):
            return result
        if isinstance(result, dict):
            data = result.get("data")
            if self._is_child_chat(data):
                return data
            if isinstance(data, dict):
                for key in ("chat", "child", "window"):
                    candidate = data.get(key)
                    if self._is_child_chat(candidate):
                        return candidate
        try:
            succeeded = bool(result)
        except Exception as error:
            raise RuntimeError(
                f"监听 {nickname} 的返回结果无法判定"
            ) from error
        if not succeeded:
            raise RuntimeError(f"监听 {nickname} 失败：{str(result)[:200]}")
        get_subwindow = getattr(self.wx, "GetSubWindow", None)
        child = get_subwindow(nickname) if callable(get_subwindow) else None
        if not self._is_child_chat(child):
            raise RuntimeError(f"监听 {nickname} 后未取得独立 Chat 子窗口")
        return child

    def _validate_child_chat(self, nickname: str, child: object) -> dict[str, str]:
        if not self._is_child_chat(child):
            raise RuntimeError(f"{nickname} 的监听对象不是可用 Chat 子窗口")
        child_who = str(getattr(child, "who", "") or "").strip()
        if child_who != nickname:
            raise RuntimeError(
                f"Chat 子窗口名称不匹配：预期 {nickname}，实际 {child_who or '<空>'}"
            )
        info = self._clean_mapping(child.ChatInfo())
        active_name = info.get("chat_name", "").strip()
        chat_type = info.get("chat_type", "").strip().lower()
        child_type = str(getattr(child, "chat_type", "") or "").strip().lower()
        if active_name != nickname:
            raise RuntimeError(
                f"ChatInfo 名称不匹配：预期 {nickname}，实际 {active_name or '<空>'}"
            )
        if chat_type != "friend" or (child_type and child_type != "friend"):
            raise RuntimeError(f"{nickname} 不是一对一好友会话，已拒绝使用")
        return info

    def _run_listener(self) -> None:
        try:
            if self.wx is not None:
                self.wx.KeepRunning()
        except Exception as error:
            self._last_error = str(error)[:300]
        finally:
            # KeepRunning is expected to block until stop().  If it exits first,
            # fail closed so a stale child window cannot still be used to send.
            if not self._stopped:
                if not self._last_error:
                    self._last_error = "wxautox4 监听线程意外结束"
                self._stopped = True

    def _on_message(self, msg, chat) -> None:  # wxautox4 callback signature
        try:
            self._verify_online_account()
            who = str(getattr(chat, "who", "")).strip()
            if who not in self.whitelist:
                return
            if str(getattr(chat, "chat_type", "")).lower() != "friend":
                return
            if str(getattr(msg, "attr", "")).lower() != "friend":
                return
            if str(getattr(msg, "type", "")).lower() != "text":
                return
            text = str(getattr(msg, "content", "")).strip()
            if not text:
                return
            message_id = str(getattr(msg, "id", "") or "").strip()
            message_hash = str(getattr(msg, "hash", "") or "").strip()
            stable_identifier = message_id or message_hash
            if not stable_identifier:
                self._dropped_unstable += 1
                self._last_error = "消息缺少稳定 id/hash；为避免重放已拒绝自动处理"
                return
            binding = self.bindings[who]
            stable_parts = [who, str(getattr(msg, "sender", "")), stable_identifier]
            external_id = hashlib.sha256("|".join(stable_parts).encode("utf-8")).hexdigest()
            self._last_event = datetime.now().astimezone().isoformat(timespec="seconds")
            incoming = IncomingMessage(
                external_id=external_id,
                contact_name=binding["display_name"],
                contact_key=binding["contact_key"],
                text=text,
                timestamp=datetime.now(),
                metadata={
                    "source": "wxautox4",
                    "adapter_alias": who,
                    "account_nickname": self._account.get("nickname", ""),
                    "message_id": message_id,
                    "message_hash": message_hash,
                },
            )
            if self.callback:
                self.callback(incoming)
        except Exception as error:
            # A malformed UI object must never crash the listener or trigger a reply.
            self._last_error = str(error)[:300]
            return

    def stop(self) -> None:
        with self._state_lock:
            self.callback = None
            self._stopped = True
        self._cleanup_listeners()
        if self._runner and self._runner is not threading.current_thread():
            self._runner.join(timeout=2)
        with self._state_lock:
            self._child_chats.clear()

    def _cleanup_listeners(self) -> None:
        if self.wx is None:
            return
        for method_name in ("StopListening", "Stop", "Close"):
            method = getattr(self.wx, method_name, None)
            if callable(method):
                try:
                    method()
                except Exception:
                    pass
                break

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        if (
            self.wx is None
            or self._stopped
            or self._runner is None
            or not self._runner.is_alive()
        ):
            raise SendBlockedError("wxautox4 未启动；没有调用发送接口")
        alias = self._alias_by_key.get(contact_key)
        binding = self.bindings.get(alias or "")
        if alias is None or binding is None or binding["display_name"] != contact_name:
            raise SendBlockedError(
                "联系人键、显示名与微信备注名绑定不一致；没有调用发送接口"
            )
        if not text.strip():
            raise SendBlockedError("空消息已被阻断；没有调用发送接口")
        if not send_key.strip():
            raise SendBlockedError("send_key 为空；没有调用发送接口")
        with self._send_lock:
            if send_key in self._seen_send_keys:
                raise SendBlockedError(
                    "检测到重复 send_key，已拒绝再次发送；没有调用发送接口"
                )
            child = self._child_chats.get(alias)
            if child is None:
                raise SendBlockedError(
                    f"{alias} 没有活动的独立 Chat 子窗口；没有调用发送接口"
                )
            try:
                self._verify_online_account()
                self._validate_child_chat(alias, child)
            except Exception as error:
                raise SendBlockedError(
                    f"发送前子窗口复核失败：{error}；没有调用发送接口"
                ) from error

            # Record the key immediately before crossing the external-call
            # boundary.  From this point on, no failure is safe to retry.
            self._seen_send_keys.add(send_key)
            try:
                result = child.SendMsg(msg=text)
            except Exception as error:
                raise SendUncertainError(
                    "已调用 wxautox4 SendMsg，但调用异常；发送结果不确定，禁止重试"
                ) from error
            try:
                succeeded = bool(result)
            except Exception as error:
                raise SendUncertainError(
                    "已调用 wxautox4 SendMsg，但返回值无法判定；禁止重试"
                ) from error
            if not succeeded:
                raise SendUncertainError(
                    "已调用 wxautox4 SendMsg，但未得到成功结果；发送结果不确定，禁止重试"
                )

    def health(self) -> dict[str, object]:
        running = bool(
            self._runner and self._runner.is_alive() and not self._stopped
        )
        with self._state_lock:
            account = dict(self._account)
            active_listener_count = len(self._child_chats) if running else 0
        return {
            "mode": "wxautox4",
            "running": running,
            "online": self._online,
            "account": account,
            "whitelist_count": len(self.whitelist),
            "binding_count": len(self.bindings),
            "active_listener_count": active_listener_count,
            "last_event": self._last_event,
            "dropped_unstable": self._dropped_unstable,
            "last_error": self._last_error,
        }


class WxAuto4PollingAdapter(ChatAdapter):
    """Free, read-only, single-chat polling adapter for wxauto4.

    The adapter intentionally stops when the visible chat changes or the message
    list is rebuilt without a stable overlap.  That is restrictive, but prevents
    old history from being mistaken for a new production message.
    """

    def __init__(
        self,
        whitelist: tuple[str, ...],
        expected_version: str,
        expected_account_nickname: str,
        poll_seconds: float = 1.0,
        allow_send: bool = False,
        allowed_send_contact_key: str = "",
        send_echo_timeout_seconds: float = 5.0,
    ) -> None:
        if len(whitelist) != 1:
            raise ValueError("免费微信读取模式必须且只能配置一个联系人")
        if not expected_account_nickname.strip():
            raise ValueError("免费微信读取模式必须配置预期登录账号昵称")
        self.whitelist = set(whitelist)
        self.alias = whitelist[0]
        self.expected_version = expected_version
        self.expected_account_nickname = expected_account_nickname.strip()
        self.poll_seconds = poll_seconds
        self.allow_send = allow_send
        self.allowed_send_contact_key = allowed_send_contact_key.strip()
        self.send_echo_timeout_seconds = send_echo_timeout_seconds
        self.bindings: dict[str, dict[str, str]] = {}
        self._alias_by_key: dict[str, str] = {}
        self.callback: IncomingCallback | None = None
        self.wx = None
        self._stop = threading.Event()
        self._runner: threading.Thread | None = None
        self._ui_lock = threading.RLock()
        self._send_lock = threading.Lock()
        self._seen_send_keys: set[str] = set()
        self._sent_count = 0
        self._stopped = True
        self._online: bool | None = None
        self._account: dict[str, str | bool] = {}
        self._previous_order: list[str] = []
        self._seen_ids: set[str] = set()
        self._seen_order: deque[str] = deque()
        self._baseline_ready = False
        self._message_parser: Callable[[object, object], object] | None = None
        self._chat_box = None
        self._startup_stage = "idle"
        self._startup_duration_ms = 0
        self._last_poll_duration_ms = 0
        self._poll_count = 0
        self._foreground_switches = 0
        self._dropped_unstable = 0
        self._last_event: str | None = None
        self._last_error = ""

    def configure_bindings(self, bindings: dict[str, dict[str, str]]) -> None:
        if set(bindings) != self.whitelist:
            raise ValueError("微信白名单与联系人显式绑定不一致")
        self.bindings = dict(bindings)
        self._alias_by_key = {
            value["contact_key"]: alias for alias, value in bindings.items()
        }

    def destination_matches(
        self,
        contact_key: str,
        contact_name: str,
        adapter_alias: str,
    ) -> bool:
        alias = self._alias_by_key.get(contact_key)
        binding = self.bindings.get(alias or "")
        return bool(
            binding
            and alias == adapter_alias
            and binding["display_name"] == contact_name
        )

    @staticmethod
    def _clean_mapping(value: object) -> dict[str, str]:
        if not isinstance(value, dict):
            raise RuntimeError("wxauto4 返回了无效的信息结构")
        return {
            str(key).strip(): str(item).strip()
            for key, item in value.items()
            if str(key).strip() and item is not None
        }

    @staticmethod
    def _first_value(mapping: dict[str, str], keys: tuple[str, ...]) -> str:
        for key in keys:
            value = mapping.get(key, "").strip()
            if value:
                return value
        return ""

    def _verify_account(self) -> None:
        if self.wx is None:
            raise RuntimeError("wxauto4 未初始化")
        is_online = getattr(self.wx, "IsOnline", None)
        if not callable(is_online):
            raise RuntimeError("wxauto4 缺少 IsOnline，无法安全核验账号")
        self._online = bool(is_online())
        if not self._online:
            raise RuntimeError("目标微信账号当前未在线")
        get_my_info = getattr(self.wx, "GetMyInfo", None)
        if not callable(get_my_info):
            raise RuntimeError("wxauto4 缺少 GetMyInfo，无法安全核验账号")
        info = self._clean_mapping(get_my_info())
        actual = self._first_value(
            info,
            ("nickname", "昵称", "name", "NickName", "display_name"),
        )
        if not actual:
            raise RuntimeError("GetMyInfo 未返回可核验的账号昵称")
        if actual != self.expected_account_nickname:
            raise RuntimeError(
                "微信登录账号不匹配："
                f"预期 {self.expected_account_nickname}，实际 {actual}"
            )
        account_id = self._first_value(
            info,
            ("wxid", "微信号", "wechat_id", "account", "id"),
        )
        if self.allow_send and not account_id:
            raise RuntimeError("GetMyInfo 未返回稳定微信号，当前进程禁止外发")
        previous_account_id = str(self._account.get("wechat_id", "") or "")
        if previous_account_id and previous_account_id != account_id:
            raise RuntimeError("微信登录账号 ID 已变化，监听与外发均已停止")
        self._account = {
            "nickname": actual,
            "wechat_id": account_id,
            "verified": True,
        }

    def _verify_visible_chat(self) -> None:
        if self.wx is None:
            raise RuntimeError("wxauto4 未初始化")
        info = self._clean_mapping(self.wx.ChatInfo())
        active_name = info.get("chat_name", "").strip()
        chat_type = info.get("chat_type", "").strip().lower()
        if active_name != self.alias:
            raise RuntimeError(
                f"微信可见会话已变化：预期 {self.alias}，实际 {active_name or '<空>'}；"
                "免费单联系人监听已停止"
            )
        if chat_type != "friend":
            raise RuntimeError(f"{self.alias} 不是一对一好友会话，已停止监听")

    def _wait_for_visible_chat(self, timeout_seconds: float = 5.0) -> None:
        """Wait for ChatWith's asynchronous UI change to become observable."""
        deadline = time.monotonic() + timeout_seconds
        last_error: RuntimeError | None = None
        while True:
            try:
                self._verify_visible_chat()
                return
            except RuntimeError as error:
                last_error = error
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"微信未能在 {timeout_seconds:g} 秒内切换到 {self.alias}：{last_error}"
                ) from None
            if self._stop.wait(0.1):
                raise RuntimeError("等待微信切换会话时监听已停止")

    @staticmethod
    def _control_identity(control: object) -> str:
        """Return the stable UI Automation runtime id without parsing a message.

        ``GetAllMessage`` constructs every visible Message object.  In wxauto4
        41.1.2 that can retry sender classification many times per historical
        message.  Reading the control runtime ids is both read-only and enough to
        establish the no-replay baseline.
        """
        runtime_id = getattr(control, "runtimeid", None)
        if runtime_id is None:
            runtime_id = getattr(control, "RuntimeId", None)
        if isinstance(runtime_id, (tuple, list)):
            return "uia:" + ",".join(str(part) for part in runtime_id)
        return f"uia:{runtime_id}" if runtime_id not in (None, "") else ""

    def _remember(self, identity: str) -> None:
        if identity in self._seen_ids:
            return
        self._seen_ids.add(identity)
        self._seen_order.append(identity)
        while len(self._seen_order) > 10_000:
            expired = self._seen_order.popleft()
            self._seen_ids.discard(expired)

    def _current_controls(self) -> list[tuple[str, object]]:
        if self._chat_box is None:
            raise RuntimeError("wxauto4 ChatBox 未初始化")
        msgbox = getattr(self._chat_box, "msgbox", None)
        get_children = getattr(msgbox, "GetChildren", None)
        if not callable(get_children):
            raise RuntimeError("wxauto4 缺少只读消息控件接口，已拒绝全量解析历史消息")
        raw = get_children()
        if not isinstance(raw, (list, tuple)):
            raise RuntimeError("wxauto4 消息控件接口未返回列表")
        current: list[tuple[str, object]] = []
        for control in raw:
            if str(getattr(control, "ControlTypeName", "")) != "ListItemControl":
                continue
            identity = self._control_identity(control)
            if identity:
                current.append((identity, control))
            else:
                self._dropped_unstable += 1
        return current

    def _parse_control(self, control: object) -> object:
        if self._message_parser is None or self._chat_box is None:
            raise RuntimeError("wxauto4 消息解析器未初始化")
        return self._message_parser(control, self._chat_box)

    def _one_click_controls(self) -> tuple[object, object]:
        if self._chat_box is None:
            raise RuntimeError("wxauto4 ChatBox 未初始化")
        editbox = getattr(self._chat_box, "editbox", None)
        sendbtn = getattr(self._chat_box, "sendbtn", None)
        for owner, method_names in (
            (
                editbox,
                ("Exists", "ShortcutSelectAll", "SendKeys", "Paste", "GetValuePattern"),
            ),
            (sendbtn, ("Exists", "Click")),
        ):
            if owner is None or any(
                not callable(getattr(owner, method_name, None))
                for method_name in method_names
            ):
                raise RuntimeError("wxauto4 缺少一次性安全发送所需的固定控件接口")
            if not bool(owner.Exists(0)):
                raise RuntimeError("wxauto4 一次性安全发送控件当前不存在")
        return editbox, sendbtn

    @staticmethod
    def _editbox_value(editbox: object) -> str:
        pattern = editbox.GetValuePattern()
        value = getattr(pattern, "Value", None)
        if not isinstance(value, str):
            raise RuntimeError("微信输入框没有返回可核验文本")
        return value.replace("\ufffc", "")

    def _prepare_one_click_text(self, text: str) -> object:
        editbox, sendbtn = self._one_click_controls()
        editbox.ShortcutSelectAll()
        editbox.SendKeys("{DELETE}")
        if self._editbox_value(editbox) != "":
            raise RuntimeError("微信输入框未能安全清空")
        editbox.Paste(text)
        actual = self._editbox_value(editbox)
        if actual != text:
            raise RuntimeError("微信输入框内容与待发送文本不完全一致")
        return sendbtn

    def _wait_for_self_echo(self, text: str, baseline_ids: set[str]) -> None:
        deadline = time.monotonic() + self.send_echo_timeout_seconds
        settle_seconds = min(0.25, max(0.01, self.send_echo_timeout_seconds / 2))
        first_echo_at: float | None = None
        matching_ids: set[str] = set()
        last_parse_error = ""
        while True:
            self._verify_visible_chat()
            for identity, control in self._current_controls():
                if identity in baseline_ids:
                    continue
                try:
                    msg = self._parse_control(control)
                except Exception as error:
                    last_parse_error = str(error)[:200]
                    continue
                if (
                    str(getattr(msg, "attr", "")).lower() == "self"
                    and str(getattr(msg, "type", "")).lower() == "text"
                    and str(getattr(msg, "content", "") or "") == text
                ):
                    matching_ids.add(identity)
                    if first_echo_at is None:
                        first_echo_at = time.monotonic()
            if first_echo_at is not None and time.monotonic() - first_echo_at >= settle_seconds:
                if len(matching_ids) == 1:
                    return
                raise RuntimeError("观察到重复的本人消息气泡，发送结果不唯一")
            if time.monotonic() >= deadline:
                detail = f"；最后解析错误：{last_parse_error}" if last_parse_error else ""
                raise RuntimeError(f"未观察到本人消息气泡回显{detail}")
            time.sleep(0.1)

    def _set_baseline(self) -> None:
        self._verify_visible_chat()
        current = self._current_controls()
        self._previous_order = [identity for identity, _ in current]
        for identity in self._previous_order:
            self._remember(identity)
        self._baseline_ready = True

    def _poll_once(self) -> None:
        with self._ui_lock:
            started = time.monotonic()
            self._verify_visible_chat()
            current = self._current_controls()
            current_ids = [identity for identity, _ in current]
            if not self._baseline_ready:
                raise RuntimeError("wxauto4 读取基线尚未建立")

            if not self._previous_order:
                candidate_start = 0
            else:
                positions = {identity: index for index, identity in enumerate(current_ids)}
                anchor_index: int | None = None
                for previous_id in reversed(self._previous_order):
                    if previous_id in positions:
                        anchor_index = positions[previous_id]
                        break
                if anchor_index is None:
                    raise RuntimeError(
                        "消息窗口重建且没有稳定重叠；为避免把历史消息当作新消息，"
                        "免费单联系人监听已停止"
                    )
                candidate_start = anchor_index + 1

            candidates = set(current_ids[candidate_start:])
            binding = self.bindings[self.alias]
            for identity, control in current:
                was_seen = identity in self._seen_ids
                self._remember(identity)
                if identity not in candidates or was_seen:
                    continue
                msg = self._parse_control(control)
                if str(getattr(msg, "attr", "")).lower() != "friend":
                    continue
                if str(getattr(msg, "type", "")).lower() != "text":
                    continue
                text = str(getattr(msg, "content", "") or "").strip()
                if not text:
                    continue
                external_id = hashlib.sha256(
                    f"{self.alias}|{identity}".encode("utf-8")
                ).hexdigest()
                self._last_event = datetime.now().astimezone().isoformat(
                    timespec="seconds"
                )
                incoming = IncomingMessage(
                    external_id=external_id,
                    contact_name=binding["display_name"],
                    contact_key=binding["contact_key"],
                    text=text,
                    timestamp=datetime.now(),
                    metadata={
                        "source": "wxauto4_polling",
                        "adapter_alias": self.alias,
                        "account_nickname": self._account.get("nickname", ""),
                        "message_id": str(getattr(msg, "id", "") or ""),
                        "message_hash": str(getattr(msg, "hash", "") or ""),
                    },
                )
                if self.callback:
                    self.callback(incoming)
            self._previous_order = current_ids
            self._poll_count += 1
            self._last_poll_duration_ms = int((time.monotonic() - started) * 1000)

    def start(self, callback: IncomingCallback) -> None:
        if set(self.bindings) != self.whitelist:
            raise RuntimeError("启动 wxauto4 前必须完成联系人显式绑定")
        installed_version = importlib.metadata.version("wxauto4")
        if self.expected_version and installed_version != self.expected_version:
            raise RuntimeError(
                f"wxauto4 版本不匹配：需要 {self.expected_version}，当前 {installed_version}"
            )
        module = importlib.import_module("wxauto4")
        self.callback = callback
        self._stop.clear()
        self._stopped = False
        self._last_error = ""
        self._previous_order.clear()
        self._seen_ids.clear()
        self._seen_order.clear()
        self._seen_send_keys.clear()
        self._sent_count = 0
        self._baseline_ready = False
        self._message_parser = None
        self._chat_box = None
        self._startup_stage = "constructing_wechat"
        self._startup_duration_ms = 0
        self._last_poll_duration_ms = 0
        self._poll_count = 0
        self._foreground_switches = 0
        started = time.monotonic()
        try:
            # Locate the visible WeChat window without pre-filtering by nickname.
            # wxauto4's public constructor does not document a nickname selector,
            # and emoji/space-heavy account names can make that selector reject an
            # otherwise valid window before GetMyInfo() is available.  Account
            # safety is still enforced immediately below by _verify_account().
            self.wx = module.WeChat(ads=False, resize=False)
            for method_name in ("ChatWith", "ChatInfo"):
                if not callable(getattr(self.wx, method_name, None)):
                    raise RuntimeError(f"wxauto4 缺少必需方法: {method_name}")
            self._chat_box = getattr(self.wx, "ChatBox", None)
            parser = getattr(module, "parse_msg", None)
            if not callable(parser):
                parser_module = importlib.import_module("wxauto4.msgs.msg")
                parser = getattr(parser_module, "parse_msg", None)
            if not callable(parser):
                raise RuntimeError("wxauto4 缺少消息解析器 parse_msg")
            self._message_parser = parser
            # Validate the raw, read-only path before any foreground operation.
            msgbox = getattr(self._chat_box, "msgbox", None)
            if not callable(getattr(msgbox, "GetChildren", None)):
                raise RuntimeError("wxauto4 缺少只读消息控件接口")
            if self.allow_send:
                self._one_click_controls()
            self._startup_stage = "verifying_account"
            self._verify_account()
            self._startup_stage = "selecting_chat"
            try:
                self._verify_visible_chat()
            except RuntimeError:
                # ChatWith is the only operation in this adapter expected to
                # activate WeChat.  Skip it on restarts when the exact friend is
                # already open, so normal work in other applications keeps focus.
                self.wx.ChatWith(self.alias, exact=True)
                self._foreground_switches += 1
                self._wait_for_visible_chat()
            self._startup_stage = "building_read_only_baseline"
            self._set_baseline()
            self._startup_stage = "running"
            self._startup_duration_ms = int((time.monotonic() - started) * 1000)
            self._runner = threading.Thread(
                target=self._run,
                name="wxauto4-single-contact-poller",
                daemon=True,
            )
            self._runner.start()
        except Exception as error:
            self._startup_duration_ms = int((time.monotonic() - started) * 1000)
            self._last_error = str(error)[:300]
            self.callback = None
            self.wx = None
            self._stopped = True
            raise

    def _run(self) -> None:
        while not self._stop.wait(self.poll_seconds):
            try:
                self._poll_once()
            except Exception as error:
                self._last_error = str(error)[:300]
                self._stopped = True
                self.callback = None
                break

    def stop(self) -> None:
        self._stop.set()
        self._stopped = True
        self.callback = None
        if self._runner and self._runner is not threading.current_thread():
            self._runner.join(timeout=2)
        self.wx = None

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        if not self.allow_send:
            raise SendBlockedError("当前 wxauto4 进程未授权外发；发送接口未被调用")
        if not self.allowed_send_contact_key:
            raise SendBlockedError("未锁定唯一外发 contact_key；发送接口未被调用")
        if contact_key != self.allowed_send_contact_key:
            raise SendBlockedError("外发 contact_key 不在唯一测试目标内；发送接口未被调用")
        if (
            self.wx is None
            or self._stopped
            or self._runner is None
            or not self._runner.is_alive()
        ):
            raise SendBlockedError("wxauto4 单联系人监听未运行；发送接口未被调用")
        alias = self._alias_by_key.get(contact_key)
        binding = self.bindings.get(alias or "")
        if (
            alias != self.alias
            or binding is None
            or binding["display_name"] != contact_name
        ):
            raise SendBlockedError(
                "联系人键、显示名与唯一微信备注名绑定不一致；发送接口未被调用"
            )
        if not text.strip():
            raise SendBlockedError("空消息已被阻断；发送接口未被调用")
        if "\ufffc" in text:
            raise SendBlockedError("消息包含无法无歧义核验的对象占位符；发送接口未被调用")
        if not send_key.strip():
            raise SendBlockedError("send_key 为空；发送接口未被调用")

        with self._send_lock:
            if send_key in self._seen_send_keys:
                raise SendBlockedError(
                    "检测到重复 send_key，已拒绝再次发送；发送接口未被调用"
                )
            with self._ui_lock:
                try:
                    self._verify_account()
                    self._verify_visible_chat()
                    baseline_ids = {
                        identity for identity, _ in self._current_controls()
                    }
                    sendbtn = self._prepare_one_click_text(text)
                    # Preparing the input can take time; repeat both destination
                    # checks immediately before the only external send click.
                    self._verify_account()
                    self._verify_visible_chat()
                except Exception as error:
                    raise SendBlockedError(
                        f"发送前账号或可见会话复核失败：{error}；发送接口未被调用"
                    ) from error

                # The public wxauto4 SendMsg implementation may internally click
                # more than once while waiting for a button-state change.  Use the
                # pinned 4.1.8 controls directly so this boundary is crossed by
                # exactly one Click, then require a new self-message UIA echo.
                self._seen_send_keys.add(send_key)
                try:
                    sendbtn.Click()
                    self._wait_for_self_echo(text, baseline_ids)
                except Exception as error:
                    self._last_error = (
                        "一次点击后发送结果不确定；必须人工核对微信并重启监听"
                    )
                    self._stopped = True
                    self.callback = None
                    self._stop.set()
                    raise SendUncertainError(
                        "微信发送按钮已点击一次，但未得到可靠的本人消息回显；"
                        "发送结果不确定，禁止重试"
                    ) from error
                self._sent_count += 1

    def health(self) -> dict[str, object]:
        running = bool(
            self._runner and self._runner.is_alive() and not self._stopped
        )
        return {
            "mode": "wxauto4_polling",
            "running": running,
            "online": self._online,
            "account": dict(self._account),
            "whitelist_count": len(self.whitelist),
            "binding_count": len(self.bindings),
            "active_listener_count": 1 if running else 0,
            "baseline_count": len(self._previous_order),
            "startup_stage": self._startup_stage,
            "startup_duration_ms": self._startup_duration_ms,
            "last_poll_duration_ms": self._last_poll_duration_ms,
            "poll_count": self._poll_count,
            "foreground_switches": self._foreground_switches,
            "poll_strategy": "uia_runtime_ids_then_parse_new_only",
            "send_strategy": "verified_edit_single_click_then_self_echo",
            "last_event": self._last_event,
            "dropped_unstable": self._dropped_unstable,
            "last_error": self._last_error,
            "read_only": not self.allow_send,
            "send_capable": self.allow_send,
            "sent_count": self._sent_count,
        }


def build_adapter(config: AppConfig) -> ChatAdapter:
    if config.adapter_mode == "mock":
        return MockAdapter()
    if config.adapter_mode == "wxautox4":
        return WxAutoX4Adapter(
            config.contact_whitelist,
            config.wxautox4_expected_version,
            config.wx_account_nickname,
        )
    if config.adapter_mode == "wxauto4_polling":
        return WxAuto4PollingAdapter(
            config.contact_whitelist,
            config.wxauto4_expected_version,
            config.wx_account_nickname,
            allow_send=config.send_enabled,
            allowed_send_contact_key=config.wx_send_contact_key,
        )
    if config.adapter_mode == "wxauto4_global_readonly":
        # Lazy import keeps the already validated single-contact implementation
        # isolated from the experimental global scanner and avoids a module cycle.
        from .global_read import WxAuto4GlobalReadonlyAdapter

        return WxAuto4GlobalReadonlyAdapter(
            expected_version=config.wxauto4_expected_version,
            expected_account_nickname=config.wx_account_nickname,
            parking_chat=config.wx_global_parking_chat,
            poll_seconds=config.wx_global_poll_seconds,
            state_dir=config.data_dir / "global-read-state",
        )
    return JsonlFileAdapter(config.inbox_path, config.outbox_path)
