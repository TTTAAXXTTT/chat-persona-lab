from __future__ import annotations

import json
import hmac
import mimetypes
import re
import secrets
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from .service import PersonaService
from .store import Store


class AppServer(ThreadingHTTPServer):
    def __init__(self, address, handler, *, service: PersonaService, store: Store, web_root: Path):
        super().__init__(address, handler)
        self.service = service
        self.store = store
        self.web_root = web_root
        self.csrf_token = secrets.token_urlsafe(32)
        host, port = self.server_address[:2]
        self.allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if host == "::1":
            self.allowed_hosts.add(f"[::1]:{port}")
        self._rate_lock = threading.Lock()
        self._incoming_times: deque[float] = deque()

    def allow_incoming_request(self) -> bool:
        now = time.monotonic()
        with self._rate_lock:
            while self._incoming_times and now - self._incoming_times[0] > 60:
                self._incoming_times.popleft()
            if len(self._incoming_times) >= 20:
                return False
            self._incoming_times.append(now)
            return True


class Handler(BaseHTTPRequestHandler):
    server: AppServer

    def log_message(self, format: str, *args: object) -> None:
        return

    def _json(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._security_headers()
        self.end_headers()
        self.wfile.write(body)

    def _error(self, error: Exception, status: int = 400) -> None:
        self._json({"ok": False, "error": str(error)}, status)

    def _body(self) -> dict[str, Any]:
        content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            raise ValueError("POST 请求必须使用 application/json")
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > 1_000_000:
            raise ValueError("请求体过大")
        raw = self.rfile.read(length) if length else b"{}"
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return payload

    def _security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; connect-src 'self'; "
            "img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
        )

    def _check_host(self) -> None:
        if self.headers.get("Host", "") not in self.server.allowed_hosts:
            raise PermissionError("Host 不在本机允许列表")

    def _check_api_token(self) -> None:
        supplied = self.headers.get("X-Local-CSRF", "")
        if not hmac.compare_digest(supplied, self.server.csrf_token):
            raise PermissionError("本地会话令牌无效")

    def _check_origin(self) -> None:
        origin = self.headers.get("Origin", "")
        if origin and origin not in {
            f"http://{host}" for host in self.server.allowed_hosts
        }:
            raise PermissionError("Origin 不在本机允许列表")

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            self._check_host()
            if path.startswith("/api/"):
                self._check_api_token()
            if path == "/api/state":
                self._json({"ok": True, "state": self.server.service.state()})
                return
            if path == "/api/contacts":
                self._json({"ok": True, "contacts": self.server.store.list_contacts()})
                return
            if path == "/api/drafts":
                self._json({"ok": True, "drafts": self.server.store.list_drafts()})
                return
            if path == "/api/adapter-identities":
                self._json(
                    {
                        "ok": True,
                        "identities": self.server.store.list_adapter_identities(),
                    }
                )
                return
            if path == "/api/quarantine":
                self._json(
                    {
                        "ok": True,
                        "quarantine": self.server.store.list_quarantined_incoming(),
                    }
                )
                return
            if path in {"/", "/index.html"}:
                self._serve_file(self.server.web_root / "index.html")
                return
            self._json({"ok": False, "error": "Not found"}, HTTPStatus.NOT_FOUND)
        except PermissionError as error:
            self._error(error, 403)
        except Exception as error:
            self._error(error, 500)

    def _serve_file(self, path: Path) -> None:
        if path.name == "index.html":
            body = path.read_text(encoding="utf-8").replace(
                "__LOCAL_CSRF_TOKEN__", self.server.csrf_token
            ).encode("utf-8")
        else:
            body = path.read_bytes()
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._security_headers()
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            self._check_host()
            self._check_origin()
            self._check_api_token()
            payload = self._body()
            if path == "/api/model":
                selected = self.server.service.select_model(
                    str(payload.get("model", ""))
                )
                self._json({"ok": True, "model": selected})
                return
            if path == "/api/send-mode":
                enabled = payload.get("enabled")
                if not isinstance(enabled, bool):
                    raise ValueError("enabled 必须是 JSON boolean")
                if enabled:
                    self.server.service.require_ready()
                effective = self.server.service.set_runtime_send_enabled(enabled)
                self._json({"ok": True, "runtime_send_enabled": effective})
                return
            if path == "/api/incoming":
                self.server.service.require_ready()
                if not self.server.allow_incoming_request():
                    self._json({"ok": False, "error": "测试消息请求过于频繁"}, 429)
                    return
                external_id = self.server.service.submit_manual_incoming(
                    str(payload.get("contact_key", "")),
                    str(payload.get("text", "")),
                    str(payload.get("contact_name", "")),
                )
                self._json({"ok": True, "external_id": external_id}, 202)
                return
            match = re.fullmatch(r"/api/drafts/([a-f0-9]+)/approve", path)
            if match:
                self.server.service.require_ready()
                raw_messages = payload.get("messages", [])
                if not isinstance(raw_messages, list) or not all(
                    isinstance(item, str) for item in raw_messages
                ):
                    raise ValueError("messages 必须是字符串数组")
                draft = self.server.service.approve(
                    match.group(1),
                    raw_messages,
                    str(payload.get("destination_confirmation", "")),
                )
                self._json({"ok": True, "draft": draft})
                return
            match = re.fullmatch(r"/api/drafts/([a-f0-9]+)/reject", path)
            if match:
                draft = self.server.service.reject(match.group(1))
                self._json({"ok": True, "draft": draft})
                return
            match = re.fullmatch(
                r"/api/adapter-identities/([a-f0-9]{64})/bind", path
            )
            if match:
                expected_fields = {
                    "expected_alias",
                    "contact_key",
                    "display_name",
                    "relationship",
                    "create_new",
                    "enable_live_read",
                }
                if set(payload) != expected_fields:
                    raise ValueError("身份绑定请求字段缺失或包含未知字段")
                expected_alias = payload.get("expected_alias")
                contact_key = payload.get("contact_key")
                display_name = payload.get("display_name")
                relationship = payload.get("relationship")
                create_new = payload.get("create_new")
                enable_live_read = payload.get("enable_live_read")
                if not isinstance(expected_alias, str):
                    raise ValueError("expected_alias 必须是字符串")
                if contact_key is not None and not isinstance(contact_key, str):
                    raise ValueError("contact_key 必须是字符串或 null")
                if not isinstance(display_name, str):
                    raise ValueError("display_name 必须是字符串")
                if not isinstance(relationship, str):
                    raise ValueError("relationship 必须是字符串")
                if not isinstance(create_new, bool):
                    raise ValueError("create_new 必须是 JSON boolean")
                if not isinstance(enable_live_read, bool):
                    raise ValueError("enable_live_read 必须是 JSON boolean")
                contact = self.server.service.bind_adapter_identity(
                    identity_key=match.group(1),
                    expected_alias=expected_alias,
                    contact_key=contact_key,
                    display_name=display_name,
                    relationship=relationship,
                    create_new=create_new,
                    enable_live_read=enable_live_read,
                )
                self._json({"ok": True, "contact": contact})
                return
            match = re.fullmatch(
                r"/api/quarantine/([a-f0-9]{64})/(release|reject)", path
            )
            if match:
                if payload:
                    raise ValueError("隔离消息操作不接受请求参数")
                if match.group(2) == "release":
                    result = self.server.service.release_quarantined_event(
                        match.group(1)
                    )
                    self._json({"ok": True, "result": result})
                    return
                if not self.server.service.reject_quarantined_event(match.group(1)):
                    raise KeyError(match.group(1))
                self._json({"ok": True})
                return
            match = re.fullmatch(r"/api/contacts/(.+)", path)
            if match:
                from urllib.parse import unquote

                contact_key = unquote(match.group(1))
                live_read_enabled = payload.get("live_read_enabled", False)
                if not isinstance(live_read_enabled, bool):
                    raise ValueError("live_read_enabled 必须是 JSON boolean")
                self.server.store.update_contact(
                    contact_key,
                    str(payload.get("relationship", "待确认")),
                    live_read_enabled,
                    str(payload.get("adapter_alias", "")),
                )
                self._json({"ok": True})
                return
            self._json({"ok": False, "error": "Not found"}, HTTPStatus.NOT_FOUND)
        except KeyError as error:
            self._error(error, 404)
        except PermissionError as error:
            self._error(error, 403)
        except (ValueError, RuntimeError) as error:
            self._error(error, 400)
        except Exception as error:
            self._error(error, 500)

    def do_OPTIONS(self) -> None:
        self._json({"ok": False, "error": "CORS preflight rejected"}, 403)


def run_server(
    service: PersonaService,
    store: Store,
    host: str,
    port: int,
    web_root: Path,
    *,
    on_bound: Callable[[], None] | None = None,
) -> None:
    server = AppServer((host, port), Handler, service=service, store=store, web_root=web_root)
    try:
        if on_bound is not None:
            on_bound()
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
