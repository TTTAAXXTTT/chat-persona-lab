from __future__ import annotations

import re

from .models import RiskDecision


class RiskEngine:
    HIGH_RISK: tuple[tuple[str, re.Pattern[str]], ...] = (
        ("金钱或付款", re.compile(r"转账|借钱|借我|还钱|付款|支付|付一下|收款|收钱|银行卡|红包|担保|投资|退款|打款|报价|费用|\d+(?:\.\d+)?\s*元")),
        ("法律或合同", re.compile(r"合同|协议|签字|签署|怎么签|盖章|赔偿|律师|起诉|报警|法律责任|认责|仲裁")),
        ("医疗或人身安全", re.compile(r"诊断|处方|停药|药量|剂量|用药|吃什么药|发烧|急诊|医院|自杀|轻生|跳楼|伤害自己|人身安全")),
        ("账号与高敏隐私", re.compile(r"密码|验证码|身份证|护照|银行卡号|登录口令|账号权限|微信号|微信账号|API.?Key|密钥|家庭住址|具体地址", re.I)),
        ("关系重大变化", re.compile(r"分手|复合|表白|结婚|离婚|确定关系|关系定性|在一起吧|谈恋爱")),
        ("职业重大决定", re.compile(r"辞职|离职|跳槽|接受offer|拒绝offer|调岗|薪酬谈判", re.I)),
        ("代理身份询问", re.compile(r"你是机器人|是不是机器人|是本人吗|本人在吗|AI代回|AI生成|自动生成|自动回复吗", re.I)),
    )
    COMMITMENT = re.compile(r"我保证|我承诺|我一定会|肯定能|包在我身上|我已经付款|我同意签")
    INVITATION = re.compile(r"一起吃|一起去|出来玩|周末有空|要不要见|约个|这次不去|我不去了")
    PROMPT_INJECTION = re.compile(r"忽略.*规则|忽略.*指令|system prompt|系统提示词|把.*隐私.*告诉", re.I)

    def assess(self, text: str) -> RiskDecision:
        reasons = [label for label, pattern in self.HIGH_RISK if pattern.search(text)]
        if reasons:
            return RiskDecision(level="high", action="blocked", reasons=reasons)
        medium: list[str] = []
        if self.INVITATION.search(text):
            medium.append("邀约或拒绝邀约只能生成草稿")
        if self.PROMPT_INJECTION.search(text):
            medium.append("对方消息疑似试图改变机器人规则")
        if self.COMMITMENT.search(text):
            medium.append("可能产生新承诺")
        if medium:
            return RiskDecision(level="medium", action="draft", reasons=medium)
        return RiskDecision(level="low", action="draft", reasons=["首版所有回复均需本人确认"])

    def generated_text_safe(self, messages: list[str]) -> tuple[bool, list[str]]:
        joined = "\n".join(messages)
        reasons = [label for label, pattern in self.HIGH_RISK if pattern.search(joined)]
        if self.COMMITMENT.search(joined):
            reasons.append("草稿新增了承诺性措辞")
        return not reasons, reasons
