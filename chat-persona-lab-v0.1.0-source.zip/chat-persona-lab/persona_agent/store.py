from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .chat_parser import build_example_pairs
from .models import AdapterEnvelope, IncomingMessage, ModelDraft, ParsedExport, RiskDecision


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store:
    _SAFE_ADAPTER_METADATA_FIELDS = {
        "account_nickname",
        "account_wechat_id",
        "session_identity",
        "adapter_run_generation",
        "message_id",
        "message_hash",
        "control_identity",
        "unread_delta",
        "event_identity_scope",
        "platform_message_id",
    }

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=20)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    @contextmanager
    def connection(self):
        connection = self._connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def initialize(self) -> None:
        schema = """
        CREATE TABLE IF NOT EXISTS contacts (
            contact_key TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            account_id TEXT,
            adapter_alias TEXT,
            relationship TEXT NOT NULL DEFAULT '待确认',
            enabled INTEGER NOT NULL DEFAULT 1,
            live_read_enabled INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            source_key TEXT PRIMARY KEY,
            contact_key TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            sender_role TEXT NOT NULL,
            sender_name TEXT NOT NULL,
            content TEXT NOT NULL,
            source_file TEXT NOT NULL,
            sequence_index INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(contact_key) REFERENCES contacts(contact_key)
        );
        CREATE INDEX IF NOT EXISTS idx_messages_contact_time
            ON messages(contact_key, timestamp DESC);
        CREATE TABLE IF NOT EXISTS examples (
            source_key TEXT PRIMARY KEY,
            contact_key TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            incoming_json TEXT NOT NULL,
            reply_json TEXT NOT NULL,
            source_file TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(contact_key) REFERENCES contacts(contact_key)
        );
        CREATE INDEX IF NOT EXISTS idx_examples_contact_time
            ON examples(contact_key, timestamp DESC);
        CREATE TABLE IF NOT EXISTS incoming (
            external_id TEXT PRIMARY KEY,
            contact_key TEXT NOT NULL,
            contact_name TEXT NOT NULL,
            text TEXT NOT NULL,
            received_at TEXT NOT NULL,
            metadata_json TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY(contact_key) REFERENCES contacts(contact_key)
        );
        CREATE TABLE IF NOT EXISTS drafts (
            id TEXT PRIMARY KEY,
            incoming_id TEXT NOT NULL UNIQUE,
            contact_key TEXT NOT NULL,
            contact_name TEXT NOT NULL,
            incoming_text TEXT NOT NULL,
            messages_json TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            risk_reasons_json TEXT NOT NULL,
            confidence REAL NOT NULL,
            needs_user_input INTEGER NOT NULL DEFAULT 0,
            uncertainties_json TEXT NOT NULL,
            status TEXT NOT NULL,
            model TEXT NOT NULL,
            send_key TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            error TEXT,
            FOREIGN KEY(incoming_id) REFERENCES incoming(external_id)
        );
        CREATE INDEX IF NOT EXISTS idx_drafts_status_time
            ON drafts(status, created_at DESC);
        CREATE TABLE IF NOT EXISTS send_attempts (
            draft_id TEXT NOT NULL,
            message_index INTEGER NOT NULL,
            send_key TEXT NOT NULL UNIQUE,
            content TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            error TEXT,
            PRIMARY KEY(draft_id, message_index),
            FOREIGN KEY(draft_id) REFERENCES drafts(id)
        );
        CREATE TABLE IF NOT EXISTS knowledge_sources (
            source_path TEXT PRIMARY KEY,
            source_name TEXT NOT NULL,
            kind TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            modified_ns INTEGER NOT NULL,
            item_count INTEGER NOT NULL,
            metadata_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS adapter_identities (
            identity_key TEXT PRIMARY KEY,
            account_scope TEXT NOT NULL,
            adapter_kind TEXT NOT NULL,
            external_identity TEXT NOT NULL,
            identity_quality TEXT NOT NULL,
            adapter_alias TEXT NOT NULL,
            last_seen_alias TEXT NOT NULL,
            contact_key TEXT,
            status TEXT NOT NULL,
            first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            approved_at TEXT,
            FOREIGN KEY(contact_key) REFERENCES contacts(contact_key),
            UNIQUE(account_scope, adapter_kind, external_identity)
        );
        CREATE INDEX IF NOT EXISTS idx_adapter_identities_status
            ON adapter_identities(status, last_seen_at DESC);
        CREATE INDEX IF NOT EXISTS idx_adapter_identities_alias
            ON adapter_identities(account_scope, adapter_kind, last_seen_alias);
        CREATE TABLE IF NOT EXISTS quarantined_incoming (
            event_key TEXT PRIMARY KEY,
            external_event_id TEXT NOT NULL,
            identity_key TEXT,
            account_scope TEXT NOT NULL,
            adapter_kind TEXT NOT NULL,
            external_identity TEXT NOT NULL,
            identity_quality TEXT NOT NULL,
            adapter_alias TEXT NOT NULL,
            chat_type TEXT NOT NULL,
            sender_role TEXT NOT NULL,
            message_type TEXT NOT NULL,
            text TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            metadata_json TEXT NOT NULL,
            reason TEXT NOT NULL,
            releasable INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL,
            released_incoming_id TEXT,
            released_contact_key TEXT,
            released_at TEXT,
            error TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(identity_key) REFERENCES adapter_identities(identity_key),
            FOREIGN KEY(released_incoming_id) REFERENCES incoming(external_id),
            FOREIGN KEY(released_contact_key) REFERENCES contacts(contact_key),
            UNIQUE(account_scope, adapter_kind, external_event_id)
        );
        CREATE INDEX IF NOT EXISTS idx_quarantined_status_time
            ON quarantined_incoming(status, occurred_at);
        CREATE INDEX IF NOT EXISTS idx_quarantined_identity_status
            ON quarantined_incoming(identity_key, status, occurred_at);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_adapter_approved_alias
            ON adapter_identities(account_scope, adapter_kind, adapter_alias)
            WHERE status='approved';
        CREATE INDEX IF NOT EXISTS idx_adapter_identity_contact_status
            ON adapter_identities(contact_key, status);
        """
        with self.connection() as connection:
            connection.executescript(schema)
            message_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(messages)").fetchall()
            }
            if "sequence_index" not in message_columns:
                connection.execute(
                    "ALTER TABLE messages ADD COLUMN sequence_index INTEGER NOT NULL DEFAULT 0"
                )
            contact_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(contacts)").fetchall()
            }
            if "adapter_alias" not in contact_columns:
                connection.execute("ALTER TABLE contacts ADD COLUMN adapter_alias TEXT")
            draft_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(drafts)").fetchall()
            }
            if "needs_user_input" not in draft_columns:
                connection.execute(
                    "ALTER TABLE drafts ADD COLUMN needs_user_input INTEGER NOT NULL DEFAULT 0"
                )
            example_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(examples)").fetchall()
            }
            if "source_file" not in example_columns:
                connection.execute(
                    "ALTER TABLE examples ADD COLUMN source_file TEXT NOT NULL DEFAULT ''"
                )
            quarantine_columns = {
                row["name"]
                for row in connection.execute(
                    "PRAGMA table_info(quarantined_incoming)"
                ).fetchall()
            }
            for column, definition in (
                ("releasable", "INTEGER NOT NULL DEFAULT 0"),
                ("released_contact_key", "TEXT"),
                ("released_at", "TEXT"),
            ):
                if column not in quarantine_columns:
                    connection.execute(
                        f"ALTER TABLE quarantined_incoming ADD COLUMN {column} {definition}"
                    )
            connection.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS idx_contacts_adapter_alias
                ON contacts(adapter_alias)
                WHERE adapter_alias IS NOT NULL AND adapter_alias <> ''
                """
            )
            # Create indexes that reference migrated columns only after the
            # additive ALTER TABLE steps above.  This keeps upgrades from older
            # development schemas fail-closed but recoverable.
            connection.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS idx_quarantine_released_incoming
                ON quarantined_incoming(released_incoming_id)
                WHERE released_incoming_id IS NOT NULL
                """
            )

    def import_export(self, export: ParsedExport) -> dict[str, int]:
        inserted_messages = 0
        inserted_examples = 0
        now = _utc_now()
        with self._lock, self.connection() as connection:
            connection.execute(
                """
                INSERT INTO contacts(contact_key, display_name, account_id, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(contact_key) DO UPDATE SET
                    display_name=excluded.display_name,
                    account_id=excluded.account_id,
                    updated_at=excluded.updated_at
                """,
                (export.conversation_id, export.conversation_name, export.conversation_id, now),
            )
            # A re-export can insert or remove lines at the beginning of the same
            # file. Rebuild that file atomically so stale indexes never mix with
            # the new content.
            connection.execute("DELETE FROM messages WHERE source_file=?", (export.source_file,))
            connection.execute("DELETE FROM examples WHERE source_file=?", (export.source_file,))
            # Older packaged databases stored precompiled examples with either an
            # empty source marker or ``compiled-local`` while preserving their
            # original source keys.  Remove only those migration rows for this
            # contact before rebuilding from the user's real export; otherwise a
            # safe re-import collides with the global source_key uniqueness rule.
            connection.execute(
                """
                DELETE FROM examples
                WHERE source_file IN ('', 'compiled-local') AND contact_key=?
                """,
                (export.conversation_id,),
            )
            for message in export.messages:
                source_key = hashlib.sha256(
                    f"{message.source_file}|{message.source_index}".encode("utf-8")
                ).hexdigest()
                cursor = connection.execute(
                    """
                    INSERT INTO messages(
                        source_key, contact_key, timestamp, sender_role,
                        sender_name, content, source_file, sequence_index
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        source_key,
                        export.conversation_id,
                        message.timestamp.isoformat(),
                        "self" if message.is_self else "other",
                        message.sender_name,
                        message.content,
                        message.source_file,
                        message.source_index,
                    ),
                )
                inserted_messages += cursor.rowcount
            for example in build_example_pairs(export):
                cursor = connection.execute(
                    """
                    INSERT INTO examples(
                        source_key, contact_key, timestamp, incoming_json, reply_json, source_file
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        example.source_key,
                        example.contact_key,
                        example.timestamp.isoformat(),
                        json.dumps(example.incoming_messages, ensure_ascii=False),
                        json.dumps(example.reply_messages, ensure_ascii=False),
                        export.source_file,
                    ),
                )
                inserted_examples += cursor.rowcount
        return {"messages": inserted_messages, "examples": inserted_examples}

    def list_contacts(self) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT c.*,
                    (SELECT COUNT(*) FROM messages m WHERE m.contact_key=c.contact_key) AS message_count,
                    (SELECT COUNT(*) FROM examples e WHERE e.contact_key=c.contact_key) AS example_count
                FROM contacts c ORDER BY c.display_name
                """
            ).fetchall()
        return [dict(row) for row in rows]

    RELATIONSHIPS = {
        "待确认",
        "亲近朋友",
        "普通朋友",
        "陌生人",
        "亲密对象",
        "家人",
        "工作同事",
        "客户/业务方",
    }

    def update_contact(
        self,
        contact_key: str,
        relationship: str,
        live_read_enabled: bool,
        adapter_alias: str = "",
    ) -> None:
        normalized_relationship = relationship.strip() or "待确认"
        if normalized_relationship not in self.RELATIONSHIPS:
            raise ValueError("未知联系人关系类型")
        normalized_alias = adapter_alias.strip() or None
        with self.connection() as connection:
            try:
                cursor = connection.execute(
                    """
                    UPDATE contacts
                    SET relationship=?, live_read_enabled=?, adapter_alias=?, updated_at=?
                    WHERE contact_key=?
                    """,
                    (
                        normalized_relationship,
                        int(live_read_enabled),
                        normalized_alias,
                        _utc_now(),
                        contact_key,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise ValueError("微信备注名已绑定到另一位联系人") from error
            if cursor.rowcount != 1:
                raise KeyError(contact_key)

    def contact_for_key(self, contact_key: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM contacts WHERE contact_key=?", (contact_key,)
            ).fetchone()
        return dict(row) if row else None

    def contact_for_name(self, name: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            rows = connection.execute(
                "SELECT * FROM contacts WHERE display_name=?", (name,)
            ).fetchall()
        if len(rows) > 1:
            raise ValueError("存在同名联系人，必须使用 contact_key 明确选择")
        return dict(rows[0]) if rows else None

    def contact_for_alias(self, alias: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            rows = connection.execute(
                "SELECT * FROM contacts WHERE adapter_alias=?", (alias,)
            ).fetchall()
        if len(rows) > 1:
            raise ValueError("微信备注名绑定不唯一")
        return dict(rows[0]) if rows else None

    def ensure_contact(self, key: str, name: str) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO contacts(contact_key, display_name, account_id, updated_at)
                VALUES (?, ?, ?, ?)
                """,
                (key, name, key, _utc_now()),
            )

    @staticmethod
    def adapter_identity_key(
        account_scope: str, adapter_kind: str, external_identity: str
    ) -> str:
        return hashlib.sha256(
            f"{account_scope}\x1f{adapter_kind}\x1f{external_identity}".encode(
                "utf-8"
            )
        ).hexdigest()

    @staticmethod
    def adapter_event_key(envelope: AdapterEnvelope) -> str:
        return hashlib.sha256(
            (
                f"{envelope.account_scope}\x1f{envelope.adapter_kind}\x1f"
                f"{envelope.event_id}"
            ).encode("utf-8")
        ).hexdigest()

    @staticmethod
    def global_incoming_id(event_key: str) -> str:
        """Return the one canonical incoming ID for a captured adapter event."""

        return f"global-in:{event_key}"

    def quarantined_event(self, event_key: str) -> dict[str, Any] | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM quarantined_incoming WHERE event_key=?", (event_key,)
            ).fetchone()
        return dict(row) if row else None

    def observe_adapter_identity(self, envelope: AdapterEnvelope) -> dict[str, Any]:
        """Record an untrusted identity without creating or changing contacts."""

        identity_key = self.adapter_identity_key(
            envelope.account_scope,
            envelope.adapter_kind,
            envelope.external_identity,
        )
        now = _utc_now()
        with self._lock, self.connection() as connection:
            if envelope.identity_quality == "uia_runtime":
                # UIA runtime IDs have no cross-restart identity guarantee. A
                # newly observed run-scoped identity for the same exact alias
                # invalidates the older approval before the new identity can be
                # presented for explicit binding.
                connection.execute(
                    """
                    UPDATE quarantined_incoming
                    SET releasable=0, reason='identity_generation_expired',
                        updated_at=?
                    WHERE status='pending' AND identity_key IN (
                        SELECT identity_key FROM adapter_identities
                        WHERE account_scope=? AND adapter_kind=?
                          AND identity_quality='uia_runtime'
                          AND adapter_alias=?
                          AND status IN ('pending','conflict','approved')
                          AND external_identity<>?
                    )
                    """,
                    (
                        now,
                        envelope.account_scope,
                        envelope.adapter_kind,
                        envelope.adapter_alias,
                        envelope.external_identity,
                    ),
                )
                connection.execute(
                    """
                    UPDATE adapter_identities
                    SET status='stale', last_seen_at=?
                    WHERE account_scope=? AND adapter_kind=?
                      AND identity_quality='uia_runtime'
                      AND adapter_alias=?
                      AND status IN ('pending','conflict','approved')
                      AND external_identity<>?
                    """,
                    (
                        now,
                        envelope.account_scope,
                        envelope.adapter_kind,
                        envelope.adapter_alias,
                        envelope.external_identity,
                    ),
                )
            connection.execute(
                """
                INSERT INTO adapter_identities(
                    identity_key, account_scope, adapter_kind, external_identity,
                    identity_quality, adapter_alias, last_seen_alias, contact_key,
                    status, first_seen_at, last_seen_at, approved_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 'pending', ?, ?, NULL)
                ON CONFLICT(account_scope, adapter_kind, external_identity)
                DO UPDATE SET
                    identity_quality=excluded.identity_quality,
                    last_seen_alias=excluded.last_seen_alias,
                    last_seen_at=excluded.last_seen_at,
                    status=CASE
                        WHEN adapter_identities.adapter_alias <> excluded.last_seen_alias
                        THEN 'conflict'
                        ELSE adapter_identities.status
                    END
                """,
                (
                    identity_key,
                    envelope.account_scope,
                    envelope.adapter_kind,
                    envelope.external_identity,
                    envelope.identity_quality,
                    envelope.adapter_alias,
                    envelope.adapter_alias,
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM adapter_identities WHERE identity_key=?",
                (identity_key,),
            ).fetchone()
        if row is None:
            raise RuntimeError("适配器身份写入后无法读取")
        return dict(row)

    def adapter_identity_for_envelope(
        self, envelope: AdapterEnvelope
    ) -> dict[str, Any] | None:
        identity_key = self.adapter_identity_key(
            envelope.account_scope,
            envelope.adapter_kind,
            envelope.external_identity,
        )
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM adapter_identities WHERE identity_key=?",
                (identity_key,),
            ).fetchone()
        return dict(row) if row else None

    def quarantine_adapter_envelope(
        self,
        envelope: AdapterEnvelope,
        *,
        reason: str,
        identity_key: str | None,
        releasable: bool,
        retain_text: bool,
    ) -> bool:
        """Persist an event outside the message/model pipeline.

        Group, service and malformed events are recorded without their body so
        excluded conversations can be audited without retaining their content.
        """

        event_key = self.adapter_event_key(envelope)
        now = _utc_now()
        metadata: dict[str, Any] = {}
        for key in self._SAFE_ADAPTER_METADATA_FIELDS:
            if key not in envelope.metadata:
                continue
            value = envelope.metadata.get(key)
            if value is None or isinstance(value, (bool, int, float)):
                metadata[key] = value
            elif isinstance(value, str):
                metadata[key] = value[:500]
        with self._lock, self.connection() as connection:
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO quarantined_incoming(
                    event_key, external_event_id, identity_key, account_scope,
                    adapter_kind, external_identity, identity_quality,
                    adapter_alias, chat_type, sender_role, message_type, text,
                    occurred_at, metadata_json, reason, releasable, status,
                    released_incoming_id, released_contact_key, released_at,
                    error, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                          'pending', NULL, NULL, NULL, NULL, ?, ?)
                """,
                (
                    event_key,
                    envelope.event_id,
                    identity_key,
                    envelope.account_scope,
                    envelope.adapter_kind,
                    envelope.external_identity,
                    envelope.identity_quality,
                    envelope.adapter_alias,
                    envelope.chat_type,
                    envelope.sender_role,
                    envelope.message_type,
                    envelope.text if retain_text else "",
                    envelope.timestamp.isoformat(),
                    json.dumps(metadata, ensure_ascii=False),
                    reason,
                    int(releasable),
                    now,
                    now,
                ),
            )
        return cursor.rowcount == 1

    def list_adapter_identities(self, limit: int = 500) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT ai.*, c.display_name, c.relationship, c.enabled,
                       c.live_read_enabled,
                       (SELECT COUNT(*) FROM quarantined_incoming q
                        WHERE q.identity_key=ai.identity_key
                          AND q.status='pending') AS pending_event_count
                FROM adapter_identities ai
                LEFT JOIN contacts c ON c.contact_key=ai.contact_key
                ORDER BY
                    CASE ai.status WHEN 'conflict' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,
                    ai.last_seen_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_quarantined_incoming(
        self, *, status: str = "pending", limit: int = 500
    ) -> list[dict[str, Any]]:
        if status not in {"pending", "released", "rejected"}:
            raise ValueError("未知隔离消息状态")
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT q.*, ai.status AS identity_status,
                       ai.contact_key AS bound_contact_key,
                       c.display_name AS bound_display_name
                FROM quarantined_incoming q
                LEFT JOIN adapter_identities ai ON ai.identity_key=q.identity_key
                LEFT JOIN contacts c ON c.contact_key=ai.contact_key
                WHERE q.status=?
                ORDER BY q.occurred_at DESC, q.rowid DESC
                LIMIT ?
                """,
                (status, limit),
            ).fetchall()
        output: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            try:
                item["metadata"] = json.loads(item.pop("metadata_json"))
            except (TypeError, json.JSONDecodeError):
                item["metadata"] = {}
            item["releasable"] = bool(item.get("releasable", 0))
            output.append(item)
        return output

    def bind_adapter_identity(
        self,
        *,
        identity_key: str,
        expected_alias: str,
        contact_key: str | None,
        display_name: str,
        relationship: str,
        create_new: bool,
        enable_live_read: bool,
    ) -> dict[str, Any]:
        """Explicitly approve one adapter identity without releasing old events."""

        expected_alias = expected_alias.strip()
        display_name = display_name.strip()
        normalized_relationship = relationship.strip() or "待确认"
        if normalized_relationship not in self.RELATIONSHIPS:
            raise ValueError("未知联系人关系类型")
        if not identity_key or not expected_alias:
            raise ValueError("身份键和精确备注名不能为空")
        if create_new == bool(contact_key):
            raise ValueError("必须且只能选择已有联系人或显式创建新联系人")
        now = _utc_now()
        with self._lock, self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            identity = connection.execute(
                "SELECT * FROM adapter_identities WHERE identity_key=?",
                (identity_key,),
            ).fetchone()
            if identity is None:
                raise KeyError(identity_key)
            if str(identity["status"]) not in {"pending", "conflict", "approved"}:
                raise ValueError("当前身份状态不允许绑定")
            if str(identity["last_seen_alias"]) != expected_alias:
                raise ValueError("联系人备注名已变化，请刷新后重新确认")

            selected_key = (contact_key or "").strip()
            if create_new:
                if not display_name:
                    display_name = expected_alias
                selected_key = f"global:{identity_key[:32]}"
            if str(identity["status"]) == "approved":
                if str(identity["contact_key"] or "") != selected_key:
                    raise ValueError("已批准身份不能重新绑定到其他联系人")
                approved_contact = connection.execute(
                    "SELECT * FROM contacts WHERE contact_key=?", (selected_key,)
                ).fetchone()
                if approved_contact is None or str(
                    approved_contact["adapter_alias"] or ""
                ) != expected_alias:
                    raise ValueError("已批准身份与联系人备注绑定不一致")
                return dict(approved_contact)
            if create_new:
                try:
                    connection.execute(
                        """
                        INSERT INTO contacts(
                            contact_key, display_name, account_id, adapter_alias,
                            relationship, enabled, live_read_enabled, updated_at
                        ) VALUES (?, ?, ?, ?, ?, 1, ?, ?)
                        ON CONFLICT(contact_key) DO NOTHING
                        """,
                        (
                            selected_key,
                            display_name,
                            str(identity["external_identity"]),
                            expected_alias,
                            normalized_relationship,
                            int(enable_live_read),
                            now,
                        ),
                    )
                except sqlite3.IntegrityError as error:
                    raise ValueError(
                        "联系人备注名或外部身份已被其他联系人占用，已拒绝绑定"
                    ) from error
                created_contact = connection.execute(
                    "SELECT * FROM contacts WHERE contact_key=?", (selected_key,)
                ).fetchone()
                if created_contact is None or (
                    str(created_contact["account_id"] or "")
                    != str(identity["external_identity"])
                    or str(created_contact["adapter_alias"] or "") != expected_alias
                ):
                    raise ValueError("目标联系人键已存在且身份内容不一致，已拒绝绑定")
            else:
                contact = connection.execute(
                    "SELECT * FROM contacts WHERE contact_key=?",
                    (selected_key,),
                ).fetchone()
                if contact is None:
                    raise KeyError(selected_key)
                try:
                    connection.execute(
                        """
                        UPDATE contacts
                        SET adapter_alias=?, relationship=?, live_read_enabled=?,
                            updated_at=?
                        WHERE contact_key=?
                        """,
                        (
                            expected_alias,
                            normalized_relationship,
                            int(enable_live_read),
                            now,
                            selected_key,
                        ),
                    )
                except sqlite3.IntegrityError as error:
                    raise ValueError(
                        "联系人备注名已被其他联系人占用，已拒绝绑定"
                    ) from error

            try:
                cursor = connection.execute(
                    """
                    UPDATE adapter_identities
                    SET adapter_alias=?, last_seen_alias=?, contact_key=?,
                        status='approved', approved_at=?, last_seen_at=?
                    WHERE identity_key=? AND status IN ('pending','conflict','approved')
                    """,
                    (
                        expected_alias,
                        expected_alias,
                        selected_key,
                        now,
                        now,
                        identity_key,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise ValueError("同一微信账号存在重复备注名，已拒绝绑定") from error
            if cursor.rowcount != 1:
                raise RuntimeError("身份绑定状态已变化，请刷新后重试")
            contact = connection.execute(
                "SELECT * FROM contacts WHERE contact_key=?", (selected_key,)
            ).fetchone()
        if contact is None:
            raise RuntimeError("绑定后的联系人不存在")
        return dict(contact)

    def reject_quarantined_event(self, event_key: str) -> bool:
        with self._lock, self.connection() as connection:
            cursor = connection.execute(
                """
                UPDATE quarantined_incoming
                SET status='rejected', updated_at=?, error=NULL
                WHERE event_key=? AND status='pending'
                """,
                (_utc_now(), event_key),
            )
        return cursor.rowcount == 1

    def promote_quarantined_event(
        self, event_key: str
    ) -> tuple[IncomingMessage, bool]:
        """Atomically turn one approved, releasable event into received input."""

        now = _utc_now()
        with self._lock, self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT q.*, ai.status AS identity_status,
                       ai.contact_key AS bound_contact_key,
                       ai.adapter_alias AS approved_alias,
                       ai.account_scope AS identity_account_scope,
                       ai.adapter_kind AS identity_adapter_kind,
                       ai.external_identity AS identity_external_identity,
                       ai.identity_quality AS approved_identity_quality,
                       c.display_name, c.adapter_alias AS contact_adapter_alias,
                       c.enabled, c.live_read_enabled
                FROM quarantined_incoming q
                LEFT JOIN adapter_identities ai ON ai.identity_key=q.identity_key
                LEFT JOIN contacts c ON c.contact_key=ai.contact_key
                WHERE q.event_key=?
                """,
                (event_key,),
            ).fetchone()
            if row is None:
                raise KeyError(event_key)
            if str(row["status"]) == "released":
                existing = connection.execute(
                    "SELECT * FROM incoming WHERE external_id=?",
                    (str(row["released_incoming_id"]),),
                ).fetchone()
                if existing is None:
                    raise RuntimeError("隔离记录已释放但对应入站消息缺失")
                metadata = json.loads(str(existing["metadata_json"]))
                return (
                    IncomingMessage(
                        external_id=str(existing["external_id"]),
                        contact_key=str(existing["contact_key"]),
                        contact_name=str(existing["contact_name"]),
                        text=str(existing["text"]),
                        timestamp=datetime.fromisoformat(str(existing["received_at"])),
                        metadata=metadata if isinstance(metadata, dict) else {},
                    ),
                    False,
                )
            if str(row["status"]) != "pending":
                raise ValueError("当前隔离消息状态不允许释放")
            if not bool(row["releasable"]):
                raise PermissionError("此事件缺少稳定消息标识，不能释放到草稿队列")
            if str(row["identity_status"] or "") != "approved":
                raise PermissionError("联系人身份尚未批准")
            if (
                str(row["account_scope"]) != str(row["identity_account_scope"] or "")
                or str(row["adapter_kind"])
                != str(row["identity_adapter_kind"] or "")
                or str(row["external_identity"])
                != str(row["identity_external_identity"] or "")
                or str(row["chat_type"]).lower() != "friend"
                or str(row["sender_role"]).lower() != "friend"
                or str(row["message_type"]).lower() != "text"
                or str(row["identity_quality"])
                != str(row["approved_identity_quality"] or "")
            ):
                raise PermissionError("隔离消息身份或会话类型校验失败")
            if str(row["approved_alias"] or "") != str(row["adapter_alias"]):
                raise PermissionError("联系人备注名已漂移，必须重新核验身份")
            contact_key_value = str(row["bound_contact_key"] or "")
            if not contact_key_value or not bool(row["enabled"]) or not bool(
                row["live_read_enabled"]
            ):
                raise PermissionError("联系人已停用或尚未开启自动读取")
            if str(row["contact_adapter_alias"] or "") != str(
                row["adapter_alias"]
            ):
                raise PermissionError("联系人当前备注绑定与隔离事件不一致")
            text = str(row["text"] or "").strip()
            if not text:
                raise ValueError("隔离消息正文为空，不能生成草稿")

            external_id = self.global_incoming_id(event_key)
            raw_metadata = json.loads(str(row["metadata_json"] or "{}"))
            metadata = raw_metadata if isinstance(raw_metadata, dict) else {}
            metadata.update(
                {
                    "source": "wxauto4_global_readonly",
                    "adapter_kind": str(row["adapter_kind"]),
                    "adapter_alias": str(row["adapter_alias"]),
                    "identity_key": str(row["identity_key"]),
                    "account_scope": str(row["account_scope"]),
                    "external_identity": str(row["external_identity"]),
                    "identity_quality": str(row["identity_quality"]),
                    "chat_type": "friend",
                    "peer_type": "friend",
                    "quarantine_event_key": event_key,
                }
            )
            existing = connection.execute(
                "SELECT * FROM incoming WHERE external_id=?", (external_id,)
            ).fetchone()
            created = existing is None
            if existing is None:
                connection.execute(
                    """
                    INSERT INTO incoming(
                        external_id, contact_key, contact_name, text,
                        received_at, metadata_json, status
                    ) VALUES (?, ?, ?, ?, ?, ?, 'received')
                    """,
                    (
                        external_id,
                        contact_key_value,
                        str(row["display_name"]),
                        text,
                        str(row["occurred_at"]),
                        json.dumps(metadata, ensure_ascii=False),
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO messages(
                        source_key, contact_key, timestamp, sender_role,
                        sender_name, content, source_file, sequence_index
                    ) VALUES (?, ?, ?, 'other', ?, ?, 'live', 0)
                    """,
                    (
                        f"live-in:{external_id}",
                        contact_key_value,
                        str(row["occurred_at"]),
                        str(row["display_name"]),
                        text,
                    ),
                )
            else:
                if (
                    str(existing["contact_key"]) != contact_key_value
                    or str(existing["text"]) != text
                ):
                    raise RuntimeError("隔离消息幂等键与已有入站内容冲突")
            cursor = connection.execute(
                """
                UPDATE quarantined_incoming
                SET status='released', released_incoming_id=?,
                    released_contact_key=?, released_at=?, updated_at=?, error=NULL
                WHERE event_key=? AND status='pending'
                """,
                (external_id, contact_key_value, now, now, event_key),
            )
            if cursor.rowcount != 1:
                raise RuntimeError("隔离消息状态并发变化，已回滚释放")

        return (
            IncomingMessage(
                external_id=external_id,
                contact_key=contact_key_value,
                contact_name=str(row["display_name"]),
                text=text,
                timestamp=datetime.fromisoformat(str(row["occurred_at"])),
                metadata=metadata,
            ),
            created,
        )

    def examples_for_contact(self, contact_key: str, limit: int = 1200) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT source_key, timestamp, incoming_json, reply_json
                FROM examples WHERE contact_key=? ORDER BY timestamp DESC LIMIT ?
                """,
                (contact_key, limit),
            ).fetchall()
        return [
            {
                "id": row["source_key"],
                "timestamp": row["timestamp"],
                "incoming": json.loads(row["incoming_json"]),
                "reply": json.loads(row["reply_json"]),
            }
            for row in rows
        ]

    def style_source_messages(self) -> list[dict[str, str]]:
        """Return local-only self messages used to build an anonymous style summary.

        The caller must never forward these rows verbatim across contacts.  They
        intentionally include every historical self-authored text message so the
        aggregate fingerprint reflects all configured chat exports.
        """
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT m.contact_key, c.relationship, m.content, m.source_file
                FROM messages m
                JOIN contacts c ON c.contact_key=m.contact_key
                WHERE m.sender_role='self'
                  AND m.source_file NOT IN ('live', 'live-approved')
                ORDER BY m.contact_key, m.timestamp, m.sequence_index
                """
            ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def record_knowledge_source(
        self,
        path: Path,
        *,
        kind: str,
        item_count: int,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        resolved = path.resolve()
        stat = resolved.stat()
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO knowledge_sources(
                    source_path, source_name, kind, sha256, size_bytes,
                    modified_ns, item_count, metadata_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(source_path) DO UPDATE SET
                    source_name=excluded.source_name,
                    kind=excluded.kind,
                    sha256=excluded.sha256,
                    size_bytes=excluded.size_bytes,
                    modified_ns=excluded.modified_ns,
                    item_count=excluded.item_count,
                    metadata_json=excluded.metadata_json,
                    updated_at=excluded.updated_at
                """,
                (
                    str(resolved),
                    resolved.name,
                    kind,
                    self._sha256(resolved),
                    stat.st_size,
                    stat.st_mtime_ns,
                    int(item_count),
                    json.dumps(metadata or {}, ensure_ascii=False, sort_keys=True),
                    _utc_now(),
                ),
            )

    def knowledge_summary(self) -> dict[str, Any]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT source_name, kind, sha256, size_bytes, item_count,
                       metadata_json, updated_at
                FROM knowledge_sources ORDER BY kind, source_name
                """
            ).fetchall()
        sources: list[dict[str, Any]] = []
        for row in rows:
            try:
                metadata = json.loads(str(row["metadata_json"]))
                if not isinstance(metadata, dict):
                    metadata = {}
            except json.JSONDecodeError:
                metadata = {}
            sources.append(
                {
                    "name": str(row["source_name"]),
                    "kind": str(row["kind"]),
                    "sha256": str(row["sha256"]),
                    "size_bytes": int(row["size_bytes"]),
                    "item_count": int(row["item_count"]),
                    "metadata": metadata,
                    "updated_at": str(row["updated_at"]),
                }
            )
        return {
            "source_count": len(sources),
            "profile_files": sum(1 for item in sources if item["kind"] == "profile_xlsx"),
            "chat_files": sum(1 for item in sources if item["kind"] == "chat_export"),
            "sources": sources,
        }

    def prune_knowledge_manifest(self, active_paths: list[Path]) -> None:
        """Remove manifest rows for no-longer-configured sources, not source data."""
        normalized = [str(path.resolve()) for path in active_paths]
        with self.connection() as connection:
            if not normalized:
                connection.execute("DELETE FROM knowledge_sources")
                return
            placeholders = ",".join("?" for _ in normalized)
            connection.execute(
                f"DELETE FROM knowledge_sources WHERE source_path NOT IN ({placeholders})",
                normalized,
            )

    def recent_context(
        self,
        contact_key: str,
        limit: int = 12,
        *,
        before_timestamp: datetime | None = None,
        window_hours: int = 72,
    ) -> list[dict[str, str]]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT timestamp, sender_role, content FROM messages
                WHERE contact_key=? ORDER BY timestamp DESC, sequence_index DESC LIMIT ?
                """,
                (contact_key, max(limit * 5, 60)),
            ).fetchall()
        if before_timestamp is None:
            return [dict(row) for row in reversed(rows[:limit])]
        anchor = before_timestamp
        if anchor.tzinfo is not None:
            anchor = anchor.astimezone().replace(tzinfo=None)
        selected: list[sqlite3.Row] = []
        for row in rows:
            try:
                timestamp = datetime.fromisoformat(str(row["timestamp"]))
                if timestamp.tzinfo is not None:
                    timestamp = timestamp.astimezone().replace(tzinfo=None)
                age_hours = (anchor - timestamp).total_seconds() / 3600
            except ValueError:
                continue
            if 0 <= age_hours <= window_hours:
                selected.append(row)
                if len(selected) >= limit:
                    break
        return [dict(row) for row in reversed(selected)]

    def register_incoming(self, incoming: IncomingMessage) -> bool:
        metadata_json = json.dumps(incoming.metadata, ensure_ascii=False)
        incoming_source = str(incoming.metadata.get("source", "direct-test"))
        with self._lock, self.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if incoming_source == "wxauto4_global_readonly":
                identity_key = str(incoming.metadata.get("identity_key", ""))
                adapter_alias = str(incoming.metadata.get("adapter_alias", ""))
                identity = connection.execute(
                    """
                    SELECT ai.*, c.adapter_alias AS contact_adapter_alias,
                           c.enabled, c.live_read_enabled
                    FROM adapter_identities ai
                    JOIN contacts c ON c.contact_key=ai.contact_key
                    WHERE ai.identity_key=?
                    """,
                    (identity_key,),
                ).fetchone()
                if identity is None or (
                    str(identity["status"]) != "approved"
                    or str(identity["contact_key"] or "") != incoming.contact_key
                    or str(identity["adapter_alias"]) != adapter_alias
                    or str(identity["last_seen_alias"]) != adapter_alias
                    or str(identity["contact_adapter_alias"] or "") != adapter_alias
                    or str(identity["account_scope"])
                    != str(incoming.metadata.get("account_scope", ""))
                    or str(identity["external_identity"])
                    != str(incoming.metadata.get("external_identity", ""))
                    or str(identity["identity_quality"])
                    != str(incoming.metadata.get("identity_quality", ""))
                    or not bool(identity["enabled"])
                    or not bool(identity["live_read_enabled"])
                ):
                    raise PermissionError(
                        "全局只读身份绑定在入站提交前已变化，已拒绝消息"
                    )
            existing_before = connection.execute(
                "SELECT 1 FROM incoming WHERE external_id=?", (incoming.external_id,)
            ).fetchone()
            if existing_before is None:
                connection.execute(
                    """
                    INSERT OR IGNORE INTO contacts(
                        contact_key, display_name, account_id, updated_at
                    ) VALUES (?, ?, ?, ?)
                    """,
                    (
                        incoming.contact_key,
                        incoming.contact_name,
                        incoming.contact_key,
                        _utc_now(),
                    ),
                )
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO incoming(
                    external_id, contact_key, contact_name, text,
                    received_at, metadata_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, 'received')
                """,
                (
                    incoming.external_id,
                    incoming.contact_key,
                    incoming.contact_name,
                    incoming.text,
                    incoming.timestamp.isoformat(),
                    metadata_json,
                ),
            )
            inserted = cursor.rowcount == 1
            canonical = connection.execute(
                "SELECT * FROM incoming WHERE external_id=?",
                (incoming.external_id,),
            ).fetchone()
            if canonical is None:
                raise RuntimeError("入站消息写入后无法读取")
            try:
                canonical_metadata = json.loads(str(canonical["metadata_json"]))
            except json.JSONDecodeError as error:
                raise RuntimeError("已有入站消息 metadata 损坏，已拒绝处理") from error
            if not isinstance(canonical_metadata, dict):
                raise RuntimeError("已有入站消息 metadata 不是对象，已拒绝处理")
            if not inserted:
                existing_source = str(
                    canonical_metadata.get("source", "direct-test")
                )
                if (
                    str(canonical["contact_key"]) != incoming.contact_key
                    or str(canonical["text"]) != incoming.text
                    or existing_source != incoming_source
                ):
                    raise ValueError(
                        "入站 external_id 与已有联系人、正文或来源冲突，已拒绝处理"
                    )
                if incoming_source == "wxauto4_global_readonly":
                    immutable_identity_fields = (
                        "account_scope",
                        "adapter_kind",
                        "adapter_alias",
                        "identity_key",
                        "external_identity",
                        "identity_quality",
                        "chat_type",
                        "peer_type",
                    )
                    if any(
                        str(canonical_metadata.get(field, ""))
                        != str(incoming.metadata.get(field, ""))
                        for field in immutable_identity_fields
                    ):
                        raise ValueError(
                            "入站 external_id 与已有微信身份信封冲突，已拒绝处理"
                        )
            if inserted:
                connection.execute(
                    """
                    INSERT OR IGNORE INTO messages(
                        source_key, contact_key, timestamp, sender_role,
                        sender_name, content, source_file, sequence_index
                    ) VALUES (?, ?, ?, 'other', ?, ?, 'live', 0)
                    """,
                    (
                        f"live-in:{incoming.external_id}",
                        incoming.contact_key,
                        incoming.timestamp.isoformat(),
                        incoming.contact_name,
                        incoming.text,
                    ),
                )
                stored_message = connection.execute(
                    "SELECT contact_key, content FROM messages WHERE source_key=?",
                    (f"live-in:{incoming.external_id}",),
                ).fetchone()
                if stored_message is None or (
                    str(stored_message["contact_key"]) != incoming.contact_key
                    or str(stored_message["content"]) != incoming.text
                ):
                    raise RuntimeError("入站消息账本与消息正文不一致，已回滚")
            transient_metadata = {
                key: value
                for key, value in incoming.metadata.items()
                if isinstance(key, str) and key.startswith("_")
            }
            incoming.contact_key = str(canonical["contact_key"])
            incoming.contact_name = str(canonical["contact_name"])
            incoming.text = str(canonical["text"])
            incoming.timestamp = datetime.fromisoformat(str(canonical["received_at"]))
            incoming.metadata = {**canonical_metadata, **transient_metadata}
            claimed = connection.execute(
                """
                UPDATE incoming SET status='processing'
                WHERE external_id=? AND status='received'
                """,
                (incoming.external_id,),
            )
        return claimed.rowcount == 1

    def release_incoming(self, external_id: str) -> None:
        with self.connection() as connection:
            connection.execute(
                "UPDATE incoming SET status='received' WHERE external_id=? AND status='processing'",
                (external_id,),
            )

    def received_incoming(self, limit: int = 1000) -> list[IncomingMessage]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT * FROM incoming WHERE status='received'
                ORDER BY rowid LIMIT ?
                """,
                (limit,),
            ).fetchall()
        output: list[IncomingMessage] = []
        for row in rows:
            try:
                metadata = json.loads(row["metadata_json"])
                if not isinstance(metadata, dict):
                    metadata = {}
            except json.JSONDecodeError:
                metadata = {}
            output.append(
                IncomingMessage(
                    external_id=str(row["external_id"]),
                    contact_key=str(row["contact_key"]),
                    contact_name=str(row["contact_name"]),
                    text=str(row["text"]),
                    timestamp=datetime.fromisoformat(str(row["received_at"])),
                    metadata=metadata,
                )
            )
        return output

    def append_outgoing_messages(
        self,
        *,
        draft_id: str,
        contact_key: str,
        messages: list[str],
    ) -> None:
        # Chat exports and live adapters use local wall-clock timestamps. Keep this
        # column consistent so lexical ISO ordering remains chronological.
        timestamp = datetime.now().isoformat()
        with self.connection() as connection:
            for index, content in enumerate(messages):
                connection.execute(
                    """
                    INSERT OR IGNORE INTO messages(
                        source_key, contact_key, timestamp, sender_role,
                        sender_name, content, source_file, sequence_index
                    ) VALUES (?, ?, ?, 'self', '本人', ?, 'live-approved', ?)
                    """,
                    (
                        f"live-out:{draft_id}:{index}",
                        contact_key,
                        timestamp,
                        content,
                        index + 1,
                    ),
                )

    def recover_incomplete(self) -> dict[str, int]:
        """Fail closed after a crash; no uncertain send is ever retried."""
        now = _utc_now()
        with self._lock, self.connection() as connection:
            attempts = connection.execute(
                """
                UPDATE send_attempts
                SET status='uncertain', updated_at=?, error='进程中断，发送结果需人工核对'
                WHERE status='attempting'
                """,
                (now,),
            ).rowcount
            drafts = connection.execute(
                """
                UPDATE drafts
                SET status='uncertain', updated_at=?, error='进程中断，禁止自动重试'
                WHERE status IN ('approved','sending')
                """,
                (now,),
            ).rowcount
            incoming = connection.execute(
                """
                UPDATE incoming SET status='received'
                WHERE status='processing'
                  AND NOT EXISTS (
                    SELECT 1 FROM drafts d WHERE d.incoming_id=incoming.external_id
                  )
                """
            ).rowcount
            quarantined = connection.execute(
                """
                UPDATE quarantined_incoming
                SET status='pending', updated_at=?,
                    error='进程中断，隔离消息等待重新释放'
                WHERE status='releasing'
                """,
                (now,),
            ).rowcount
        return {
            "send_attempts": attempts,
            "drafts": drafts,
            "incoming": incoming,
            "quarantined": quarantined,
        }

    def create_draft(
        self,
        incoming: IncomingMessage,
        model_draft: ModelDraft,
        risk: RiskDecision,
        model: str,
        status: str = "pending",
        error: str | None = None,
    ) -> str:
        draft_id = uuid.uuid4().hex
        now = _utc_now()
        with self._lock, self.connection() as connection:
            connection.execute(
                """
                INSERT INTO drafts(
                    id, incoming_id, contact_key, contact_name, incoming_text,
                    messages_json, risk_level, risk_reasons_json, confidence,
                    needs_user_input, uncertainties_json, status, model, send_key,
                    created_at, updated_at, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    draft_id,
                    incoming.external_id,
                    incoming.contact_key,
                    incoming.contact_name,
                    incoming.text,
                    json.dumps(model_draft.messages, ensure_ascii=False),
                    risk.level,
                    json.dumps(risk.reasons, ensure_ascii=False),
                    model_draft.confidence,
                    int(model_draft.needs_user_input),
                    json.dumps(model_draft.uncertainties, ensure_ascii=False),
                    status,
                    model,
                    uuid.uuid4().hex,
                    now,
                    now,
                    error,
                ),
            )
            connection.execute(
                "UPDATE incoming SET status=? WHERE external_id=?",
                (status, incoming.external_id),
            )
        return draft_id

    @staticmethod
    def _decode_draft(
        row: sqlite3.Row, attempts: list[dict[str, Any]] | None = None
    ) -> dict[str, Any]:
        output = dict(row)
        metadata_raw = output.pop("incoming_metadata_json", "{}")
        try:
            incoming_metadata = json.loads(metadata_raw or "{}")
        except (TypeError, json.JSONDecodeError):
            incoming_metadata = {}
        output["incoming_source"] = str(incoming_metadata.get("source", ""))
        output["messages"] = json.loads(output.pop("messages_json"))
        output["risk_reasons"] = json.loads(output.pop("risk_reasons_json"))
        output["uncertainties"] = json.loads(output.pop("uncertainties_json"))
        output["needs_user_input"] = bool(output.get("needs_user_input", 0))
        output["send_attempts"] = attempts or []
        return output

    def list_drafts(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT d.*, i.metadata_json AS incoming_metadata_json
                FROM drafts d
                JOIN incoming i ON i.external_id=d.incoming_id
                ORDER BY d.created_at DESC, d.rowid DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
            draft_ids = [str(row["id"]) for row in rows]
            attempts_by_draft: dict[str, list[dict[str, Any]]] = {}
            if draft_ids:
                placeholders = ",".join("?" for _ in draft_ids)
                attempt_rows = connection.execute(
                    f"""
                    SELECT * FROM send_attempts WHERE draft_id IN ({placeholders})
                    ORDER BY draft_id, message_index
                    """,
                    draft_ids,
                ).fetchall()
                for attempt in attempt_rows:
                    attempts_by_draft.setdefault(str(attempt["draft_id"]), []).append(
                        dict(attempt)
                    )
        return [
            self._decode_draft(row, attempts_by_draft.get(str(row["id"]), []))
            for row in rows
        ]

    def get_draft(self, draft_id: str) -> dict[str, Any]:
        with self.connection() as connection:
            row = connection.execute(
                """
                SELECT d.*, i.metadata_json AS incoming_metadata_json
                FROM drafts d
                JOIN incoming i ON i.external_id=d.incoming_id
                WHERE d.id=?
                """,
                (draft_id,),
            ).fetchone()
            attempts = connection.execute(
                """
                SELECT * FROM send_attempts WHERE draft_id=? ORDER BY message_index
                """,
                (draft_id,),
            ).fetchall()
        if row is None:
            raise KeyError(draft_id)
        return self._decode_draft(row, [dict(attempt) for attempt in attempts])

    def transition_draft(
        self,
        draft_id: str,
        expected_statuses: tuple[str, ...],
        new_status: str,
        messages: list[str] | None = None,
        error: str | None = None,
    ) -> bool:
        placeholders = ",".join("?" for _ in expected_statuses)
        assignments = ["status=?", "updated_at=?", "error=?"]
        parameters: list[Any] = [new_status, _utc_now(), error]
        if messages is not None:
            assignments.append("messages_json=?")
            parameters.append(json.dumps(messages, ensure_ascii=False))
        parameters.extend([draft_id, *expected_statuses])
        sql = (
            f"UPDATE drafts SET {', '.join(assignments)} "
            f"WHERE id=? AND status IN ({placeholders})"
        )
        with self._lock, self.connection() as connection:
            cursor = connection.execute(sql, parameters)
        return cursor.rowcount == 1

    def claim_draft_for_approval(
        self,
        draft_id: str,
        messages: list[str],
        not_before: datetime,
    ) -> bool:
        # ``not_before`` remains in the signature for API compatibility. Pending
        # drafts now wait for explicit review instead of expiring or being skipped
        # when a newer message arrives.
        del not_before
        with self._lock, self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM drafts WHERE id=?", (draft_id,)
            ).fetchone()
            if row is None:
                raise KeyError(draft_id)
            if row["status"] != "pending":
                return False
            cursor = connection.execute(
                """
                UPDATE drafts SET status='approved', messages_json=?, updated_at=?, error=NULL
                WHERE id=? AND status='pending'
                """,
                (json.dumps(messages, ensure_ascii=False), _utc_now(), draft_id),
            )
        return cursor.rowcount == 1

    def prepare_send_attempts(
        self,
        draft_id: str,
        send_key: str,
        messages: list[str],
    ) -> None:
        now = _utc_now()
        with self._lock, self.connection() as connection:
            for index, content in enumerate(messages):
                connection.execute(
                    """
                    INSERT INTO send_attempts(
                        draft_id, message_index, send_key, content,
                        status, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, 'prepared', ?, ?)
                    """,
                    (draft_id, index, f"{send_key}:{index}", content, now, now),
                )

    def transition_send_attempt(
        self,
        draft_id: str,
        message_index: int,
        expected_status: str,
        new_status: str,
        error: str | None = None,
    ) -> bool:
        with self._lock, self.connection() as connection:
            cursor = connection.execute(
                """
                UPDATE send_attempts SET status=?, updated_at=?, error=?
                WHERE draft_id=? AND message_index=? AND status=?
                """,
                (
                    new_status,
                    _utc_now(),
                    error,
                    draft_id,
                    message_index,
                    expected_status,
                ),
            )
        return cursor.rowcount == 1

    def append_outgoing_message(
        self,
        *,
        draft_id: str,
        contact_key: str,
        message_index: int,
        content: str,
    ) -> None:
        timestamp = datetime.now().isoformat()
        with self.connection() as connection:
            connection.execute(
                """
                INSERT OR IGNORE INTO messages(
                    source_key, contact_key, timestamp, sender_role,
                    sender_name, content, source_file, sequence_index
                ) VALUES (?, ?, ?, 'self', '本人', ?, 'live-approved', ?)
                """,
                (
                    f"live-out:{draft_id}:{message_index}",
                    contact_key,
                    timestamp,
                    content,
                    message_index + 1,
                ),
            )

    def counts(self) -> dict[str, int]:
        with self.connection() as connection:
            return {
                table: int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
                for table in (
                    "contacts",
                    "messages",
                    "examples",
                    "incoming",
                    "drafts",
                    "send_attempts",
                    "adapter_identities",
                    "quarantined_incoming",
                )
            }
