@echo off
cd /d "%~dp0"
python -X utf8 -m persona_agent --offline-fake-model
if errorlevel 1 pause
