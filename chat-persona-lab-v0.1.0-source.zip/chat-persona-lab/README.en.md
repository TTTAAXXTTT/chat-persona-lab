# Chat Persona Lab

Local chat analysis, communication-style memory, and human-reviewed reply drafts.

[中文文档](README.md)

Import chat text exports and a structured XLSX profile, build a local SQLite
index, compute statistics from your own messages, and retrieve contact-scoped
examples to help draft replies. The default mode uses a local JSONL adapter,
disables cloud processing, and never sends a message to WeChat.

Version 0.1.0 is experimental. This public edition contains fictional examples
only. It does not decrypt WeChat databases, extract chat histories, transcribe
audio, train a model, or infer verified personality facts.

## Quick start

Python 3.11+ is required. The source checkout's core needs no third-party runtime
packages.

```sh
python scripts/create_demo.py
python -m persona_agent --analyze-only
python -m persona_agent --offline-fake-model
```

Open http://127.0.0.1:8765. Select a fictional contact, submit a short greeting,
edit the draft, then approve or reject it. With default settings, approval is
recorded as `approved_not_sent`. The fake model returns deterministic fixtures;
it demonstrates the workflow rather than AI response quality.

The demo generator preserves an existing `.env` and workbook. Place private
input files outside the repository or under ignored `private/`, then configure
their locations in your local `.env`. The accepted text format is documented
in [DATA_FORMAT](docs/DATA_FORMAT.md). The UI and detailed guides are in Chinese.

## Capabilities

- Text conversation parsing, local source manifests, message counts, example
  pairs, and aggregate self-message style statistics.
- XLSX profile retrieval with relationship and disclosure boundaries.
- Per-contact context and historical reply examples.
- Local browser review, editing, rejection, approval, and uncertain-send states.
- Optional DeepSeek official / OpenCode Go generation, with an explicit local
  key and cloud-processing opt-in.
- JSONL inbox/outbox and optional experimental Windows desktop adapters.

Cloud mode can transmit selected messages, profile rows, context, examples,
and aggregate style data to your chosen provider. Redaction is best effort,
not an anonymity guarantee. SQLite and backups are plaintext. Do not expose
the local HTTP service publicly. Provider availability, terms, retention, and
pricing are controlled by the provider, not this project.

## Development

```sh
python -m unittest discover -s tests -v
python scripts/check_public.py
python scripts/smoke_test.py
python scripts/build_release.py
```

Tests mock WeChat and model network calls. Live provider calls and real desktop
messaging are not part of automated acceptance. The release script packages
curated source files rather than your full working directory.

See [architecture](docs/ARCHITECTURE.md), [configuration](docs/CONFIGURATION.md),
[privacy](docs/PRIVACY.md), [WeChat limitations](docs/WECHAT.md),
[contributing](CONTRIBUTING.md), and [third-party notices](NOTICE.md).

Licensed under the [MIT License](LICENSE).
