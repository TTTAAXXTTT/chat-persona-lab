# Security and privacy reports

For a vulnerability, use the repository's private vulnerability reporting
facility if enabled. Otherwise open a minimal issue asking for a private
reporting channel without exploit details or personal data. Do not publish
credentials, real messages, database files, screenshots of accounts, or private
paths in an issue.

The current 0.1.x series is experimental. There is no guaranteed response time
or production security support. The application is designed to bind only to
loopback. Do not expose it through port forwarding or a public reverse proxy.

If a key is exposed, revoke it at the provider before cleaning the repository.
Removing a file from the latest commit does not remove it from Git history.
See [privacy](docs/PRIVACY.md) for storage and cloud-processing boundaries.
