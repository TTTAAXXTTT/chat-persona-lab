from __future__ import annotations

import http.client
import json
import tempfile
import threading
import time
import unittest
from datetime import datetime
from pathlib import Path
from typing import Callable

from persona_agent.adapters import JsonlFileAdapter, MockAdapter
from persona_agent.deepseek import FakeDraftModel
from persona_agent.models import IncomingMessage
from persona_agent.retrieval import ProfileRetriever
from persona_agent.server import AppServer, Handler
from persona_agent.service import PersonaService
from persona_agent.store import Store
from tests.test_service import test_config


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = PROJECT_ROOT / "persona_agent" / "web"


def wait_until(predicate: Callable[[], bool], timeout: float = 2.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    raise AssertionError("condition was not met before timeout")


def jsonl_record() -> str:
    return json.dumps(
        {
            "contact_key": "contact-1",
            "contact_name": "测试联系人",
            "text": "完全相同的消息",
        },
        ensure_ascii=False,
    )


class RunningServer:
    def __init__(self, service: object | None = None) -> None:
        self.server = AppServer(
            ("127.0.0.1", 0),
            Handler,
            service=service or object(),  # Most boundary tests never call service methods.
            store=object(),
            web_root=WEB_ROOT,
        )
        self.thread = threading.Thread(
            target=self.server.serve_forever,
            kwargs={"poll_interval": 0.01},
            daemon=True,
        )

    @property
    def port(self) -> int:
        return int(self.server.server_address[1])

    def __enter__(self) -> "RunningServer":
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def request(
        self,
        method: str,
        path: str,
        *,
        body: str | bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=2)
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            response_body = response.read()
            return response.status, dict(response.getheaders()), response_body
        finally:
            connection.close()


class JsonlAdapterTests(unittest.TestCase):
    def test_identical_lines_at_different_offsets_have_distinct_ids(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inbox = root / "inbox.jsonl"
            line = jsonl_record()
            inbox.write_text(f"{line}\n{line}\n", encoding="utf-8")
            adapter = JsonlFileAdapter(inbox, root / "outbox.jsonl", poll_seconds=0.01)
            received: list[IncomingMessage] = []
            adapter.start(received.append)
            try:
                wait_until(lambda: len(received) == 2)
            finally:
                adapter.stop()

            self.assertEqual([message.text for message in received], ["完全相同的消息"] * 2)
            self.assertNotEqual(received[0].external_id, received[1].external_id)

    def test_partial_line_is_processed_after_newline_is_appended(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inbox = root / "inbox.jsonl"
            adapter = JsonlFileAdapter(inbox, root / "outbox.jsonl", poll_seconds=0.01)
            received: list[IncomingMessage] = []
            adapter.start(received.append)
            try:
                inbox.write_text(jsonl_record(), encoding="utf-8")
                time.sleep(0.08)
                self.assertEqual(received, [])

                with inbox.open("a", encoding="utf-8") as handle:
                    handle.write("\n")
                wait_until(lambda: len(received) == 1)
            finally:
                adapter.stop()

            self.assertEqual(received[0].text, "完全相同的消息")
            self.assertEqual(adapter.health()["malformed_lines"], 0)

    def test_callback_failure_retries_same_line_and_external_id(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inbox = root / "inbox.jsonl"
            inbox.write_text(jsonl_record() + "\n", encoding="utf-8")
            adapter = JsonlFileAdapter(inbox, root / "outbox.jsonl", poll_seconds=0.01)
            attempts: list[str] = []
            received: list[IncomingMessage] = []

            def flaky_callback(message: IncomingMessage) -> None:
                attempts.append(message.external_id)
                if len(attempts) == 1:
                    raise RuntimeError("transient callback failure")
                received.append(message)

            adapter.start(flaky_callback)
            try:
                wait_until(lambda: len(received) == 1 and len(attempts) >= 2)
            finally:
                adapter.stop()

            self.assertEqual(attempts[:2], [received[0].external_id] * 2)
            self.assertGreaterEqual(int(adapter.health()["callback_failures"]), 1)

    def test_poison_lines_are_consumed_without_blocking_later_valid_line(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inbox = root / "inbox.jsonl"
            bad_timestamp = json.dumps(
                {
                    "contact_key": "contact-1",
                    "contact_name": "测试联系人",
                    "text": "bad timestamp",
                    "timestamp": 123,
                },
                ensure_ascii=False,
            )
            inbox.write_text(
                f"[1,2,3]\n{bad_timestamp}\n{jsonl_record()}\n",
                encoding="utf-8",
            )
            adapter = JsonlFileAdapter(inbox, root / "outbox.jsonl", poll_seconds=0.01)
            received: list[IncomingMessage] = []
            adapter.start(received.append)
            try:
                wait_until(lambda: len(received) == 1)
            finally:
                adapter.stop()
            self.assertEqual(received[0].text, "完全相同的消息")
            self.assertEqual(adapter.health()["malformed_lines"], 2)

    def test_atomic_replacement_changes_fallback_event_identity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inbox = root / "inbox.jsonl"
            line = jsonl_record() + "\n"
            inbox.write_text(line, encoding="utf-8")
            adapter = JsonlFileAdapter(inbox, root / "outbox.jsonl", poll_seconds=0.01)
            received: list[IncomingMessage] = []
            adapter.start(received.append)
            try:
                wait_until(lambda: len(received) == 1)
                replacement = root / "replacement.jsonl"
                replacement.write_text(line, encoding="utf-8")
                deadline = time.monotonic() + 2
                while True:
                    try:
                        replacement.replace(inbox)
                        break
                    except PermissionError:
                        if time.monotonic() >= deadline:
                            raise
                        time.sleep(0.01)
                wait_until(lambda: len(received) == 2)
            finally:
                adapter.stop()
            self.assertNotEqual(received[0].external_id, received[1].external_id)
            self.assertGreaterEqual(int(adapter.health()["replacements"]), 1)


class AppServerBoundaryTests(unittest.TestCase):
    def test_approve_api_rejects_four_messages_and_non_strings_before_send(self) -> None:
        class ReadyService:
            def __init__(self, service: PersonaService) -> None:
                self.service = service

            def require_ready(self) -> None:
                return

            def approve(self, *args, **kwargs):
                return self.service.approve(*args, **kwargs)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = test_config(root)
            store = Store(config.db_path)
            adapter = MockAdapter()
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )
            invalid_cases = (
                ["第一条", "第二条", "第三条", "第四条"],
                ["有效字符串", 123],
            )

            with RunningServer(ReadyService(service)) as running:
                headers = {
                    "Content-Type": "application/json",
                    "X-Local-CSRF": running.server.csrf_token,
                    "Origin": f"http://127.0.0.1:{running.port}",
                }
                for index, messages in enumerate(invalid_cases):
                    with self.subTest(messages=messages):
                        draft_id = service.process(
                            IncomingMessage(
                                external_id=f"evt-api-invalid-segments-{index}",
                                contact_name=f"测试联系人{index}",
                                contact_key=f"contact-api-invalid-{index}",
                                text="普通低风险消息",
                                timestamp=datetime.now(),
                            )
                        )
                        status, _, body = running.request(
                            "POST",
                            f"/api/drafts/{draft_id}/approve",
                            body=json.dumps(
                                {"messages": messages}, ensure_ascii=False
                            ).encode("utf-8"),
                            headers=headers,
                        )

                        self.assertEqual(status, 400, body.decode("utf-8"))
                        self.assertFalse(json.loads(body)["ok"])
                        draft = store.get_draft(str(draft_id))
                        self.assertEqual(draft["status"], "pending")
                        self.assertEqual(draft["send_attempts"], [])
                        self.assertEqual(adapter.sent, [])

    def test_send_mode_api_toggles_without_secret_and_rejects_unsafe_inputs(self) -> None:
        class SendModeService:
            def __init__(self) -> None:
                self.enabled = False
                self.calls: list[bool] = []

            def require_ready(self) -> None:
                return

            def set_runtime_send_enabled(self, enabled: bool) -> None:
                self.calls.append(enabled)
                self.enabled = enabled

            def state(self) -> dict[str, bool]:
                return {
                    "send_capable": True,
                    "runtime_send_enabled": self.enabled,
                }

        service = SendModeService()
        with RunningServer(service) as running:
            headers = {
                "Content-Type": "application/json",
                "X-Local-CSRF": running.server.csrf_token,
                "Origin": f"http://127.0.0.1:{running.port}",
            }
            status, _, body = running.request(
                "POST",
                "/api/send-mode",
                body=json.dumps({"enabled": True}),
                headers=headers,
            )
            self.assertEqual(status, 200, body.decode("utf-8"))
            self.assertTrue(json.loads(body)["ok"])
            self.assertEqual(service.calls, [True])
            self.assertTrue(service.enabled)

            status, _, body = running.request(
                "POST",
                "/api/send-mode",
                body=json.dumps({"enabled": False}),
                headers=headers,
            )
            self.assertEqual(status, 200, body.decode("utf-8"))
            self.assertEqual(service.calls, [True, False])
            self.assertFalse(service.enabled)

            for invalid_payload in ({"enabled": "true"}, {"enabled": 1}, {}):
                with self.subTest(invalid_payload=invalid_payload):
                    status, _, _ = running.request(
                        "POST",
                        "/api/send-mode",
                        body=json.dumps(invalid_payload),
                        headers=headers,
                    )
                    self.assertEqual(status, 400)
                    self.assertEqual(service.calls, [True, False])

            status, _, _ = running.request(
                "POST",
                "/api/send-mode",
                body=json.dumps({"enabled": True}),
                headers={
                    "Content-Type": "application/json",
                    "Origin": f"http://127.0.0.1:{running.port}",
                },
            )
            self.assertEqual(status, 403)
            self.assertEqual(service.calls, [True, False])

    def test_model_switch_is_csrf_protected_and_allowlisted_by_service(self) -> None:
        class ModelService:
            def __init__(self) -> None:
                self.selected = "deepseek-v4-flash"

            def select_model(self, model_name: str) -> str:
                if model_name not in {"deepseek-v4-flash", "deepseek-v4-pro"}:
                    raise ValueError("模型不在允许列表")
                self.selected = model_name
                return model_name

        service = ModelService()
        with RunningServer(service) as running:
            headers = {
                "Content-Type": "application/json",
                "X-Local-CSRF": running.server.csrf_token,
                "Origin": f"http://127.0.0.1:{running.port}",
            }
            status, _, body = running.request(
                "POST",
                "/api/model",
                body=json.dumps({"model": "deepseek-v4-pro"}),
                headers=headers,
            )
            self.assertEqual(status, 200)
            self.assertEqual(json.loads(body)["model"], "deepseek-v4-pro")
            self.assertEqual(service.selected, "deepseek-v4-pro")

            status, _, _ = running.request(
                "POST",
                "/api/model",
                body=json.dumps({"model": "not-allowed"}),
                headers=headers,
            )
            self.assertEqual(status, 400)

    def test_api_rejects_missing_csrf_token(self) -> None:
        with RunningServer() as running:
            status, _, _ = running.request(
                "POST",
                "/api/incoming",
                body="{}",
                headers={"Content-Type": "application/json"},
            )
        self.assertEqual(status, 403)

    def test_api_rejects_wrong_host(self) -> None:
        with RunningServer() as running:
            status, _, _ = running.request(
                "GET",
                "/api/state",
                headers={
                    "Host": "attacker.invalid",
                    "X-Local-CSRF": running.server.csrf_token,
                },
            )
        self.assertEqual(status, 403)

    def test_api_rejects_wrong_origin(self) -> None:
        with RunningServer() as running:
            status, _, _ = running.request(
                "POST",
                "/api/incoming",
                body="{}",
                headers={
                    "Content-Type": "application/json",
                    "X-Local-CSRF": running.server.csrf_token,
                    "Origin": "https://attacker.invalid",
                },
            )
        self.assertEqual(status, 403)

    def test_page_denies_framing_and_has_content_security_policy(self) -> None:
        with RunningServer() as running:
            status, headers, body = running.request("GET", "/")

        self.assertEqual(status, 200)
        self.assertEqual(headers.get("X-Frame-Options"), "DENY")
        policy = headers.get("Content-Security-Policy", "")
        self.assertIn("frame-ancestors 'none'", policy)
        self.assertIn("default-src 'self'", policy)
        self.assertNotIn(b"__LOCAL_CSRF_TOKEN__", body)
        page = body.decode("utf-8")
        self.assertIn("手工模拟一条新消息（永不外发）", page)
        self.assertIn("最新消息在最上方", page)
        self.assertNotIn("const priority =", page)
        self.assertNotIn("priority[b.status]", page)
        self.assertIn("/api/send-mode", page)
        self.assertIn("允许真实发送：已关闭", page)
        self.assertNotIn("/api/arm", page)
        self.assertNotIn("解锁码", page)
        self.assertIn("destination_confirmation", page)
        self.assertIn("window.prompt", page)


if __name__ == "__main__":
    unittest.main()
