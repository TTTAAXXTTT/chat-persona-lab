from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import threading
import time
import unittest
from dataclasses import replace
from datetime import datetime
from pathlib import Path

from persona_agent.adapters import MockAdapter
from persona_agent.deepseek import FakeDraftModel
from persona_agent.models import AdapterEnvelope, IncomingMessage, wechat_account_scope
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.store import Store
from tests.test_service import test_config


ACCOUNT = "合成只读测试账号"
ACCOUNT_ID = "wxid-synthetic-readonly-account"
ADAPTER_KIND = "wxauto4_global_readonly"
RUN_GENERATION = "synthetic-adapter-run-generation"


def scoped_external_identity(
    session_identity: str, alias: str, run_generation: str = RUN_GENERATION
) -> str:
    account_scope = wechat_account_scope(ACCOUNT, ACCOUNT_ID)
    return "session-uia-sha256:" + hashlib.sha256(
        (
            f"{account_scope}\x1f{alias}\x1f{session_identity}\x1f"
            f"{run_generation}"
        ).encode("utf-8")
    ).hexdigest()


def envelope(
    event_id: str,
    *,
    external_identity: str = "session-runtime-1",
    alias: str = "合成唯一备注",
    chat_type: str = "friend",
    sender_role: str = "friend",
    message_type: str = "text",
    text: str = "合成测试消息",
    releasable: bool = True,
    run_generation: str = RUN_GENERATION,
    metadata_extra: dict[str, object] | None = None,
) -> AdapterEnvelope:
    metadata: dict[str, object] = {
        "account_nickname": ACCOUNT,
        "account_wechat_id": ACCOUNT_ID,
        "session_identity": external_identity,
        "adapter_run_generation": run_generation,
    }
    metadata.update(metadata_extra or {})
    return AdapterEnvelope(
        event_id=event_id,
        account_scope=wechat_account_scope(ACCOUNT, ACCOUNT_ID),
        adapter_kind=ADAPTER_KIND,
        external_identity=scoped_external_identity(
            external_identity, alias, run_generation
        ),
        identity_quality="uia_runtime",
        adapter_alias=alias,
        chat_type=chat_type,
        sender_role=sender_role,
        message_type=message_type,
        text=text,
        timestamp=datetime.now(),
        releasable=releasable,
        metadata=metadata,
    )


def service_for(root: Path) -> tuple[PersonaService, Store]:
    config = replace(
        test_config(root),
        adapter_mode=ADAPTER_KIND,
        wx_account_nickname=ACCOUNT,
        send_enabled=False,
    )
    store = Store(config.db_path)
    service = PersonaService(
        config=config,
        store=store,
        model=FakeDraftModel(),
        profile_retriever=ProfileRetriever([]),
        adapter=MockAdapter(),
    )
    return service, store


class IdentityQuarantineContractTests(unittest.TestCase):
    def test_new_scanner_generation_stales_old_uia_approval_before_rebind(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            first = envelope("evt-first-scanner-run")
            self.assertFalse(service.receive_adapter_event(first))
            first_identity = store.list_adapter_identities()[0]
            contact = service.bind_adapter_identity(
                identity_key=str(first_identity["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=None,
                display_name="合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )

            second = envelope(
                "evt-second-scanner-run",
                run_generation="different-synthetic-run-generation",
            )
            self.assertFalse(service.receive_adapter_event(second))
            identities = store.list_adapter_identities()
            by_key = {str(item["identity_key"]): item for item in identities}
            self.assertEqual(by_key[str(first_identity["identity_key"])]["status"], "stale")
            current = next(item for item in identities if item["status"] == "pending")
            self.assertIsNone(current["contact_key"])
            self.assertEqual(store.counts()["incoming"], 0)
            expired = next(
                item
                for item in store.list_quarantined_incoming()
                if item["external_event_id"] == first.event_id
            )
            self.assertEqual(expired["reason"], "identity_generation_expired")
            self.assertFalse(expired["releasable"])

            rebound = service.bind_adapter_identity(
                identity_key=str(current["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=str(contact["contact_key"]),
                display_name="",
                relationship="普通朋友",
                create_new=False,
                enable_live_read=True,
            )
            self.assertEqual(rebound["contact_key"], contact["contact_key"])

    def test_duplicate_claim_rehydrates_the_canonical_incoming_object(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / "canonical.sqlite3")
            canonical_time = datetime(2026, 1, 2, 3, 4, 5)
            first = IncomingMessage(
                external_id="synthetic-canonical-id",
                contact_key="canonical-contact",
                contact_name="首次显示名",
                text="相同正文",
                timestamp=canonical_time,
                metadata={"source": "direct-test", "canonical": True},
            )
            self.assertTrue(store.register_incoming(first))
            store.release_incoming(first.external_id)

            replay = IncomingMessage(
                external_id=first.external_id,
                contact_key=first.contact_key,
                contact_name="调用方临时显示名",
                text=first.text,
                timestamp=datetime(2030, 9, 8, 7, 6, 5),
                metadata={
                    "source": "direct-test",
                    "caller_only": "must disappear",
                    "_worker_retries": 1,
                },
            )
            self.assertTrue(store.register_incoming(replay))
            self.assertEqual(replay.contact_name, "首次显示名")
            self.assertEqual(replay.timestamp, canonical_time)
            self.assertEqual(replay.metadata["canonical"], True)
            self.assertNotIn("caller_only", replay.metadata)
            self.assertEqual(replay.metadata["_worker_retries"], 1)

    def test_missing_stable_login_account_id_is_never_bound_or_modelled(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            event = envelope("evt-missing-login-account-id")
            event.metadata.pop("account_wechat_id")
            event.account_scope = wechat_account_scope(ACCOUNT)

            self.assertFalse(service.receive_adapter_event(event))
            quarantined = store.list_quarantined_incoming()[0]
            self.assertEqual(quarantined["reason"], "account_mismatch")
            self.assertEqual(quarantined["text"], "")
            self.assertEqual(store.list_adapter_identities(), [])
            self.assertEqual(store.counts()["incoming"], 0)
            self.assertEqual(store.counts()["drafts"], 0)

    def test_incoming_id_collision_never_claims_different_contact_or_body(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory) / "collision.sqlite3")
            first = IncomingMessage(
                external_id="synthetic-collision-id",
                contact_key="contact-a",
                contact_name="合成甲",
                text="原始正文",
                timestamp=datetime.now(),
                metadata={"source": "direct-test"},
            )
            second = IncomingMessage(
                external_id=first.external_id,
                contact_key="contact-b",
                contact_name="合成乙",
                text="冲突正文",
                timestamp=datetime.now(),
                metadata={"source": "direct-test"},
            )

            self.assertTrue(store.register_incoming(first))
            store.release_incoming(first.external_id)
            with self.assertRaisesRegex(ValueError, "external_id|冲突"):
                store.register_incoming(second)

            with store.connection() as connection:
                canonical = connection.execute(
                    "SELECT contact_key, text, status FROM incoming WHERE external_id=?",
                    (first.external_id,),
                ).fetchone()
                unexpected_contact = connection.execute(
                    "SELECT 1 FROM contacts WHERE contact_key='contact-b'"
                ).fetchone()
            self.assertEqual(tuple(canonical), ("contact-a", "原始正文", "received"))
            self.assertIsNone(unexpected_contact)

    def test_unknown_identity_observation_and_quarantine_are_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            event = envelope("evt-observe-idempotent")

            self.assertFalse(service.receive_adapter_event(event))
            self.assertFalse(service.receive_adapter_event(event))

            identities = store.list_adapter_identities()
            quarantined = store.list_quarantined_incoming()
            self.assertEqual(len(identities), 1)
            self.assertEqual(identities[0]["status"], "pending")
            self.assertIsNone(identities[0]["contact_key"])
            self.assertEqual(identities[0]["pending_event_count"], 1)
            self.assertEqual(len(quarantined), 1)
            self.assertEqual(quarantined[0]["reason"], "unbound_identity")
            self.assertTrue(quarantined[0]["releasable"])
            self.assertEqual(store.counts()["contacts"], 0)
            self.assertEqual(store.counts()["incoming"], 0)

    def test_bind_then_concurrent_release_is_atomic_and_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            event = envelope("evt-atomic-release")
            self.assertFalse(service.receive_adapter_event(event))
            identity = store.list_adapter_identities()[0]
            quarantined = store.list_quarantined_incoming()[0]

            contact = service.bind_adapter_identity(
                identity_key=str(identity["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=None,
                display_name="合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )

            # Binding is one atomic identity/contact transaction, but it never
            # silently releases historical quarantined content.
            rebound = store.list_adapter_identities()[0]
            self.assertEqual(rebound["status"], "approved")
            self.assertEqual(rebound["contact_key"], contact["contact_key"])
            self.assertEqual(store.counts()["incoming"], 0)
            self.assertEqual(
                store.list_quarantined_incoming()[0]["status"], "pending"
            )
            # Replaying the same driver event after identity approval must not
            # bypass the explicit per-event release decision.
            self.assertFalse(service.receive_adapter_event(event))
            self.assertEqual(store.counts()["incoming"], 0)

            barrier = threading.Barrier(3)
            results: list[tuple[str, bool]] = []
            errors: list[Exception] = []

            def release_once() -> None:
                barrier.wait()
                try:
                    incoming, created = store.promote_quarantined_event(
                        str(quarantined["event_key"])
                    )
                    results.append((incoming.external_id, created))
                except Exception as error:  # pragma: no cover - asserted below
                    errors.append(error)

            threads = [threading.Thread(target=release_once) for _ in range(2)]
            for thread in threads:
                thread.start()
            barrier.wait()
            for thread in threads:
                thread.join(timeout=2)

            self.assertEqual(errors, [])
            self.assertEqual(len(results), 2)
            self.assertEqual(len({external_id for external_id, _ in results}), 1)
            self.assertEqual(
                results[0][0],
                store.global_incoming_id(str(quarantined["event_key"])),
            )
            self.assertEqual(sorted(created for _, created in results), [False, True])
            self.assertEqual(store.counts()["incoming"], 1)
            self.assertEqual(store.counts()["messages"], 1)
            released = store.list_quarantined_incoming(status="released")
            self.assertEqual(len(released), 1)
            self.assertEqual(released[0]["released_contact_key"], contact["contact_key"])

            again, created_again = store.promote_quarantined_event(
                str(quarantined["event_key"])
            )
            self.assertFalse(created_again)
            self.assertEqual(again.external_id, results[0][0])
            self.assertEqual(store.counts()["incoming"], 1)
            self.assertEqual(store.counts()["messages"], 1)

    def test_service_release_queues_and_generates_exactly_one_draft(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            event = envelope("evt-service-release-to-draft")
            self.assertFalse(service.receive_adapter_event(event))
            identity = store.list_adapter_identities()[0]
            quarantined = store.list_quarantined_incoming()[0]
            service.bind_adapter_identity(
                identity_key=str(identity["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=None,
                display_name="合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )

            service.start()
            try:
                result = service.release_quarantined_event(
                    str(quarantined["event_key"])
                )
                self.assertTrue(result["created"])
                self.assertTrue(result["queued"])
                deadline = time.monotonic() + 2
                drafts = store.list_drafts()
                while not drafts and time.monotonic() < deadline:
                    time.sleep(0.01)
                    drafts = store.list_drafts()
                self.assertEqual(len(drafts), 1)
                self.assertEqual(drafts[0]["status"], "pending")
                self.assertEqual(drafts[0]["incoming_text"], event.text)
                self.assertEqual(store.counts()["incoming"], 1)
                self.assertEqual(store.counts()["messages"], 1)
            finally:
                service.stop()

    def test_group_quarantine_never_retains_message_body(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            body_sentinel = "GROUP-BODY-MUST-NOT-BE-STORED-7f70"

            accepted = service.receive_adapter_event(
                envelope(
                    "evt-group-body",
                    external_identity="room-runtime-1",
                    alias="合成群聊",
                    chat_type="group",
                    text=body_sentinel,
                    metadata_extra={
                        "text": body_sentinel,
                        "content": body_sentinel,
                        "raw": {"content": body_sentinel},
                    },
                )
            )

            self.assertFalse(accepted)
            quarantined = store.list_quarantined_incoming()[0]
            self.assertEqual(quarantined["reason"], "excluded_chat_type")
            self.assertEqual(quarantined["text"], "")
            self.assertNotIn(body_sentinel, json.dumps(quarantined["metadata"]))
            self.assertEqual(store.list_adapter_identities(), [])
            self.assertEqual(store.counts()["messages"], 0)
            self.assertEqual(store.counts()["drafts"], 0)

    def test_nontext_quarantine_never_retains_body_in_text_or_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            body_sentinel = "NONTEXT-BODY-MUST-NOT-BE-STORED-a21c"

            accepted = service.receive_adapter_event(
                envelope(
                    "evt-nontext-body",
                    message_type="image",
                    text=body_sentinel,
                    metadata_extra={
                        "text": body_sentinel,
                        "content": body_sentinel,
                        "raw": {"message": body_sentinel},
                    },
                )
            )

            self.assertFalse(accepted)
            quarantined = store.list_quarantined_incoming()[0]
            self.assertEqual(quarantined["reason"], "excluded_message_kind")
            self.assertEqual(quarantined["text"], "")
            self.assertNotIn(body_sentinel, json.dumps(quarantined["metadata"]))
            self.assertEqual(store.list_adapter_identities(), [])
            self.assertEqual(store.counts()["messages"], 0)
            self.assertEqual(store.counts()["drafts"], 0)

    def test_same_alias_cannot_approve_two_external_identities_and_rolls_back(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            first = envelope(
                "evt-alias-first",
                external_identity="session-runtime-first",
                alias="完全相同备注",
            )
            second = envelope(
                "evt-alias-second",
                external_identity="session-runtime-second",
                alias="完全相同备注",
            )
            self.assertFalse(service.receive_adapter_event(first))
            self.assertFalse(service.receive_adapter_event(second))
            identities = {
                str(item["external_identity"]): item
                for item in store.list_adapter_identities()
            }
            first_identity = scoped_external_identity(
                "session-runtime-first", "完全相同备注"
            )
            second_identity = scoped_external_identity(
                "session-runtime-second", "完全相同备注"
            )

            self.assertEqual(identities[first_identity]["status"], "stale")
            self.assertEqual(identities[second_identity]["status"], "pending")
            service.bind_adapter_identity(
                identity_key=str(identities[second_identity]["identity_key"]),
                expected_alias="完全相同备注",
                contact_key=None,
                display_name="第二位合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )
            with self.assertRaises((ValueError, sqlite3.IntegrityError)):
                service.bind_adapter_identity(
                    identity_key=str(identities[first_identity]["identity_key"]),
                    expected_alias="完全相同备注",
                    contact_key=None,
                    display_name="第一位合成联系人",
                    relationship="普通朋友",
                    create_new=True,
                    enable_live_read=True,
                )

            after = {
                str(item["external_identity"]): item
                for item in store.list_adapter_identities()
            }
            self.assertEqual(after[first_identity]["status"], "stale")
            self.assertEqual(after[second_identity]["status"], "approved")
            self.assertIsNone(after[first_identity]["contact_key"])
            self.assertEqual(store.counts()["contacts"], 1)
            rolled_back_key = (
                "global:"
                + str(identities[first_identity]["identity_key"])[:32]
            )
            self.assertIsNone(store.contact_for_key(rolled_back_key))

    def test_disabled_contact_cannot_release_and_transaction_leaves_no_input(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            self.assertFalse(
                service.receive_adapter_event(envelope("evt-disabled-release"))
            )
            identity = store.list_adapter_identities()[0]
            quarantined = store.list_quarantined_incoming()[0]
            contact = service.bind_adapter_identity(
                identity_key=str(identity["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=None,
                display_name="稍后禁用的合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )
            with store.connection() as connection:
                connection.execute(
                    "UPDATE contacts SET enabled=0 WHERE contact_key=?",
                    (str(contact["contact_key"]),),
                )

            with self.assertRaises(PermissionError):
                store.promote_quarantined_event(str(quarantined["event_key"]))

            still_pending = store.list_quarantined_incoming()[0]
            self.assertEqual(still_pending["status"], "pending")
            self.assertIsNone(still_pending["released_incoming_id"])
            self.assertIsNone(still_pending["released_contact_key"])
            self.assertEqual(store.counts()["incoming"], 0)
            self.assertEqual(store.counts()["messages"], 0)
            self.assertEqual(store.counts()["drafts"], 0)

    def test_contact_alias_change_quarantines_future_event_instead_of_crossing(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store = service_for(Path(directory))
            first = envelope("evt-before-contact-alias-change")
            self.assertFalse(service.receive_adapter_event(first))
            identity = store.list_adapter_identities()[0]
            contact = service.bind_adapter_identity(
                identity_key=str(identity["identity_key"]),
                expected_alias="合成唯一备注",
                contact_key=None,
                display_name="合成联系人",
                relationship="普通朋友",
                create_new=True,
                enable_live_read=True,
            )
            store.update_contact(
                str(contact["contact_key"]),
                "普通朋友",
                True,
                adapter_alias="另一个备注",
            )

            self.assertFalse(
                service.receive_adapter_event(
                    envelope("evt-after-contact-alias-change")
                )
            )
            pending = store.list_quarantined_incoming()
            self.assertEqual(
                pending[0]["reason"], "identity_contact_alias_mismatch"
            )
            self.assertEqual(store.counts()["incoming"], 0)
            self.assertEqual(store.counts()["drafts"], 0)


if __name__ == "__main__":
    unittest.main()
