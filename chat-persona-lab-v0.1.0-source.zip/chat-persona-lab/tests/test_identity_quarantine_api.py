from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from typing import Any

from persona_agent.adapters import MockAdapter
from persona_agent.deepseek import FakeDraftModel
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.store import Store
from tests.test_adapter_server import RunningServer
from tests.test_service import test_config


IDENTITY_KEY = "a" * 64
EVENT_KEY = "b" * 64
UNKNOWN_KEY = "c" * 64


class IdentityStoreDouble:
    def __init__(self) -> None:
        self.identities = [
            {
                "identity_key": IDENTITY_KEY,
                "adapter_alias": "精确备注",
                "status": "pending",
                "pending_event_count": 1,
            }
        ]
        self.quarantined = [
            {
                "event_key": EVENT_KEY,
                "identity_key": IDENTITY_KEY,
                "status": "pending",
                "reason": "unknown_identity",
            }
        ]

    def list_adapter_identities(self) -> list[dict[str, Any]]:
        return self.identities

    def list_quarantined_incoming(self) -> list[dict[str, Any]]:
        return self.quarantined


class IdentityServiceDouble:
    def __init__(self) -> None:
        self.bind_calls: list[dict[str, Any]] = []
        self.release_calls: list[str] = []
        self.reject_calls: list[str] = []

    def bind_adapter_identity(self, **kwargs: Any) -> dict[str, Any]:
        self.bind_calls.append(kwargs)
        return {
            "contact_key": "global:approved",
            "display_name": kwargs["display_name"],
        }

    def release_quarantined_event(self, event_key: str) -> dict[str, Any]:
        self.release_calls.append(event_key)
        if event_key == UNKNOWN_KEY:
            raise KeyError(event_key)
        return {"event_key": event_key, "created": True, "queued": True}

    def reject_quarantined_event(self, event_key: str) -> bool:
        self.reject_calls.append(event_key)
        return event_key != UNKNOWN_KEY


def api_headers(running: RunningServer, *, csrf: bool = True) -> dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "Origin": f"http://127.0.0.1:{running.port}",
    }
    if csrf:
        headers["X-Local-CSRF"] = running.server.csrf_token
    return headers


class IdentityQuarantineApiTests(unittest.TestCase):
    def test_state_counts_and_list_apis_expose_identity_quarantine_state(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(test_config(root), send_enabled=False)
            store = Store(config.db_path)
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=MockAdapter(),
            )
            state = service.state()
            self.assertEqual(state["counts"]["adapter_identities"], 0)
            self.assertEqual(state["counts"]["quarantined_incoming"], 0)

        fake_store = IdentityStoreDouble()
        with RunningServer(IdentityServiceDouble()) as running:
            running.server.store = fake_store
            headers = {"X-Local-CSRF": running.server.csrf_token}

            identity_status, _, identity_body = running.request(
                "GET", "/api/adapter-identities", headers=headers
            )
            quarantine_status, _, quarantine_body = running.request(
                "GET", "/api/quarantine", headers=headers
            )

        self.assertEqual(identity_status, 200, identity_body.decode("utf-8"))
        self.assertEqual(
            json.loads(identity_body)["identities"], fake_store.identities
        )
        self.assertEqual(quarantine_status, 200, quarantine_body.decode("utf-8"))
        self.assertEqual(
            json.loads(quarantine_body)["quarantine"], fake_store.quarantined
        )

    def test_identity_and_quarantine_get_apis_require_csrf(self) -> None:
        with RunningServer(IdentityServiceDouble()) as running:
            running.server.store = IdentityStoreDouble()
            for path in ("/api/adapter-identities", "/api/quarantine"):
                with self.subTest(path=path):
                    status, _, _ = running.request("GET", path)
                    self.assertEqual(status, 403)

    def test_bind_accepts_only_typed_explicit_confirmation(self) -> None:
        service = IdentityServiceDouble()
        valid_payload = {
            "expected_alias": "精确备注",
            "contact_key": None,
            "display_name": "新联系人",
            "relationship": "待确认",
            "create_new": True,
            "enable_live_read": False,
        }
        with RunningServer(service) as running:
            headers = api_headers(running)
            status, _, body = running.request(
                "POST",
                f"/api/adapter-identities/{IDENTITY_KEY}/bind",
                body=json.dumps(valid_payload, ensure_ascii=False).encode("utf-8"),
                headers=headers,
            )
            self.assertEqual(status, 200, body.decode("utf-8"))
            self.assertEqual(
                service.bind_calls,
                [dict(valid_payload, identity_key=IDENTITY_KEY)],
            )

            invalid_payloads = (
                dict(valid_payload, expected_alias=123),
                dict(valid_payload, contact_key=123),
                dict(valid_payload, display_name=[]),
                dict(valid_payload, relationship={}),
                dict(valid_payload, create_new="true"),
                dict(valid_payload, create_new=1),
                {key: value for key, value in valid_payload.items() if key != "create_new"},
                dict(valid_payload, enable_live_read="false"),
                dict(valid_payload, enable_live_read=0),
                {
                    key: value
                    for key, value in valid_payload.items()
                    if key != "enable_live_read"
                },
            )
            for payload in invalid_payloads:
                with self.subTest(payload=payload):
                    invalid_status, _, _ = running.request(
                        "POST",
                        f"/api/adapter-identities/{IDENTITY_KEY}/bind",
                        body=json.dumps(payload).encode("utf-8"),
                        headers=headers,
                    )
                    self.assertEqual(invalid_status, 400)

            no_csrf_status, _, _ = running.request(
                "POST",
                f"/api/adapter-identities/{IDENTITY_KEY}/bind",
                body=json.dumps(valid_payload).encode("utf-8"),
                headers=api_headers(running, csrf=False),
            )
            self.assertEqual(no_csrf_status, 403)

        self.assertEqual(len(service.bind_calls), 1)

    def test_release_and_reject_are_explicit_strict_actions(self) -> None:
        service = IdentityServiceDouble()
        with RunningServer(service) as running:
            headers = api_headers(running)
            for action in ("release", "reject"):
                with self.subTest(action=action):
                    status, _, body = running.request(
                        "POST",
                        f"/api/quarantine/{EVENT_KEY}/{action}",
                        body=b"{}",
                        headers=headers,
                    )
                    self.assertEqual(status, 200, body.decode("utf-8"))

            for action in ("release", "reject"):
                with self.subTest(action=action, extra_payload=True):
                    status, _, _ = running.request(
                        "POST",
                        f"/api/quarantine/{EVENT_KEY}/{action}",
                        body=json.dumps({"force": True}).encode("utf-8"),
                        headers=headers,
                    )
                    self.assertEqual(status, 400)

            release_status, _, _ = running.request(
                "POST",
                f"/api/quarantine/{UNKNOWN_KEY}/release",
                body=b"{}",
                headers=headers,
            )
            reject_status, _, _ = running.request(
                "POST",
                f"/api/quarantine/{UNKNOWN_KEY}/reject",
                body=b"{}",
                headers=headers,
            )
            malformed_status, _, _ = running.request(
                "POST",
                "/api/quarantine/not-a-key/release",
                body=b"{}",
                headers=headers,
            )
            no_csrf_status, _, _ = running.request(
                "POST",
                f"/api/quarantine/{EVENT_KEY}/release",
                body=b"{}",
                headers=api_headers(running, csrf=False),
            )

        self.assertEqual(release_status, 404)
        self.assertIn(reject_status, {400, 404})
        self.assertEqual(malformed_status, 404)
        self.assertEqual(no_csrf_status, 403)
        self.assertEqual(service.release_calls, [EVENT_KEY, UNKNOWN_KEY])
        self.assertEqual(service.reject_calls, [EVENT_KEY, UNKNOWN_KEY])


if __name__ == "__main__":
    unittest.main()
