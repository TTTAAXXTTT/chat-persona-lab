from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from persona_agent.adapters import (
    SendBlockedError,
    SendUncertainError,
    WxAuto4PollingAdapter,
)


ACCOUNT = "虚构演示账号"
ALIAS = "demo_friend"


def message(
    identity: str,
    content: str,
    *,
    attr: str = "friend",
    msg_type: str = "text",
):
    return SimpleNamespace(
        id=identity,
        hash=f"hash-{identity}" if identity else "",
        attr=attr,
        type=msg_type,
        content=content,
        sender=ALIAS if attr == "friend" else ACCOUNT,
    )


class FakeWeChat:
    def __init__(self) -> None:
        self.messages = [message("old-1", "历史消息")]
        self.info = {"chat_name": ALIAS, "chat_type": "friend"}
        self.chat_calls: list[tuple[str, bool]] = []
        self.account_info = {"nickname": ACCOUNT, "wxid": "wxid_account"}
        self.get_all_calls = 0
        self.button_clicks = 0
        self.echo_on_click = True
        self.switch_delay_reads = 0
        self.pending_chat: str | None = None
        self.ChatBox = SimpleNamespace(
            msgbox=FakeMsgBox(self),
            editbox=FakeEditBox(),
        )
        self.ChatBox.sendbtn = FakeSendButton(self)

    def IsOnline(self) -> bool:
        return True

    def GetMyInfo(self) -> dict[str, str]:
        return dict(self.account_info)

    def ChatWith(self, who: str, exact: bool = True):
        self.chat_calls.append((who, exact))
        if self.switch_delay_reads:
            self.pending_chat = who
        else:
            self.info = {"chat_name": who, "chat_type": "friend"}

    def ChatInfo(self) -> dict[str, str]:
        if self.pending_chat is not None:
            if self.switch_delay_reads > 0:
                self.switch_delay_reads -= 1
            else:
                self.info = {"chat_name": self.pending_chat, "chat_type": "friend"}
                self.pending_chat = None
        return dict(self.info)

    def GetAllMessage(self):
        self.get_all_calls += 1
        return list(self.messages)

class FakeControl:
    ControlTypeName = "ListItemControl"

    def __init__(self, msg) -> None:
        self.message = msg
        self.runtimeid = (42, str(msg.id or msg.hash))


class FakeMsgBox:
    def __init__(self, wx: FakeWeChat) -> None:
        self.wx = wx

    def GetChildren(self):
        return [FakeControl(item) for item in self.wx.messages]


class FakeValuePattern:
    def __init__(self, value: str) -> None:
        self.Value = value


class FakeEditBox:
    def __init__(self) -> None:
        self.value = ""

    def ShortcutSelectAll(self) -> None:
        pass

    def Exists(self, timeout: float = 0) -> bool:
        return True

    def SendKeys(self, keys: str) -> None:
        if keys == "{DELETE}":
            self.value = ""

    def Paste(self, value: str) -> None:
        self.value = value

    def GetValuePattern(self) -> FakeValuePattern:
        return FakeValuePattern(self.value)


class FakeSendButton:
    def __init__(self, wx: FakeWeChat) -> None:
        self.wx = wx

    def Click(self) -> None:
        self.wx.button_clicks += 1
        text = self.wx.ChatBox.editbox.value
        if self.wx.echo_on_click:
            self.wx.messages.append(
                message(f"sent-{self.wx.button_clicks}", text, attr="self")
            )
            self.wx.ChatBox.editbox.value = ""

    def Exists(self, timeout: float = 0) -> bool:
        return True


class FakeModule:
    def __init__(self, wx: FakeWeChat) -> None:
        self.wx = wx
        self.kwargs = {}

    def WeChat(self, **kwargs):
        self.kwargs = dict(kwargs)
        return self.wx

    @staticmethod
    def parse_msg(control, parent):
        return control.message


def configured_adapter(*, allow_send: bool = False) -> WxAuto4PollingAdapter:
    adapter = WxAuto4PollingAdapter(
        (ALIAS,),
        "41.1.2",
        ACCOUNT,
        poll_seconds=60,
        allow_send=allow_send,
        allowed_send_contact_key="live:demo_friend" if allow_send else "",
        send_echo_timeout_seconds=0.03,
    )
    adapter.configure_bindings(
        {
            ALIAS: {
                "contact_key": "live:demo_friend",
                "display_name": ALIAS,
            }
        }
    )
    return adapter


class WxAuto4PollingAdapterTests(unittest.TestCase):
    def start_adapter(self, adapter, wx, callback):
        module = FakeModule(wx)
        version_patch = patch(
            "persona_agent.adapters.importlib.metadata.version",
            return_value="41.1.2",
        )
        import_patch = patch(
            "persona_agent.adapters.importlib.import_module",
            return_value=module,
        )
        version_patch.start()
        import_patch.start()
        self.addCleanup(version_patch.stop)
        self.addCleanup(import_patch.stop)
        adapter.start(callback)
        self.addCleanup(adapter.stop)
        return module

    def test_start_verifies_account_and_baselines_without_replay(self) -> None:
        wx = FakeWeChat()
        received = []
        adapter = configured_adapter()

        module = self.start_adapter(adapter, wx, received.append)

        self.assertEqual(received, [])
        self.assertEqual(wx.chat_calls, [])
        self.assertEqual(module.kwargs, {"ads": False, "resize": False})
        self.assertEqual(adapter.health()["baseline_count"], 1)
        self.assertEqual(wx.get_all_calls, 0)
        self.assertEqual(
            adapter.health()["poll_strategy"],
            "uia_runtime_ids_then_parse_new_only",
        )

    def test_start_switches_foreground_only_when_target_is_not_already_open(self) -> None:
        wx = FakeWeChat()
        wx.info = {"chat_name": "其他会话", "chat_type": "friend"}
        adapter = configured_adapter()

        self.start_adapter(adapter, wx, lambda incoming: None)

        self.assertEqual(wx.chat_calls, [(ALIAS, True)])
        self.assertEqual(adapter.health()["foreground_switches"], 1)

    def test_start_waits_for_delayed_chat_switch(self) -> None:
        wx = FakeWeChat()
        wx.info = {"chat_name": "其他会话", "chat_type": "friend"}
        wx.switch_delay_reads = 2
        adapter = configured_adapter()

        self.start_adapter(adapter, wx, lambda incoming: None)

        self.assertEqual(wx.chat_calls, [(ALIAS, True)])
        self.assertEqual(wx.info["chat_name"], ALIAS)
        self.assertEqual(adapter.health()["startup_stage"], "running")

    def test_new_friend_text_is_emitted_once(self) -> None:
        wx = FakeWeChat()
        received = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.messages.append(message("new-1", "新消息"))

        adapter._poll_once()
        adapter._poll_once()

        self.assertEqual([item.text for item in received], ["新消息"])
        self.assertEqual(received[0].contact_key, "live:demo_friend")
        self.assertEqual(
            received[0].metadata["source"],
            "wxauto4_polling",
        )

    def test_identical_text_with_distinct_ids_is_not_collapsed(self) -> None:
        wx = FakeWeChat()
        received = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.messages.extend(
            [message("new-1", "一样"), message("new-2", "一样")]
        )

        adapter._poll_once()

        self.assertEqual([item.text for item in received], ["一样", "一样"])

    def test_self_and_non_text_messages_are_ignored(self) -> None:
        wx = FakeWeChat()
        received = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.messages.extend(
            [
                message("self-1", "我发的", attr="self"),
                message("image-1", "[图片]", msg_type="image"),
            ]
        )

        adapter._poll_once()

        self.assertEqual(received, [])

    def test_visible_chat_drift_fails_closed(self) -> None:
        wx = FakeWeChat()
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, lambda incoming: None)
        wx.info = {"chat_name": "另一个会话", "chat_type": "friend"}

        with self.assertRaisesRegex(RuntimeError, "可见会话已变化"):
            adapter._poll_once()

    def test_message_window_rebuild_without_overlap_fails_closed(self) -> None:
        wx = FakeWeChat()
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, lambda incoming: None)
        wx.messages = [message("different-1", "旧页面")]

        with self.assertRaisesRegex(RuntimeError, "没有稳定重叠"):
            adapter._poll_once()

    def test_wrong_account_is_rejected(self) -> None:
        wx = FakeWeChat()
        wx.account_info = {"nickname": "另一个账号"}
        adapter = configured_adapter()
        module = FakeModule(wx)
        with patch(
            "persona_agent.adapters.importlib.metadata.version",
            return_value="41.1.2",
        ), patch(
            "persona_agent.adapters.importlib.import_module",
            return_value=module,
        ):
            with self.assertRaisesRegex(RuntimeError, "账号不匹配"):
                adapter.start(lambda incoming: None)

    def test_send_is_blocked_when_process_did_not_authorize_it(self) -> None:
        adapter = configured_adapter()
        with self.assertRaisesRegex(SendBlockedError, "未授权外发"):
            adapter.send_text(
                "live:demo_friend",
                ALIAS,
                "不会发送",
                "send-key",
            )

    def test_send_capable_start_requires_stable_login_account_id(self) -> None:
        wx = FakeWeChat()
        wx.account_info = {"nickname": ACCOUNT}
        adapter = configured_adapter(allow_send=True)
        module = FakeModule(wx)
        with patch(
            "persona_agent.adapters.importlib.metadata.version",
            return_value="41.1.2",
        ), patch(
            "persona_agent.adapters.importlib.import_module",
            return_value=module,
        ):
            with self.assertRaisesRegex(RuntimeError, "稳定微信号|禁止外发"):
                adapter.start(lambda incoming: None)

    def test_authorized_send_blocks_login_account_id_drift_before_click(self) -> None:
        wx = FakeWeChat()
        adapter = configured_adapter(allow_send=True)
        self.start_adapter(adapter, wx, lambda incoming: None)
        wx.account_info = {"nickname": ACCOUNT, "wxid": "different-account-id"}

        with self.assertRaisesRegex(SendBlockedError, "账号|ID"):
            adapter.send_text("live:demo_friend", ALIAS, "不能发送", "account-drift")
        self.assertEqual(wx.button_clicks, 0)

    def test_authorized_send_rechecks_target_and_records_success(self) -> None:
        wx = FakeWeChat()
        adapter = configured_adapter(allow_send=True)
        self.start_adapter(adapter, wx, lambda incoming: None)

        adapter.send_text("live:demo_friend", ALIAS, "真实测试", "send-key-1")

        self.assertEqual(wx.button_clicks, 1)
        self.assertEqual(wx.messages[-1].content, "真实测试")
        self.assertEqual(adapter.health()["sent_count"], 1)
        self.assertFalse(adapter.health()["read_only"])

    def test_authorized_send_blocks_wrong_target_or_chat_before_call(self) -> None:
        wx = FakeWeChat()
        adapter = configured_adapter(allow_send=True)
        self.start_adapter(adapter, wx, lambda incoming: None)

        with self.assertRaisesRegex(SendBlockedError, "contact_key"):
            adapter.send_text("live:other", ALIAS, "不能发送", "wrong-target")
        wx.info = {"chat_name": "其他会话", "chat_type": "friend"}
        with self.assertRaisesRegex(SendBlockedError, "会话复核失败"):
            adapter.send_text("live:demo_friend", ALIAS, "不能发送", "wrong-chat")
        self.assertEqual(wx.button_clicks, 0)

    def test_authorized_send_is_one_time_and_post_call_failure_is_uncertain(self) -> None:
        wx = FakeWeChat()
        wx.echo_on_click = False
        adapter = configured_adapter(allow_send=True)
        self.start_adapter(adapter, wx, lambda incoming: None)

        with self.assertRaisesRegex(SendUncertainError, "结果不确定"):
            adapter.send_text("live:demo_friend", ALIAS, "结果未知", "send-key-2")
        with self.assertRaisesRegex(SendBlockedError, "监听未运行"):
            adapter.send_text("live:demo_friend", ALIAS, "禁止重试", "send-key-2")
        self.assertEqual(wx.button_clicks, 1)
        self.assertFalse(adapter.health()["running"])


if __name__ == "__main__":
    unittest.main()
