from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path

from persona_agent.db_backup import backup_database


class DatabaseBackupTests(unittest.TestCase):
    def test_online_backup_includes_committed_wal_data_and_is_integral(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.sqlite3"
            backup_dir = root / "backups"
            connection = sqlite3.connect(source)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("CREATE TABLE sample(value TEXT NOT NULL)")
                connection.execute("INSERT INTO sample(value) VALUES ('合成数据')")
                connection.commit()
                destination = backup_database(source, backup_dir)
            finally:
                connection.close()

            self.assertIsNotNone(destination)
            assert destination is not None
            self.assertNotEqual(destination, source)
            copied = sqlite3.connect(destination)
            try:
                self.assertEqual(
                    copied.execute("SELECT value FROM sample").fetchone()[0],
                    "合成数据",
                )
                self.assertEqual(copied.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            finally:
                copied.close()

    def test_missing_database_is_a_safe_noop(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertIsNone(
                backup_database(root / "missing.sqlite3", root / "backups")
            )
            self.assertFalse((root / "backups").exists())


if __name__ == "__main__":
    unittest.main()
