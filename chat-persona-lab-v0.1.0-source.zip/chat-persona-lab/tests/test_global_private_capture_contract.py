from __future__ import annotations

import tempfile
import threading
import time
import unittest
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path

from persona_agent.models import IncomingMessage, ModelDraft
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.store import Store
from tests.test_service import test_config


GLOBAL_CAPTURE_SOURCE = "global_private_capture"


@dataclass(frozen=True, slots=True)
class CapturedEvent:
    """Synthetic event at the proposed global-capture adapter boundary.

    ``chat_type`` describes the conversation container, while ``peer_type``
    describes the remote identity.  A service account can therefore be a
    direct-looking conversation without being a one-to-one friend.
    """

    external_id: str
    peer_key: str
    peer_name: str
    text: str
    chat_type: str = "friend"
    peer_type: str = "friend"


class RecordingDraftModel:
    model_name = "contract-model"
    provider_name = "offline-contract"
    available_models = (model_name,)
    api_key_configured = False

    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []
        self.called = threading.Event()

    def generate(self, **kwargs) -> ModelDraft:
        self.calls.append(
            (str(kwargs["contact_name"]), str(kwargs["incoming_text"]))
        )
        self.called.set()
        return ModelDraft(
            messages=["仅生成草稿"],
            confidence=0.9,
            needs_user_input=False,
            uncertainties=[],
            used_model=self.model_name,
        )


class FakeGlobalCaptureAdapter:
    """Test double that emits classified events but never performs a send."""

    def __init__(self) -> None:
        self.callback = None
        self.sent: list[dict[str, str]] = []

    def start(self, callback) -> None:
        self.callback = callback

    def stop(self) -> None:
        self.callback = None

    def emit(self, event: CapturedEvent) -> None:
        if self.callback is None:
            raise RuntimeError("fake global adapter is not running")
        incoming = IncomingMessage(
            external_id=event.external_id,
            contact_name=event.peer_name,
            contact_key=event.peer_key,
            text=event.text,
            timestamp=datetime.now(),
            metadata={
                "source": GLOBAL_CAPTURE_SOURCE,
                "chat_type": event.chat_type,
                "peer_type": event.peer_type,
            },
        )
        try:
            self.callback(incoming)
        except ValueError:
            # A fail-closed admission boundary may reject an event explicitly.
            # The adapter must consume that classification result, not retry the
            # same unsafe event forever as a transport failure.
            return

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        self.sent.append(
            {
                "contact_key": contact_key,
                "contact_name": contact_name,
                "text": text,
                "send_key": send_key,
            }
        )

    def health(self) -> dict[str, object]:
        return {
            "mode": GLOBAL_CAPTURE_SOURCE,
            "running": self.callback is not None,
            "send_capable": False,
        }


class FlakyStartGlobalCaptureAdapter(FakeGlobalCaptureAdapter):
    """Fails two connection attempts so the service retry policy is observable."""

    def __init__(self) -> None:
        super().__init__()
        self.start_attempts: list[float] = []

    def start(self, callback) -> None:
        self.start_attempts.append(time.monotonic())
        if len(self.start_attempts) < 3:
            raise RuntimeError("synthetic transient capture failure")
        super().start(callback)


def wait_until(predicate, *, timeout: float = 1.5) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    raise AssertionError("condition was not reached before timeout")


class GlobalPrivateCaptureContractTests(unittest.TestCase):
    def make_service(
        self,
        root: Path,
        *,
        adapter: FakeGlobalCaptureAdapter | None = None,
    ) -> tuple[PersonaService, Store, RecordingDraftModel, FakeGlobalCaptureAdapter]:
        config = replace(
            test_config(root),
            adapter_mode=GLOBAL_CAPTURE_SOURCE,
            send_enabled=False,
        )
        store = Store(config.db_path)
        model = RecordingDraftModel()
        selected_adapter = adapter or FakeGlobalCaptureAdapter()
        service = PersonaService(
            config=config,
            store=store,
            model=model,
            profile_retriever=ProfileRetriever([]),
            adapter=selected_adapter,
        )
        return service, store, model, selected_adapter

    @staticmethod
    def bind_peer(store: Store, key: str, name: str, alias: str) -> None:
        store.ensure_contact(key, name)
        store.update_contact(
            key,
            relationship="普通朋友",
            live_read_enabled=True,
            adapter_alias=alias,
        )

    def assert_no_generation_or_send(
        self,
        *,
        store: Store,
        model: RecordingDraftModel,
        adapter: FakeGlobalCaptureAdapter,
    ) -> None:
        # Give an incorrectly admitted asynchronous event enough time to expose
        # itself.  A correctly rejected event never reaches the worker/model.
        model.called.wait(timeout=0.25)
        self.assertEqual(model.calls, [])
        self.assertEqual(store.list_drafts(), [])
        self.assertEqual(adapter.sent, [])

    def test_bound_group_never_reaches_model_or_draft(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, model, adapter = self.make_service(Path(directory))
            self.bind_peer(store, "room:bound-group", "合成群聊", "group-alias")
            service.start()
            try:
                adapter.emit(
                    CapturedEvent(
                        external_id="evt-group-1",
                        peer_key="room:bound-group",
                        peer_name="合成群聊",
                        text="群聊测试事件",
                        chat_type="group",
                        peer_type="group",
                    )
                )
                self.assert_no_generation_or_send(
                    store=store, model=model, adapter=adapter
                )
            finally:
                service.stop()

    def test_bound_service_account_never_reaches_model_or_draft(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, model, adapter = self.make_service(Path(directory))
            self.bind_peer(store, "official:bound", "合成服务号", "official-alias")
            service.start()
            try:
                adapter.emit(
                    CapturedEvent(
                        external_id="evt-official-1",
                        peer_key="official:bound",
                        peer_name="合成服务号",
                        text="服务号测试事件",
                        chat_type="friend",
                        peer_type="official_account",
                    )
                )
                self.assert_no_generation_or_send(
                    store=store, model=model, adapter=adapter
                )
            finally:
                service.stop()

    def test_unknown_friend_identity_never_reaches_model_or_draft_or_auto_binds(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, model, adapter = self.make_service(Path(directory))
            service.start()
            try:
                adapter.emit(
                    CapturedEvent(
                        external_id="evt-unknown-1",
                        peer_key="wxid:unbound-synthetic",
                        peer_name="未绑定合成好友",
                        text="未知身份测试事件",
                    )
                )
                self.assert_no_generation_or_send(
                    store=store, model=model, adapter=adapter
                )
                self.assertIsNone(store.contact_for_key("wxid:unbound-synthetic"))
            finally:
                service.stop()

    def test_bound_friends_create_independent_fifo_drafts_without_send(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, model, adapter = self.make_service(Path(directory))
            self.bind_peer(store, "wxid:friend-a", "合成好友甲", "friend-a")
            self.bind_peer(store, "wxid:friend-b", "合成好友乙", "friend-b")
            service.start()
            try:
                events = [
                    CapturedEvent(
                        "evt-fifo-1", "wxid:friend-a", "合成好友甲", "消息一"
                    ),
                    CapturedEvent(
                        "evt-fifo-2", "wxid:friend-b", "合成好友乙", "消息二"
                    ),
                    CapturedEvent(
                        "evt-fifo-3", "wxid:friend-a", "合成好友甲", "消息三"
                    ),
                ]
                for event in events:
                    adapter.emit(event)

                wait_until(lambda: len(store.list_drafts()) == 3)
                self.assertEqual(
                    model.calls,
                    [
                        ("合成好友甲", "消息一"),
                        ("合成好友乙", "消息二"),
                        ("合成好友甲", "消息三"),
                    ],
                )
                drafts = store.list_drafts()
                self.assertEqual(len({draft["id"] for draft in drafts}), 3)
                self.assertEqual(
                    [draft["status"] for draft in drafts], ["pending"] * 3
                )
                self.assertEqual(adapter.sent, [])
            finally:
                service.stop()

    def test_duplicate_global_event_is_idempotent_and_never_sends(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, model, adapter = self.make_service(Path(directory))
            self.bind_peer(store, "wxid:friend-a", "合成好友甲", "friend-a")
            service.start()
            try:
                repeated = CapturedEvent(
                    "evt-idempotent-1",
                    "wxid:friend-a",
                    "合成好友甲",
                    "重复事件",
                )

                adapter.emit(repeated)
                wait_until(lambda: len(store.list_drafts()) == 1)
                adapter.emit(repeated)
                time.sleep(0.05)

                self.assertEqual(model.calls, [("合成好友甲", "重复事件")])
                self.assertEqual(len(store.list_drafts()), 1)
                self.assertEqual(adapter.sent, [])
            finally:
                service.stop()

    def test_transient_adapter_start_failures_retry_with_backoff_without_send(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            flaky = FlakyStartGlobalCaptureAdapter()
            service, _, _, adapter = self.make_service(
                Path(directory), adapter=flaky
            )
            service.start_background()
            try:
                wait_until(
                    lambda: len(flaky.start_attempts) >= 3
                    or service.state()["service"]["status"] == "failed"
                )
                self.assertEqual(len(flaky.start_attempts), 3)
                gaps = [
                    later - earlier
                    for earlier, later in zip(
                        flaky.start_attempts, flaky.start_attempts[1:]
                    )
                ]
                self.assertTrue(all(gap >= 0.02 for gap in gaps), gaps)
                wait_until(
                    lambda: service.state()["service"]["status"] == "running"
                )
                self.assertEqual(adapter.sent, [])
            finally:
                service.stop()


if __name__ == "__main__":
    unittest.main()
