from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from persona_agent.chat_parser import build_example_pairs, group_turns, parse_export


class ChatParserTests(unittest.TestCase):
    def test_parses_multiline_and_preserves_short_message_split(self) -> None:
        content = """会话: 测试联系人 (wxid_test)
账号: self_account
时间范围: 2026-07-01 00:00:00 ~ 2026-07-02 00:00:00

[2026-07-01 10:00:00] 测试联系人(wxid_test): 第一行
第二行
[2026-07-01 10:00:20] self_account(self_account): 好
[2026-07-01 10:00:35] self_account(self_account): 我看一下
"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "messages.txt"
            path.write_text(content, encoding="utf-8")
            export = parse_export(path)
        self.assertEqual(export.conversation_id, "wxid_test")
        self.assertEqual(len(export.messages), 3)
        self.assertEqual(export.messages[0].content, "第一行\n第二行")
        self.assertFalse(export.messages[0].is_self)
        self.assertTrue(export.messages[1].is_self)
        turns = group_turns(export.messages)
        self.assertEqual(len(turns), 2)
        examples = build_example_pairs(export)
        self.assertEqual(len(examples), 1)
        self.assertEqual(examples[0].reply_messages, ["好", "我看一下"])

    def test_rejects_export_without_stable_conversation_id(self) -> None:
        content = """会话: 同名联系人
账号: self_account

[2026-07-01 10:00:00] 同名联系人(): 你好
"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "messages.txt"
            path.write_text(content, encoding="utf-8")
            with self.assertRaises(ValueError):
                parse_export(path)

    def test_sensitive_examples_are_not_built(self) -> None:
        content = """会话: 测试联系人 (wxid_test)
账号: self_account

[2026-07-01 10:00:00] 测试联系人(wxid_test): 我的账号是demo_user_123456
[2026-07-01 10:00:20] self_account(self_account): 好
"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "messages.txt"
            path.write_text(content, encoding="utf-8")
            export = parse_export(path)
        self.assertEqual(build_example_pairs(export), [])


if __name__ == "__main__":
    unittest.main()
