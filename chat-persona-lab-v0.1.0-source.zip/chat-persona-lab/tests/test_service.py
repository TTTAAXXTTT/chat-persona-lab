from __future__ import annotations

import tempfile
import threading
import time
import unittest
from dataclasses import replace
from datetime import datetime
from pathlib import Path

from persona_agent.adapters import JsonlFileAdapter, MockAdapter
from persona_agent.config import AppConfig
from persona_agent.deepseek import FakeDraftModel
from persona_agent.models import IncomingMessage, ModelDraft, ProfileItem
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.style_memory import build_style_fingerprint
from persona_agent.store import Store


class MustNotRunModel:
    model_name = "must-not-run"

    def generate(self, **kwargs):
        raise AssertionError("high-risk messages must never call the model")


class BlockingFailAdapter:
    def __init__(self) -> None:
        self.entered = threading.Event()
        self.release = threading.Event()

    def start(self, callback) -> None:
        self.entered.set()
        self.release.wait(timeout=2)
        raise RuntimeError("simulated adapter startup failure")

    def stop(self) -> None:
        self.release.set()

    def health(self) -> dict[str, object]:
        return {"mode": "blocking-test", "running": False}


class BindingMockAdapter(MockAdapter):
    """A non-WeChat test double that accepts the live contact binding contract."""

    def __init__(self) -> None:
        super().__init__()
        self.bindings: dict[str, dict[str, str]] = {}

    def configure_bindings(self, bindings: dict[str, dict[str, str]]) -> None:
        self.bindings = bindings


class CapturingStyleModel:
    model_name = "deepseek-v4-flash"
    provider_name = "opencode_go"
    available_models = ("deepseek-v4-flash", "deepseek-v4-pro")
    api_key_configured = True

    def __init__(self) -> None:
        self.style_payload = None

    def select_model(self, model_name: str) -> str:
        if model_name not in self.available_models:
            raise ValueError("模型不在允许列表")
        self.model_name = model_name
        return model_name

    def generate(self, **kwargs):
        self.style_payload = kwargs.get("style_fingerprint")
        return ModelDraft(
            messages=["在"],
            confidence=0.9,
            needs_user_input=False,
            uncertainties=[],
            used_model=self.model_name,
        )


def test_config(root: Path) -> AppConfig:
    return AppConfig(
        project_root=root,
        data_dir=root / "data",
        db_path=root / "data" / "test.sqlite3",
        profile_xlsx_path=root / "profile.xlsx",
        chat_export_files=(),
        profile_sheet_prefixes=(),
        deepseek_api_key="",
        deepseek_base_url="https://api.deepseek.com",
        deepseek_model="deepseek-v4-flash",
        deepseek_json_mode=True,
        temperature=0.5,
        max_tokens=512,
        host="127.0.0.1",
        port=8765,
        adapter_mode="mock",
        contact_whitelist=(),
        private_terms=(),
        send_enabled=True,
        allow_cloud_processing=False,
        api_context_char_budget=18000,
        debounce_seconds=0,
        draft_ttl_seconds=1800,
        wx_account_nickname="",
        wx_live_validated=False,
        wx_test_account_mode=False,
        wx_live_unlock="",
        wxauto4_expected_version="41.1.2",
        wxautox4_expected_version="41.1.1.post1",
        allow_custom_model_endpoint=False,
        inbox_path=root / "data" / "inbox.jsonl",
        outbox_path=root / "data" / "outbox.jsonl",
    )


class ServiceTests(unittest.TestCase):
    def test_restart_is_blocked_while_previous_worker_is_still_alive(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(test_config(root), send_enabled=False)
            service = PersonaService(
                config=config,
                store=Store(config.db_path),
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=MockAdapter(),
            )
            release = threading.Event()
            stale_worker = threading.Thread(
                target=lambda: release.wait(timeout=2), daemon=True
            )
            stale_worker.start()
            service._worker = stale_worker
            try:
                with self.assertRaisesRegex(RuntimeError, "worker|并发生成"):
                    service.start()
            finally:
                release.set()
                stale_worker.join(timeout=1)

    def test_style_fingerprint_and_runtime_model_selection_reach_next_draft(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(test_config(root), send_enabled=False)
            store = Store(config.db_path)
            model = CapturingStyleModel()
            fingerprint = build_style_fingerprint(
                [
                    {"contact_key": "a", "content": "哈哈哈"},
                    {"contact_key": "b", "content": "哈哈哈"},
                ]
            )
            service = PersonaService(
                config=config,
                store=store,
                model=model,
                profile_retriever=ProfileRetriever([]),
                adapter=MockAdapter(),
                style_fingerprint=fingerprint,
            )

            self.assertEqual(service.select_model("deepseek-v4-pro"), "deepseek-v4-pro")
            draft_id = service.process(
                IncomingMessage(
                    external_id="evt-style",
                    contact_name="demo_friend",
                    contact_key="live:demo_friend",
                    text="哈喽",
                    timestamp=datetime.now(),
                )
            )
            draft = store.get_draft(str(draft_id))
            self.assertEqual(draft["model"], "deepseek-v4-pro")
            self.assertEqual(model.style_payload["self_message_count"], 2)
            self.assertEqual(model.style_payload["source_contact_count"], 2)
            state = service.state()
            self.assertEqual(state["provider"], "opencode_go")
            self.assertEqual(state["available_models"], list(model.available_models))

    def test_background_start_returns_immediately_and_exposes_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = test_config(root)
            adapter = BlockingFailAdapter()
            service = PersonaService(
                config=config,
                store=Store(config.db_path),
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )

            started_at = time.monotonic()
            service.start_background()
            self.assertLess(time.monotonic() - started_at, 0.25)
            self.assertTrue(adapter.entered.wait(timeout=1))
            self.assertEqual(service.state()["service"]["status"], "starting")
            with self.assertRaises(RuntimeError):
                service.require_ready()

            adapter.release.set()
            deadline = time.monotonic() + 2
            while service.state()["service"]["status"] != "failed":
                if time.monotonic() >= deadline:
                    self.fail("background startup failure was not published")
                time.sleep(0.01)
            lifecycle = service.state()["service"]
            self.assertIn("simulated adapter startup failure", lifecycle["startup_error"])
            with self.assertRaisesRegex(RuntimeError, "simulated adapter startup failure"):
                service.require_ready()
            service.stop()

    def test_draft_approval_is_single_use(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = test_config(root)
            store = Store(config.db_path)
            adapter = MockAdapter()
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever(
                    [ProfileItem("04 语言与沟通指纹", 12, ["长度", "短消息"])]
                ),
                adapter=adapter,
            )
            incoming = IncomingMessage(
                external_id="evt-1",
                contact_name="测试联系人",
                contact_key="contact-1",
                text="到家没",
                timestamp=datetime.now(),
            )
            draft_id = service.process(incoming)
            self.assertIsNotNone(draft_id)
            draft = service.approve(str(draft_id), ["刚到"])
            self.assertEqual(draft["status"], "sent")
            self.assertEqual(len(adapter.sent), 1)
            self.assertEqual(draft["send_attempts"][0]["status"], "confirmed")
            context = store.recent_context("contact-1", limit=5)
            self.assertEqual([item["sender_role"] for item in context], ["other", "self"])
            self.assertEqual(context[-1]["content"], "刚到")
            with self.assertRaises(RuntimeError):
                service.approve(str(draft_id), ["重复发送"])
            self.assertEqual(len(adapter.sent), 1)

    def test_approval_rejects_four_messages_and_non_strings_before_send(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = test_config(root)
            store = Store(config.db_path)
            adapter = MockAdapter()
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )
            invalid_cases = (
                ["第一条", "第二条", "第三条", "第四条"],
                ["有效字符串", 123],
            )

            for index, messages in enumerate(invalid_cases):
                with self.subTest(messages=messages):
                    draft_id = service.process(
                        IncomingMessage(
                            external_id=f"evt-invalid-segments-{index}",
                            contact_name=f"测试联系人{index}",
                            contact_key=f"contact-invalid-{index}",
                            text="普通低风险消息",
                            timestamp=datetime.now(),
                        )
                    )
                    with self.assertRaises(ValueError):
                        service.approve(
                            str(draft_id),
                            messages,  # type: ignore[arg-type]
                        )

                    draft = store.get_draft(str(draft_id))
                    self.assertEqual(draft["status"], "pending")
                    self.assertEqual(draft["send_attempts"], [])
                    self.assertEqual(adapter.sent, [])

    def test_high_risk_never_calls_model_or_sends(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = test_config(root)
            store = Store(config.db_path)
            adapter = MockAdapter()
            service = PersonaService(
                config=config,
                store=store,
                model=MustNotRunModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )
            draft_id = service.process(
                IncomingMessage(
                    external_id="evt-money",
                    contact_name="测试联系人",
                    contact_key="contact-1",
                    text="把验证码和银行卡号发我",
                    timestamp=datetime.now(),
                )
            )
            draft = store.get_draft(str(draft_id))
            self.assertEqual(draft["status"], "blocked")
            self.assertEqual(adapter.sent, [])

    def test_jsonl_confirmation_reports_outbox_not_wechat_sent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(test_config(root), adapter_mode="jsonl")
            store = Store(config.db_path)
            adapter = JsonlFileAdapter(config.inbox_path, config.outbox_path)
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )
            draft_id = service.process(
                IncomingMessage(
                    external_id="evt-outbox",
                    contact_name="测试联系人",
                    contact_key="contact-1",
                    text="到家没",
                    timestamp=datetime.now(),
                )
            )
            draft = service.approve(str(draft_id), ["刚到"])
            self.assertEqual(draft["status"], "outbox_written")
            self.assertTrue(config.outbox_path.exists())

    def test_live_send_mode_defaults_off_and_each_draft_requires_confirmation(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(
                test_config(root),
                adapter_mode="wxauto4_polling",
                contact_whitelist=("demo_friend",),
                wx_account_nickname="虚构演示账号",
                wx_live_validated=True,
                wx_test_account_mode=True,
                wx_live_unlock="ENABLE_REAL_WECHAT_SEND",
                wx_send_contact_key="live:demo_friend",
                wx_polling_send_unlock="ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT",
            )
            store = Store(config.db_path)
            store.ensure_contact("live:demo_friend", "demo_friend")
            store.update_contact("live:demo_friend", "普通朋友", True, "demo_friend")
            adapter = BindingMockAdapter()
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=adapter,
            )
            service.start()
            self.addCleanup(service.stop)
            state = service.state()
            self.assertEqual(state["service"]["status"], "running")
            self.assertTrue(state["send_capable"])
            self.assertFalse(state["runtime_send_enabled"])

            first_live_id = service.process(
                IncomingMessage(
                    external_id="evt-live-off",
                    contact_name="demo_friend",
                    contact_key="live:demo_friend",
                    text="真实来信一",
                    timestamp=datetime.now(),
                    metadata={"source": "wxauto4_polling"},
                )
            )
            with self.assertRaises(PermissionError):
                service.approve(
                    str(first_live_id),
                    ["真实回复一"],
                    destination_confirmation="demo_friend",
                )
            first_pending = store.get_draft(str(first_live_id))
            self.assertEqual(first_pending["status"], "pending")
            self.assertEqual(first_pending["send_attempts"], [])
            self.assertEqual(adapter.sent, [])

            service.set_runtime_send_enabled(True)
            self.assertTrue(service.state()["runtime_send_enabled"])
            first_result = service.approve(
                str(first_live_id),
                ["真实回复一"],
                destination_confirmation="demo_friend",
            )
            self.assertEqual(first_result["status"], "sent")
            self.assertTrue(service.state()["runtime_send_enabled"])

            second_live_id = service.process(
                IncomingMessage(
                    external_id="evt-live-second",
                    contact_name="demo_friend",
                    contact_key="live:demo_friend",
                    text="真实来信二",
                    timestamp=datetime.now(),
                    metadata={"source": "wxauto4_polling"},
                )
            )
            with self.assertRaisesRegex(PermissionError, "准确输入收件人"):
                service.approve(
                    str(second_live_id),
                    ["真实回复二"],
                    destination_confirmation="其他人",
                )
            second_pending = store.get_draft(str(second_live_id))
            self.assertEqual(second_pending["status"], "pending")
            self.assertEqual(second_pending["send_attempts"], [])
            second_result = service.approve(
                str(second_live_id),
                ["真实回复二"],
                destination_confirmation="demo_friend",
            )
            self.assertEqual(second_result["status"], "sent")
            self.assertTrue(service.state()["runtime_send_enabled"])
            self.assertEqual(
                [item["contact_key"] for item in adapter.sent],
                ["live:demo_friend", "live:demo_friend"],
            )

            manual_id = service.process(
                IncomingMessage(
                    external_id="evt-manual",
                    contact_name="demo_friend",
                    contact_key="live:demo_friend",
                    text="手工模拟",
                    timestamp=datetime.now(),
                    metadata={"source": "manual-test"},
                )
            )
            with self.assertRaisesRegex(PermissionError, "手工模拟草稿永不外发"):
                service.approve(
                    str(manual_id),
                    ["不能外发"],
                    destination_confirmation="demo_friend",
                )
            self.assertEqual(len(adapter.sent), 2)

            service.stop()
            restarted = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=BindingMockAdapter(),
            )
            restarted.start()
            try:
                restarted_state = restarted.state()
                self.assertTrue(restarted_state["send_capable"])
                self.assertFalse(restarted_state["runtime_send_enabled"])
            finally:
                restarted.stop()

    def test_runtime_send_cannot_be_enabled_without_static_capability(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(test_config(root), send_enabled=False)
            service = PersonaService(
                config=config,
                store=Store(config.db_path),
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=MockAdapter(),
            )

            state = service.state()
            self.assertFalse(state["send_capable"])
            self.assertFalse(state["runtime_send_enabled"])
            with self.assertRaises(PermissionError):
                service.set_runtime_send_enabled(True)
            self.assertFalse(service.state()["runtime_send_enabled"])


if __name__ == "__main__":
    unittest.main()
