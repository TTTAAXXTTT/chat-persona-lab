from dataclasses import replace
from pathlib import Path
import tempfile
import unittest

from tests.test_service import test_config


class PublicRecipientBindingTests(unittest.TestCase):
    def test_explicit_non_demo_recipient_can_pass_config_but_requires_unlock(self):
        with tempfile.TemporaryDirectory() as directory:
            config = replace(test_config(Path(directory)),
                adapter_mode='wxauto4_polling',
                contact_whitelist=('fictional_unique_alias',),
                wx_account_nickname='fictional_new_account',
                wx_send_contact_key='fictional_bound_contact',
                send_enabled=True,
                wx_live_validated=True,
                wx_test_account_mode=True,
                wx_live_unlock='ENABLE_REAL_WECHAT_SEND',
                wx_polling_send_unlock='ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT')
            config.validate()
            with self.assertRaises(ValueError):
                replace(config, wx_polling_send_unlock='').validate()
            with self.assertRaises(ValueError):
                replace(config, wx_send_contact_key='').validate()
            with self.assertRaises(ValueError):
                replace(config, contact_whitelist=('first', 'second')).validate()


if __name__ == '__main__':
    unittest.main()
