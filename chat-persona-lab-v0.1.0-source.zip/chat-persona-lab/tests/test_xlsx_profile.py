from __future__ import annotations

import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from persona_agent.xlsx_profile import SECTION_CONTEXT_PREFIX, load_profile_items


def _cell(reference: str, value: str) -> str:
    return (
        f'<c r="{reference}" t="inlineStr"><is><t>{escape(value)}</t></is></c>'
    )


def _sheet_xml(rows: list[list[tuple[str, str]]]) -> str:
    body = []
    for index, row in enumerate(rows, start=1):
        body.append(
            f'<row r="{index}">' + "".join(_cell(ref, value) for ref, value in row) + "</row>"
        )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData>' + "".join(body) + "</sheetData></worksheet>"
    )


def _write_workbook(path: Path) -> None:
    sheets = [
        (
            "01 身份与事实基线",
            [
                [("A1", "身份事实")],
                [("A2", "持续兴趣"), ("B2", "旅行"), ("C2", "可")],
            ],
        ),
        (
            "06 情绪与状态模型",
            [
                [("A1", "状态调整")],
                [("A2", "低精力"), ("B2", "减少消息数量")],
            ],
        ),
        (
            "15 待确认问题",
            [
                [("A1", "语言习惯")],
                [("A2", "口头禅"), ("B2", "哈哈哈"), ("C2", "已确认")],
                [("A3", "隐私边界"), ("B3", "等待回答"), ("C3", "待确认")],
            ],
        ),
    ]
    workbook_sheets = []
    relationships = []
    with zipfile.ZipFile(path, "w") as archive:
        for index, (name, rows) in enumerate(sheets, start=1):
            workbook_sheets.append(
                f'<sheet name="{name}" sheetId="{index}" r:id="rId{index}"/>'
            )
            relationships.append(
                '<Relationship '
                f'Id="rId{index}" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                f'Target="worksheets/sheet{index}.xml"/>'
            )
            archive.writestr(f"xl/worksheets/sheet{index}.xml", _sheet_xml(rows))
        archive.writestr(
            "xl/workbook.xml",
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets>' + "".join(workbook_sheets) + "</sheets></workbook>",
        )
        archive.writestr(
            "xl/_rels/workbook.xml.rels",
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + "".join(relationships)
            + "</Relationships>",
        )


class XlsxProfileTests(unittest.TestCase):
    def test_loads_all_sheets_and_preserves_single_rows_and_section_context(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "profile.xlsx"
            _write_workbook(path)

            # Prefixes are now a compatibility argument; local loading is complete.
            items = load_profile_items(path, ("02",))

        self.assertEqual(
            {item.sheet for item in items},
            {"01 身份与事实基线", "06 情绪与状态模型", "15 待确认问题"},
        )
        section = next(
            item
            for item in items
            if item.sheet.startswith("01") and item.row == 1
        )
        self.assertEqual(section.cells, ["身份事实"])
        structured = next(
            item
            for item in items
            if item.sheet.startswith("01") and item.row == 2
        )
        self.assertEqual(structured.cells[:3], ["持续兴趣", "旅行", "可"])
        self.assertEqual(structured.cells[-1], f"{SECTION_CONTEXT_PREFIX}身份事实")


if __name__ == "__main__":
    unittest.main()
