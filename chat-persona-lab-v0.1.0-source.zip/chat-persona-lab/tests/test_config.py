from __future__ import annotations

import os
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from persona_agent.config import OPENCODE_GO_BASE_URL, AppConfig
from tests.test_service import test_config


class ConfigSafetyTests(unittest.TestCase):
    def test_from_root_derives_opencode_endpoint_and_separate_key(self) -> None:
        with tempfile.TemporaryDirectory() as directory, patch.dict(
            os.environ, {}, clear=True
        ):
            root = Path(directory)
            (root / ".env").write_text(
                "\n".join(
                    (
                        "MODEL_PROVIDER=opencode_go",
                        "OPENCODE_GO_API_KEY=go-key",
                        "DEEPSEEK_API_KEY=direct-key",
                        "DEEPSEEK_BASE_URL=https://api.deepseek.com",
                        "CLOUD_PROVIDER_ACK=opencode_go",
                    )
                ),
                encoding="utf-8",
            )
            config = AppConfig.from_root(root)
            self.assertEqual(config.model_provider, "opencode_go")
            self.assertEqual(config.deepseek_base_url, OPENCODE_GO_BASE_URL)
            self.assertEqual(config.opencode_go_api_key, "go-key")

    def test_legacy_deepseek_configuration_remains_the_default(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                send_enabled=False,
                deepseek_api_key="direct-key",
                allow_cloud_processing=True,
            )
            self.assertEqual(config.model_provider, "deepseek_official")
            config.validate(require_api=True)

    def test_cloud_use_requires_key_and_explicit_consent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(test_config(Path(directory)), send_enabled=False)
            with self.assertRaises(ValueError):
                config.validate(require_api=True)
            with self.assertRaises(ValueError):
                replace(config, deepseek_api_key="secret").validate(require_api=True)
            replace(
                config,
                deepseek_api_key="secret",
                allow_cloud_processing=True,
            ).validate(require_api=True)

    def test_custom_model_endpoint_is_rejected_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                send_enabled=False,
                deepseek_base_url="http://127.0.0.1:9000",
            )
            with self.assertRaises(ValueError):
                config.validate()

    def test_opencode_go_requires_its_own_key_and_provider_ack(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                send_enabled=False,
                model_provider="opencode_go",
                deepseek_base_url=OPENCODE_GO_BASE_URL,
                deepseek_api_key="must-not-count-as-go-key",
                allow_cloud_processing=True,
            )
            with self.assertRaisesRegex(ValueError, "OPENCODE_GO_API_KEY"):
                config.validate(require_api=True)
            config = replace(config, opencode_go_api_key="go-key")
            with self.assertRaisesRegex(ValueError, "CLOUD_PROVIDER_ACK"):
                config.validate(require_api=True)
            replace(config, cloud_provider_ack="opencode_go").validate(require_api=True)

    def test_opencode_go_uses_only_the_fixed_endpoint(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                send_enabled=False,
                model_provider="opencode_go",
                deepseek_base_url="https://relay.example/v1",
                allow_custom_model_endpoint=True,
            )
            with self.assertRaisesRegex(ValueError, "固定地址"):
                config.validate()

    def test_provider_and_model_are_allowlisted(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(test_config(Path(directory)), send_enabled=False)
            with self.assertRaisesRegex(ValueError, "MODEL_PROVIDER"):
                replace(config, model_provider="other").validate()
            with self.assertRaisesRegex(ValueError, "模型只允许"):
                replace(config, deepseek_model="opencode-go/deepseek-v4-pro").validate()
            replace(config, deepseek_model="deepseek-v4-pro").validate()

    def test_send_capability_has_no_unlock_secret_configuration(self) -> None:
        self.assertNotIn("approval_secret", AppConfig.__dataclass_fields__)

    def test_real_wechat_send_is_limited_to_test_account_acceptance(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxautox4",
                contact_whitelist=("唯一测试备注名",),
                wx_account_nickname="专用测试账号",
                wx_live_validated=True,
                wx_live_unlock="ENABLE_REAL_WECHAT_SEND",
                wx_test_account_mode=False,
            )
            with self.assertRaises(ValueError):
                config.validate()
            replace(config, wx_test_account_mode=True).validate()

    def test_real_wechat_requires_expected_account_even_when_read_only(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxautox4",
                contact_whitelist=("唯一测试备注名",),
                send_enabled=False,
                wx_account_nickname="",
            )
            with self.assertRaisesRegex(ValueError, "WX_ACCOUNT_NICKNAME"):
                config.validate()
            replace(config, wx_account_nickname="专用测试账号").validate()

    def test_free_wechat_polling_send_is_single_contact_and_target_locked(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxauto4_polling",
                contact_whitelist=("联系人一", "联系人二"),
                wx_account_nickname="生产账号",
                send_enabled=False,
            )
            with self.assertRaisesRegex(ValueError, "只能配置一个"):
                config.validate()
            config = replace(
                config,
                contact_whitelist=("联系人一",),
                wx_account_nickname="虚构演示账号",
                send_enabled=True,
                wx_live_validated=True,
                wx_test_account_mode=True,
                wx_live_unlock="ENABLE_REAL_WECHAT_SEND",
            )
            with self.assertRaisesRegex(ValueError, "WX_SEND_CONTACT_KEY"):
                config.validate()
            config = replace(
                config,
                contact_whitelist=("demo_friend",),
                wx_account_nickname="虚构演示账号",
                wx_send_contact_key="live:demo_friend",
            )
            with self.assertRaisesRegex(ValueError, "专用解锁短语"):
                config.validate()
            replace(
                config,
                wx_polling_send_unlock="ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT",
            ).validate()
            replace(config, send_enabled=False).validate()

    def test_global_readonly_wechat_requires_the_expected_account(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxauto4_global_readonly",
                contact_whitelist=(),
                send_enabled=False,
                wx_account_nickname="",
            )
            with self.assertRaisesRegex(ValueError, "WX_ACCOUNT_NICKNAME"):
                config.validate()

            replace(config, wx_account_nickname="专用只读账号").validate()

    def test_global_readonly_wechat_forbids_send_capability(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxauto4_global_readonly",
                contact_whitelist=(),
                send_enabled=True,
                wx_account_nickname="专用只读账号",
            )
            with self.assertRaisesRegex(ValueError, "禁止.*SEND_ENABLED|SEND_ENABLED.*禁止"):
                config.validate()

    def test_global_readonly_wechat_does_not_accept_contact_whitelist(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                adapter_mode="wxauto4_global_readonly",
                contact_whitelist=(),
                send_enabled=False,
                wx_account_nickname="专用只读账号",
            )
            # Identity approval is stored in adapter_identities; the legacy
            # sender whitelist must be absent in this read-only discovery mode.
            config.validate()
            with self.assertRaisesRegex(ValueError, "CONTACT_WHITELIST"):
                replace(config, contact_whitelist=("不应预先信任的备注名",)).validate()

    def test_global_launcher_blank_overrides_cannot_rebound_from_dotenv(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / ".env").write_text(
                "\n".join(
                    (
                        "CONTACT_WHITELIST=demo_friend",
                        "WX_LIVE_UNLOCK=ENABLE_REAL_WECHAT_SEND",
                        "WX_SEND_CONTACT_KEY=live:demo_friend",
                        "WX_POLLING_SEND_UNLOCK=ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT",
                        "APPROVAL_SECRET=legacy-secret",
                    )
                ),
                encoding="utf-8",
            )
            # PowerShell 7 deletes an environment variable assigned ''.  The
            # launcher therefore uses one space to keep a process-level value;
            # AppConfig normalizes that sentinel back to the intended empty value.
            with patch.dict(
                os.environ,
                {
                    "CHAT_ADAPTER": "wxauto4_global_readonly",
                    "SEND_ENABLED": "false",
                    "CONTACT_WHITELIST": " ",
                    "WX_ACCOUNT_NICKNAME": "专用只读账号",
                    "WX_GLOBAL_PARKING_CHAT": "文件传输助手",
                    "WX_LIVE_VALIDATED": "false",
                    "WX_TEST_ACCOUNT_MODE": "false",
                    "WX_LIVE_UNLOCK": " ",
                    "WX_SEND_CONTACT_KEY": " ",
                    "WX_POLLING_SEND_UNLOCK": " ",
                    "APPROVAL_SECRET": " ",
                },
                clear=True,
            ):
                config = AppConfig.from_root(root)
                self.assertEqual(config.contact_whitelist, ())
                self.assertEqual(config.wx_live_unlock, "")
                self.assertEqual(config.wx_send_contact_key, "")
                self.assertEqual(config.wx_polling_send_unlock, "")
                self.assertEqual(os.environ["APPROVAL_SECRET"], " ")
                config.validate()

    def test_global_launcher_overrides_unsafe_local_sender_settings(self) -> None:
        from persona_agent.global_launcher import readonly_overrides
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / '.env').write_text(
                'CHAT_ADAPTER=wxauto4_polling\nSEND_ENABLED=true\n'
                'CONTACT_WHITELIST=fictional_sender\n'
                'WX_ACCOUNT_NICKNAME=fictional_account\n'
                'WX_SEND_CONTACT_KEY=fictional_key\n'
                'WX_POLLING_SEND_UNLOCK=previous_unlock\n', encoding='utf-8')
            with patch.dict(os.environ, readonly_overrides(), clear=True):
                config = AppConfig.from_root(root)
                config.validate()
                self.assertEqual(config.adapter_mode, 'wxauto4_global_readonly')
                self.assertFalse(config.send_enabled)
                self.assertFalse(config.contact_whitelist)
                self.assertFalse(config.wx_send_contact_key)
                self.assertFalse(config.wx_polling_send_unlock)


if __name__ == "__main__":
    unittest.main()
