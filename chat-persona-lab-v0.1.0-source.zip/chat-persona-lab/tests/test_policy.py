from __future__ import annotations

import unittest

from persona_agent.policy import RiskEngine


class PolicyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = RiskEngine()

    def test_blocks_money(self) -> None:
        result = self.engine.assess("你先帮我转账吧")
        self.assertEqual(result.action, "blocked")
        self.assertEqual(result.level, "high")

    def test_blocks_identity_question(self) -> None:
        self.assertEqual(self.engine.assess("你是不是机器人？").action, "blocked")

    def test_invitation_stays_draft(self) -> None:
        result = self.engine.assess("周末有空一起吃饭吗")
        self.assertEqual(result.action, "draft")
        self.assertEqual(result.level, "medium")

    def test_low_risk_still_requires_draft(self) -> None:
        result = self.engine.assess("你到家没")
        self.assertEqual(result.action, "draft")

    def test_additional_high_risk_phrasings_are_blocked(self) -> None:
        messages = (
            "发烧吃什么药",
            "帮我付一下100元",
            "这个协议怎么签",
            "把微信账号发我",
            "我们在一起吧",
            "我准备跳槽",
            "这是AI自动生成的吗",
        )
        for message in messages:
            with self.subTest(message=message):
                self.assertEqual(self.engine.assess(message).action, "blocked")


if __name__ == "__main__":
    unittest.main()
