from __future__ import annotations

import tempfile
import time
import unittest
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from persona_agent.adapters import MockAdapter, SendBlockedError
from persona_agent.deepseek import FakeDraftModel
from persona_agent.global_read import WxAuto4GlobalReadonlyAdapter
from persona_agent.models import AdapterEnvelope, wechat_account_scope
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.store import Store
from tests.test_service import test_config


ACCOUNT = "合成全局只读账号"
PARKING_CHAT = "合成停车会话"


def message(
    identity: str,
    content: str,
    *,
    attr: str = "friend",
    msg_type: str = "text",
):
    return SimpleNamespace(
        id=identity,
        hash=f"hash-{identity}" if identity else "",
        attr=attr,
        type=msg_type,
        content=content,
        sender="合成好友" if attr == "friend" else ACCOUNT,
    )


class FakeControl:
    ControlTypeName = "ListItemControl"

    def __init__(self, item) -> None:
        self.message = item
        self.runtimeid = (91, str(item.id or item.hash))


class FakeMsgBox:
    def __init__(self, wx: "FakeWeChat") -> None:
        self.wx = wx

    def GetChildren(self):
        alias = self.wx.current_alias
        self.wx.message_reads[alias] = self.wx.message_reads.get(alias, 0) + 1
        return [FakeControl(item) for item in self.wx.messages.get(alias, [])]


class FakeSession:
    def __init__(
        self,
        wx: "FakeWeChat",
        name: str,
        *,
        isnew: bool = False,
        new_count: int = 0,
    ) -> None:
        self.wx = wx
        self.name = name
        self.isnew = isnew
        self.new_count = new_count
        self.runtimeid = (37, name)
        self.click_count = 0
        self.click_error: Exception | None = None

    def set_unread(self, count: int, *, isnew: bool) -> None:
        self.new_count = count
        self.isnew = isnew

    def click(self) -> None:
        self.click_count += 1
        if self.click_error is not None:
            raise self.click_error
        self.wx.current_alias = self.name
        # Real WeChat clears the visible unread marker after the session opens.
        self.new_count = 0
        self.isnew = False


class FakeWeChat:
    def __init__(self) -> None:
        self.current_alias = PARKING_CHAT
        self.account_info = {"nickname": ACCOUNT, "wxid": "wxid-synthetic-account"}
        self.sessions: list[FakeSession] = []
        self.chat_types: dict[str, str] = {PARKING_CHAT: "friend"}
        self.messages: dict[str, list[object]] = {PARKING_CHAT: []}
        self.chat_calls: list[tuple[str, bool]] = []
        self.message_reads: dict[str, int] = {}
        self.reported_alias: str | None = None
        self.reported_chat_type: str | None = None
        self.ChatBox = SimpleNamespace(msgbox=FakeMsgBox(self))

    def add_session(
        self,
        alias: str,
        *,
        chat_type: str = "friend",
        isnew: bool = False,
        new_count: int = 0,
    ) -> FakeSession:
        session = FakeSession(
            self, alias, isnew=isnew, new_count=new_count
        )
        self.sessions.append(session)
        self.chat_types[alias] = chat_type
        self.messages.setdefault(alias, [])
        return session

    def IsOnline(self) -> bool:
        return True

    def GetMyInfo(self) -> dict[str, str]:
        return dict(self.account_info)

    def GetSession(self):
        return list(self.sessions)

    def ChatInfo(self) -> dict[str, str]:
        return {
            "chat_name": self.reported_alias or self.current_alias,
            "chat_type": self.reported_chat_type
            or self.chat_types.get(self.current_alias, "unknown"),
        }

    def ChatWith(self, who: str, exact: bool = True):
        self.chat_calls.append((who, exact))
        self.current_alias = who


class FakeWxAuto4Module:
    def __init__(self, wx: FakeWeChat) -> None:
        self.wx = wx
        self.construct_kwargs: dict[str, object] = {}

    def WeChat(self, **kwargs):
        self.construct_kwargs = dict(kwargs)
        return self.wx

    @staticmethod
    def parse_msg(control, parent):
        return control.message


def configured_adapter(
    *, poll_seconds: float = 30, state_dir: Path | None = None
) -> WxAuto4GlobalReadonlyAdapter:
    return WxAuto4GlobalReadonlyAdapter(
        expected_version="41.1.2",
        expected_account_nickname=ACCOUNT,
        parking_chat=PARKING_CHAT,
        poll_seconds=poll_seconds,
        state_dir=state_dir,
    )


def wait_until(predicate, *, timeout: float = 1.5) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    raise AssertionError("condition was not reached before timeout")


class WxAuto4GlobalReadonlyAdapterTests(unittest.TestCase):
    def start_adapter(self, adapter, wx, callback) -> FakeWxAuto4Module:
        module = FakeWxAuto4Module(wx)
        with patch(
            "persona_agent.global_read.importlib.metadata.version",
            return_value="41.1.2",
        ), patch(
            "persona_agent.global_read.importlib.import_module",
            return_value=module,
        ):
            adapter.start(callback)
        self.addCleanup(adapter.stop)
        return module

    def test_start_requires_a_zero_unread_baseline(self) -> None:
        wx = FakeWeChat()
        unread = wx.add_session("启动前未读好友", isnew=True, new_count=2)
        wx.messages[unread.name] = [
            message("baseline-1", "启动前消息一"),
            message("baseline-2", "启动前消息二"),
        ]
        adapter = configured_adapter()
        module = FakeWxAuto4Module(wx)
        try:
            with patch(
                "persona_agent.global_read.importlib.metadata.version",
                return_value="41.1.2",
            ), patch(
                "persona_agent.global_read.importlib.import_module",
                return_value=module,
            ):
                with self.assertRaisesRegex(RuntimeError, "未读|基线"):
                    adapter.start(lambda event: None)
        finally:
            adapter.stop()

        self.assertEqual(unread.click_count, 0)
        self.assertFalse(adapter.health()["running"])

    def test_poll_ignores_sessions_unless_isnew_and_new_count_are_both_positive(self) -> None:
        wx = FakeWeChat()
        count_only = wx.add_session("只有计数")
        marker_only = wx.add_session("只有新消息标记")
        wx.messages[count_only.name] = [message("count-1", "不应读取一")]
        wx.messages[marker_only.name] = [message("marker-1", "不应读取二")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)

        count_only.set_unread(1, isnew=False)
        marker_only.set_unread(0, isnew=True)
        adapter._poll_once()

        self.assertEqual(received, [])
        self.assertEqual(count_only.click_count, 0)
        self.assertEqual(marker_only.click_count, 0)

    def test_friend_session_click_is_verified_and_last_new_friend_messages_emit_fifo(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成好友甲")
        wx.messages[session.name] = [
            message("history-1", "旧消息一"),
            message("history-2", "旧消息二"),
            message("new-1", "新消息一"),
            message("new-2", "新消息二"),
        ]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        module = self.start_adapter(adapter, wx, received.append)

        session.set_unread(2, isnew=True)
        adapter._poll_once()

        self.assertEqual(session.click_count, 1)
        self.assertEqual([item.text for item in received], ["新消息一", "新消息二"])
        self.assertTrue(all(isinstance(item, AdapterEnvelope) for item in received))
        self.assertTrue(all(item.chat_type == "friend" for item in received))
        self.assertTrue(all(item.sender_role == "friend" for item in received))
        self.assertTrue(all(item.message_type == "text" for item in received))
        self.assertTrue(all(item.releasable for item in received))
        self.assertTrue(all(item.external_identity for item in received))
        self.assertTrue(all(item.event_id for item in received))
        self.assertEqual(
            received[0].account_scope,
            wechat_account_scope(ACCOUNT, "wxid-synthetic-account"),
        )
        self.assertEqual(received[0].identity_quality, "uia_runtime")
        self.assertEqual(received[0].adapter_kind, "wxauto4_global_readonly")
        self.assertEqual(received[0].metadata["account_nickname"], ACCOUNT)
        self.assertEqual(
            received[0].metadata["account_wechat_id"], "wxid-synthetic-account"
        )
        self.assertEqual(wx.current_alias, PARKING_CHAT)
        self.assertEqual(module.construct_kwargs, {"ads": False, "resize": False})

    def test_scanner_restart_rotates_unstable_friend_identity_generation(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成好友重启身份")
        wx.messages[session.name] = [message("same-ui-message", "相同合成正文")]

        first_events: list[AdapterEnvelope] = []
        first = configured_adapter()
        self.start_adapter(first, wx, first_events.append)
        first_generation = str(first.health()["adapter_run_generation"])
        session.set_unread(1, isnew=True)
        first._poll_once()
        first.stop()

        second_events: list[AdapterEnvelope] = []
        second = configured_adapter()
        self.start_adapter(second, wx, second_events.append)
        second_generation = str(second.health()["adapter_run_generation"])
        session.set_unread(1, isnew=True)
        second._poll_once()

        self.assertNotEqual(first_generation, second_generation)
        self.assertNotEqual(first_events[0].event_id, second_events[0].event_id)
        self.assertNotEqual(
            first_events[0].external_identity,
            second_events[0].external_identity,
        )

    def test_group_chat_after_click_produces_zero_callback_and_reads_no_body(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成群聊", chat_type="group")
        wx.messages[session.name] = [message("group-1", "群聊正文不应读取")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.message_reads.clear()

        session.set_unread(1, isnew=True)
        adapter._poll_once()

        self.assertEqual(session.click_count, 1)
        self.assertEqual(received, [])
        self.assertEqual(wx.message_reads.get(session.name, 0), 0)
        self.assertEqual(adapter.health()["filtered_group_count"], 1)
        self.assertEqual(wx.current_alias, PARKING_CHAT)

    def test_last_n_friend_messages_filter_self_and_nontext(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成好友乙")
        wx.messages[session.name] = [
            message("old-friend", "更早的好友消息"),
            message("new-text-1", "需要回调一"),
            message("self-1", "自己发的", attr="self"),
            message("new-image", "[图片]", msg_type="image"),
            message("new-text-2", "需要回调二"),
        ]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)

        session.set_unread(3, isnew=True)
        adapter._poll_once()

        self.assertEqual([item.text for item in received], ["需要回调一", "需要回调二"])
        health = adapter.health()
        self.assertEqual(health["filtered_self_count"], 1)
        self.assertEqual(health["filtered_nontext_count"], 1)

    def test_duplicate_message_identity_is_emitted_once(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成好友丙")
        wx.messages[session.name] = [message("stable-message-id", "重复扫描内容")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)

        session.set_unread(1, isnew=True)
        adapter._poll_once()
        session.set_unread(1, isnew=True)
        adapter._poll_once()

        self.assertEqual(len(received), 1)
        self.assertEqual(received[0].text, "重复扫描内容")
        self.assertEqual(adapter.health()["accepted_event_count"], 1)

    def test_duplicate_session_names_are_never_clicked_or_emitted(self) -> None:
        wx = FakeWeChat()
        first = wx.add_session("完全相同备注")
        second = wx.add_session("完全相同备注")
        wx.messages[first.name] = [message("ambiguous-1", "歧义消息")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        module = FakeWxAuto4Module(wx)
        try:
            with patch(
                "persona_agent.global_read.importlib.metadata.version",
                return_value="41.1.2",
            ), patch(
                "persona_agent.global_read.importlib.import_module",
                return_value=module,
            ):
                with self.assertRaisesRegex(RuntimeError, "重复备注|唯一身份"):
                    adapter.start(received.append)
        finally:
            adapter.stop()

        self.assertEqual(received, [])
        self.assertEqual(first.click_count, 0)
        self.assertEqual(second.click_count, 0)
        self.assertEqual(wx.message_reads.get(first.name, 0), 0)
        self.assertGreaterEqual(adapter.health()["ambiguous_alias_count"], 1)

    def test_chatinfo_alias_drift_fails_before_read_or_callback(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("预期精确备注")
        wx.messages[session.name] = [message("alias-drift-1", "不得读取")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.message_reads.clear()
        wx.reported_alias = "切换后的其他备注"
        session.set_unread(1, isnew=True)

        # Advance only the adapter's timeout clock; the test must not spend the
        # real five-second safety timeout waiting for a deliberately wrong chat.
        with patch(
            "persona_agent.global_read.time.monotonic",
            side_effect=[10.0, 10.0, 16.0],
        ):
            with self.assertRaisesRegex(RuntimeError, "精确会话|实际"):
                adapter._poll_once()

        self.assertEqual(received, [])
        self.assertEqual(session.click_count, 1)
        self.assertEqual(wx.message_reads.get(session.name, 0), 0)

    def test_unknown_chatinfo_type_is_excluded_without_reading_body(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("未知类型会话")
        wx.messages[session.name] = [message("unknown-type-1", "不得读取正文")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        wx.message_reads.clear()
        wx.reported_chat_type = "unknown"
        session.set_unread(1, isnew=True)

        adapter._poll_once()

        self.assertEqual(received, [])
        self.assertEqual(session.click_count, 1)
        self.assertEqual(wx.message_reads.get(session.name, 0), 0)
        self.assertEqual(adapter.health()["accepted_event_count"], 0)

    def test_session_switch_exception_stops_scanner_without_read_or_callback(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("切换异常会话")
        wx.messages[session.name] = [message("switch-fail-1", "不得读取正文")]
        received: list[AdapterEnvelope] = []
        adapter = configured_adapter(poll_seconds=0.5)
        self.start_adapter(adapter, wx, received.append)
        wx.message_reads.clear()
        session.click_error = RuntimeError("synthetic session switch failure")
        session.set_unread(1, isnew=True)

        wait_until(lambda: adapter.health()["running"] is False, timeout=1.5)

        self.assertEqual(received, [])
        self.assertEqual(session.click_count, 1)
        self.assertEqual(wx.message_reads.get(session.name, 0), 0)
        self.assertIn("synthetic session switch failure", adapter.health()["last_error"])

    def test_restart_treats_reused_uia_token_as_new_run_scoped_event(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = replace(
                test_config(root),
                adapter_mode="wxauto4_global_readonly",
                wx_account_nickname=ACCOUNT,
                send_enabled=False,
            )
            store = Store(config.db_path)
            service = PersonaService(
                config=config,
                store=store,
                model=FakeDraftModel(),
                profile_retriever=ProfileRetriever([]),
                adapter=MockAdapter(),
            )
            wx = FakeWeChat()
            session = wx.add_session("重启重放好友")
            wx.messages[session.name] = [
                message("restart-stable-id", "重启重放合成消息")
            ]
            callback_event_ids: list[str] = []

            def route(event: AdapterEnvelope) -> None:
                callback_event_ids.append(event.event_id)
                service.receive_adapter_event(event)

            first = configured_adapter()
            self.start_adapter(first, wx, route)
            session.set_unread(1, isnew=True)
            first._poll_once()
            first.stop()

            second = configured_adapter()
            self.start_adapter(second, wx, route)
            session.set_unread(1, isnew=True)
            second._poll_once()

            self.assertEqual(len(callback_event_ids), 2)
            self.assertEqual(len(set(callback_event_ids)), 2)
            identities = store.list_adapter_identities()
            self.assertEqual(len(identities), 2)
            self.assertEqual(
                sorted(item["status"] for item in identities),
                ["pending", "stale"],
            )
            quarantined = store.list_quarantined_incoming()
            self.assertEqual(len(quarantined), 2)
            self.assertEqual(
                sorted(item["reason"] for item in quarantined),
                ["identity_generation_expired", "unbound_identity"],
            )
            self.assertEqual(store.counts()["incoming"], 0)
            self.assertEqual(store.counts()["drafts"], 0)

    def test_callback_failure_stops_background_scanner(self) -> None:
        wx = FakeWeChat()
        session = wx.add_session("合成好友丁")
        wx.messages[session.name] = [message("callback-fail-1", "触发回调失败")]
        calls: list[AdapterEnvelope] = []

        def failing_callback(event: AdapterEnvelope) -> None:
            calls.append(event)
            raise RuntimeError("synthetic callback failure")

        adapter = configured_adapter(poll_seconds=0.5)
        self.start_adapter(adapter, wx, failing_callback)
        session.set_unread(1, isnew=True)

        wait_until(lambda: adapter.health()["running"] is False, timeout=1.5)

        self.assertEqual(len(calls), 1)
        self.assertIn("synthetic callback failure", adapter.health()["last_error"])
        self.assertFalse(adapter.health()["send_capable"])
        self.assertEqual(wx.current_alias, PARKING_CHAT)
        self.assertEqual(
            adapter.health()["capture_guarantee"],
            "best_effort_ui_unread_scan",
        )

    def test_durable_spool_replays_after_callback_crash_without_duplicate_click(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory) / "capture-state"
            wx = FakeWeChat()
            session = wx.add_session("合成恢复好友")
            wx.messages[session.name] = [message("recover-1", "需要恢复的消息")]
            first_calls: list[AdapterEnvelope] = []

            def fail_after_observation(event: AdapterEnvelope) -> None:
                first_calls.append(event)
                raise RuntimeError("synthetic durable callback crash")

            first = configured_adapter(state_dir=state_dir)
            self.start_adapter(first, wx, fail_after_observation)
            session.set_unread(1, isnew=True)
            with self.assertRaisesRegex(RuntimeError, "durable callback crash"):
                first._poll_once()
            first.stop()

            self.assertTrue((state_dir / "scan-intent.json").exists())
            self.assertTrue((state_dir / "captured-spool.json").exists())
            self.assertEqual(session.click_count, 1)

            recovered: list[AdapterEnvelope] = []
            second = configured_adapter(state_dir=state_dir)
            self.start_adapter(second, wx, recovered.append)

            self.assertEqual([item.text for item in recovered], ["需要恢复的消息"])
            self.assertEqual(recovered[0].event_id, first_calls[0].event_id)
            self.assertEqual(session.click_count, 1)
            self.assertFalse((state_dir / "scan-intent.json").exists())
            self.assertFalse((state_dir / "captured-spool.json").exists())

    def test_unspooled_scan_intent_blocks_restart_until_manual_audit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            state_dir = Path(directory) / "capture-state"
            adapter = configured_adapter(state_dir=state_dir)
            adapter._write_scan_intent("待人工核对好友", "uia:synthetic", 1)
            wx = FakeWeChat()
            module = FakeWxAuto4Module(wx)
            try:
                with patch(
                    "persona_agent.global_read.importlib.metadata.version",
                    return_value="41.1.2",
                ), patch(
                    "persona_agent.global_read.importlib.import_module",
                    return_value=module,
                ):
                    with self.assertRaisesRegex(RuntimeError, "待人工核对好友|人工核对"):
                        adapter.start(lambda event: None)
            finally:
                adapter.stop()

            self.assertTrue((state_dir / "scan-intent.json").exists())
            self.assertFalse((state_dir / "captured-spool.json").exists())
            self.assertFalse(adapter.health()["running"])

    def test_send_text_is_permanently_blocked(self) -> None:
        adapter = configured_adapter()

        with self.assertRaisesRegex(SendBlockedError, "只读|未被调用"):
            adapter.send_text(
                "global:synthetic",
                "合成好友",
                "绝不能发送",
                "synthetic-send-key",
            )

        self.assertFalse(adapter.destination_matches("x", "y", "z"))
        self.assertTrue(adapter.health()["read_only"])
        self.assertFalse(adapter.health()["send_capable"])


if __name__ == "__main__":
    unittest.main()
