from __future__ import annotations

import json
import unittest

from persona_agent.style_memory import build_style_fingerprint


class StyleMemoryTests(unittest.TestCase):
    def test_builds_anonymous_statistics_and_requires_cross_contact_phrases(self) -> None:
        rows = [
            {
                "contact_key": "contact-secret-a",
                "relationship": "亲近朋友",
                "content": "哈哈哈，没问题",
                "source_file": "private-a.txt",
            },
            {
                "contact_key": "contact-secret-a",
                "relationship": "亲近朋友",
                "content": "only-one-contact-canary okok",
                "source_file": "private-a.txt",
            },
            {
                "contact_key": "contact-secret-b",
                "relationship": "普通朋友",
                "content": "哈哈哈，可以",
                "source_file": "private-b.txt",
            },
            {
                "contact_key": "contact-secret-c",
                "relationship": "工作同事",
                "content": "没问题。",
                "source_file": "private-c.txt",
            },
        ]

        fingerprint = build_style_fingerprint(rows)
        payload = fingerprint.to_prompt_payload()
        serialized = json.dumps(payload, ensure_ascii=False)

        self.assertEqual(fingerprint.source_contact_count, 3)
        self.assertEqual(fingerprint.self_message_count, 4)
        phrases = {item.phrase for item in fingerprint.safe_phrases}
        self.assertIn("哈哈哈", phrases)
        self.assertIn("没问题", phrases)
        self.assertNotIn("okok", phrases)
        for private_value in (
            "contact-secret-a",
            "contact-secret-b",
            "contact-secret-c",
            "private-a.txt",
            "private-b.txt",
            "only-one-contact-canary",
            "亲近朋友",
        ):
            self.assertNotIn(private_value, serialized)

    def test_rejects_weakened_phrase_anonymity(self) -> None:
        with self.assertRaises(ValueError):
            build_style_fingerprint([], minimum_phrase_contacts=1)

    def test_empty_input_has_stable_zero_metrics(self) -> None:
        fingerprint = build_style_fingerprint([])

        self.assertEqual(fingerprint.source_contact_count, 0)
        self.assertEqual(fingerprint.self_message_count, 0)
        self.assertEqual(fingerprint.safe_phrases, ())
        self.assertEqual(fingerprint.metrics["median_message_chars"], 0)
        self.assertEqual(fingerprint.metrics["short_message_ratio"], 0.0)


if __name__ == "__main__":
    unittest.main()
