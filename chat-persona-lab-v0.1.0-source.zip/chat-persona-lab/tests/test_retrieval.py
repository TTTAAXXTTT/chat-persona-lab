from __future__ import annotations

import unittest

from persona_agent.models import ProfileItem
from persona_agent.retrieval import ProfileRetriever, retrieve_examples
from persona_agent.xlsx_profile import SECTION_CONTEXT_PREFIX


class RetrievalPrivacyTests(unittest.TestCase):
    def test_zero_semantic_overlap_sends_no_historical_example(self) -> None:
        examples = [
            {
                "id": str(index),
                "timestamp": f"2026-07-{index + 1:02d}",
                "incoming": ["周末爬山"],
                "reply": ["可以"],
            }
            for index in range(6)
        ]
        self.assertEqual(retrieve_examples("发票什么时候开", examples), [])

    def test_sheet_15_uses_confirmed_answers_only(self) -> None:
        confirmed = ProfileItem(
            "15 待确认问题",
            6,
            ["口头禅是什么", "哈哈哈", "已确认", f"{SECTION_CONTEXT_PREFIX}语言习惯"],
        )
        pending = ProfileItem(
            "15 待确认问题",
            17,
            ["隐私禁区是什么", "等待回答", "待确认", f"{SECTION_CONTEXT_PREFIX}权限"],
        )
        retriever = ProfileRetriever([confirmed, pending])

        result = retriever.search("哈哈哈", limit=10)

        self.assertIn(confirmed, result)
        self.assertNotIn(pending, result)

    def test_identity_disclosure_policy_and_state_rows_are_semantic_only(self) -> None:
        allowed_identity = ProfileItem(
            "01 身份与事实基线",
            11,
            ["持续兴趣", "旅行", "可在朋友场景自然提及"],
        )
        private_identity = ProfileItem(
            "01 身份与事实基线",
            9,
            ["收入", "私密数值", "否"],
        )
        state_rule = ProfileItem(
            "06 情绪与状态模型",
            6,
            ["低精力", "回复变短", "减少消息数量"],
        )
        retriever = ProfileRetriever([allowed_identity, private_identity, state_rule])

        travel = retriever.search("想去旅行", limit=10)
        income = retriever.search("你的收入", limit=10)
        low_energy = retriever.search("今天低精力", limit=10)
        unrelated = retriever.search("天气不错", limit=10)

        self.assertIn(allowed_identity, travel)
        self.assertNotIn(private_identity, income)
        self.assertIn(state_rule, low_energy)
        self.assertNotIn(state_rule, unrelated)

    def test_sections_and_training_policy_rows_never_become_persona_facts(self) -> None:
        section = ProfileItem("06 情绪与状态模型", 1, ["状态调整"])
        training = ProfileItem(
            "14 训练样本标注",
            10,
            ["隐私等级", "公开或私密", "控制披露"],
        )
        retriever = ProfileRetriever([section, training])

        result = retriever.search("隐私状态调整", limit=10)

        self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
