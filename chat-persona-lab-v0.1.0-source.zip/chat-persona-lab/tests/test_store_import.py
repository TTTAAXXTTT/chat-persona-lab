from __future__ import annotations

import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from persona_agent.models import (
    ChatMessage,
    IncomingMessage,
    ModelDraft,
    ParsedExport,
    RiskDecision,
)
from persona_agent.store import Store


class StoreImportMigrationTests(unittest.TestCase):
    def test_draft_queue_is_strictly_newest_first_with_rowid_tiebreaker(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            store = Store(Path(temp_dir) / "test.sqlite3")
            draft_ids: list[str] = []
            statuses = ["generation_error", "pending", "sent", "rejected"]

            for index, status in enumerate(statuses):
                incoming = IncomingMessage(
                    external_id=f"incoming-{index}",
                    contact_name=f"contact-{index}",
                    contact_key=f"contact-{index}",
                    text=f"message-{index}",
                    timestamp=datetime(2026, 1, 1, 12, index, 0),
                )
                self.assertTrue(store.register_incoming(incoming))
                draft_ids.append(
                    store.create_draft(
                        incoming,
                        ModelDraft(
                            messages=[f"reply-{index}"],
                            confidence=0.9,
                            needs_user_input=False,
                            uncertainties=[],
                        ),
                        RiskDecision(level="low", action="draft", reasons=[]),
                        model="test-model",
                        status=status,
                    )
                )

            with store.connection() as connection:
                timestamps = [
                    "2026-01-01T00:00:00+00:00",
                    "2026-01-01T02:00:00+00:00",
                    "2026-01-01T02:00:00+00:00",
                    "2026-01-01T03:00:00+00:00",
                ]
                for draft_id, created_at in zip(draft_ids, timestamps, strict=True):
                    connection.execute(
                        "UPDATE drafts SET created_at=? WHERE id=?",
                        (created_at, draft_id),
                    )

            ordered_ids = [draft["id"] for draft in store.list_drafts()]

            # Status must not affect queue order. Equal timestamps use the later
            # insertion (higher SQLite rowid) first for deterministic display.
            self.assertEqual(
                ordered_ids,
                [draft_ids[3], draft_ids[2], draft_ids[1], draft_ids[0]],
            )

    def test_style_sources_include_historical_self_only_and_exclude_live_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            source = root / "fictional_friend_messages.txt"
            source.write_text("fictional export", encoding="utf-8")
            export = ParsedExport(
                conversation_name="虚构好友",
                conversation_id="wxid_fictional_friend",
                self_account="fictional_self",
                source_file=str(source.resolve()),
                messages=[
                    ChatMessage(
                        timestamp=datetime(2026, 1, 1, 12, 0, 0),
                        sender_name="fictional_self",
                        sender_id="fictional_self",
                        content="历史导入的虚构本人消息",
                        is_self=True,
                        source_file=str(source.resolve()),
                        source_index=1,
                    )
                ],
            )
            store = Store(root / "test.sqlite3")
            store.import_export(export)
            with store.connection() as connection:
                connection.execute(
                    """
                    INSERT INTO messages(
                        source_key, contact_key, timestamp, sender_role,
                        sender_name, content, source_file, sequence_index
                    ) VALUES (?, ?, ?, 'self', ?, ?, 'live', ?)
                    """,
                    (
                        "fictional-live-self",
                        export.conversation_id,
                        datetime(2026, 1, 1, 12, 1, 0).isoformat(),
                        "fictional_self",
                        "实时产生的虚构本人消息",
                        2,
                    ),
                )
            store.append_outgoing_message(
                draft_id="fictional-draft",
                contact_key=export.conversation_id,
                message_index=0,
                content="模型批准后的虚构发送消息",
            )

            style_rows = store.style_source_messages()

            self.assertEqual(
                [row["content"] for row in style_rows],
                ["历史导入的虚构本人消息"],
            )
            self.assertEqual(style_rows[0]["source_file"], str(source.resolve()))

    def test_knowledge_manifest_hashes_sources_and_omits_absolute_paths_from_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            profile = root / "profile.xlsx"
            chat = root / "friend_messages.txt"
            profile.write_bytes(b"profile-v1")
            chat.write_text("messages-v1", encoding="utf-8")
            store = Store(root / "test.sqlite3")

            store.record_knowledge_source(
                profile,
                kind="profile_xlsx",
                item_count=16,
                metadata={"sheet_count": 16},
            )
            store.record_knowledge_source(
                chat,
                kind="chat_export",
                item_count=20,
                metadata={"self_message_count": 9},
            )
            summary = store.knowledge_summary()

            self.assertEqual(summary["source_count"], 2)
            self.assertEqual(summary["profile_files"], 1)
            self.assertEqual(summary["chat_files"], 1)
            self.assertEqual({item["name"] for item in summary["sources"]}, {profile.name, chat.name})
            self.assertNotIn(str(root), str(summary))
            self.assertTrue(all(len(item["sha256"]) == 64 for item in summary["sources"]))

    def test_reimport_replaces_legacy_compiled_examples(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            source = root / "friend_messages.txt"
            source.write_text("placeholder", encoding="utf-8")
            export = ParsedExport(
                conversation_name="测试好友",
                conversation_id="wxid_test_friend",
                self_account="me",
                source_file=str(source.resolve()),
                messages=[
                    ChatMessage(
                        timestamp=datetime(2026, 1, 1, 12, 0, 0),
                        sender_name="测试好友",
                        sender_id="wxid_test_friend",
                        content="在吗",
                        is_self=False,
                        source_file=str(source.resolve()),
                        source_index=1,
                    ),
                    ChatMessage(
                        timestamp=datetime(2026, 1, 1, 12, 1, 0),
                        sender_name="me",
                        sender_id="me",
                        content="在的",
                        is_self=True,
                        source_file=str(source.resolve()),
                        source_index=2,
                    ),
                ],
            )
            store = Store(root / "test.sqlite3")
            store.import_export(export)
            with store.connection() as connection:
                connection.execute(
                    "UPDATE examples SET source_file='compiled-local'"
                )

            result = store.import_export(export)

            self.assertEqual(result["examples"], 1)
            with store.connection() as connection:
                rows = connection.execute(
                    "SELECT source_file FROM examples WHERE contact_key=?",
                    (export.conversation_id,),
                ).fetchall()
            self.assertEqual([row["source_file"] for row in rows], [str(source.resolve())])


if __name__ == "__main__":
    unittest.main()
