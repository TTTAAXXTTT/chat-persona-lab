from __future__ import annotations

import threading
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from persona_agent.adapters import (
    SendBlockedError,
    SendUncertainError,
    WxAutoX4Adapter,
)


ACCOUNT_NICKNAME = "生产账号"
CONTACT_ALIAS = "唯一好友备注"
DEFAULT_SEND_RESULT = object()


class BoolOnlyResponse:
    """WxResponse-like object whose public contract is only bool(response)."""

    def __init__(self, succeeded: bool, label: str = "result") -> None:
        self.succeeded = succeeded
        self.label = label

    def __bool__(self) -> bool:
        return self.succeeded

    def __str__(self) -> str:
        return self.label


class FakeChildChat:
    def __init__(
        self,
        who: str = CONTACT_ALIAS,
        *,
        chat_type: str = "friend",
        send_result: object = DEFAULT_SEND_RESULT,
    ) -> None:
        self.who = who
        self.chat_type = chat_type
        self.info = {"chat_name": who, "chat_type": chat_type}
        self.send_result = (
            BoolOnlyResponse(True)
            if send_result is DEFAULT_SEND_RESULT
            else send_result
        )
        self.sent: list[dict[str, object]] = []
        self.send_error: Exception | None = None

    def ChatInfo(self) -> dict[str, str]:
        return dict(self.info)

    def SendMsg(self, **kwargs):
        self.sent.append(dict(kwargs))
        if self.send_error is not None:
            raise self.send_error
        return self.send_result


class FakeWeChat:
    def __init__(
        self,
        child: FakeChildChat,
        *,
        online: bool = True,
        account_info: dict[str, str] | None = None,
        listen_result: object | None = None,
    ) -> None:
        self.child = child
        self.online = online
        self.account_info = account_info or {
            "nickname": ACCOUNT_NICKNAME,
            "wxid": "wxid_test_account",
        }
        self.listen_result = child if listen_result is None else listen_result
        self.listen_calls: list[str] = []
        self.stop_calls = 0
        self._stop = threading.Event()

    def IsOnline(self) -> bool:
        return self.online

    def GetMyInfo(self) -> dict[str, str]:
        return dict(self.account_info)

    def AddListenChat(self, nickname, callback):
        self.listen_calls.append(nickname)
        self.callback = callback
        return self.listen_result

    def GetSubWindow(self, nickname):
        return self.child if nickname == self.child.who else None

    def KeepRunning(self) -> None:
        self._stop.wait(5)

    def StopListening(self) -> None:
        self.stop_calls += 1
        self._stop.set()


def configured_adapter() -> WxAutoX4Adapter:
    adapter = WxAutoX4Adapter(
        (CONTACT_ALIAS,),
        "41.1.1.post1",
        ACCOUNT_NICKNAME,
    )
    adapter.configure_bindings(
        {
            CONTACT_ALIAS: {
                "contact_key": "contact-1",
                "display_name": "联系人显示名",
            }
        }
    )
    return adapter


class PatchedWxModule:
    def __init__(self, wx: FakeWeChat) -> None:
        self.wx = wx
        self.selected_nickname: str | None = None

    def WeChat(self, *, nickname: str):
        self.selected_nickname = nickname
        return self.wx


class WxAutoX4AdapterTests(unittest.TestCase):
    def start_adapter(
        self,
        adapter: WxAutoX4Adapter,
        wx: FakeWeChat,
        callback=lambda incoming: None,
    ) -> PatchedWxModule:
        module = PatchedWxModule(wx)
        version_patch = patch(
            "persona_agent.adapters.importlib.metadata.version",
            return_value="41.1.1.post1",
        )
        import_patch = patch(
            "persona_agent.adapters.importlib.import_module",
            return_value=module,
        )
        version_patch.start()
        import_patch.start()
        self.addCleanup(version_patch.stop)
        self.addCleanup(import_patch.stop)
        adapter.start(callback)
        self.addCleanup(adapter.stop)
        return module

    def test_start_validates_account_and_retains_returned_child(self) -> None:
        child = FakeChildChat()
        wx = FakeWeChat(child)
        adapter = configured_adapter()

        module = self.start_adapter(adapter, wx)

        self.assertEqual(module.selected_nickname, ACCOUNT_NICKNAME)
        self.assertIs(adapter._child_chats[CONTACT_ALIAS], child)
        health = adapter.health()
        self.assertTrue(health["online"])
        self.assertEqual(health["account"]["nickname"], ACCOUNT_NICKNAME)
        self.assertTrue(health["account"]["verified"])
        self.assertEqual(health["active_listener_count"], 1)

    def test_start_rejects_offline_or_wrong_account(self) -> None:
        cases = (
            FakeWeChat(FakeChildChat(), online=False),
            FakeWeChat(
                FakeChildChat(),
                account_info={"nickname": "另一个账号", "wxid": "wrong"},
            ),
        )
        for wx in cases:
            with self.subTest(online=wx.online, account=wx.account_info):
                adapter = configured_adapter()
                module = PatchedWxModule(wx)
                with patch(
                    "persona_agent.adapters.importlib.metadata.version",
                    return_value="41.1.1.post1",
                ), patch(
                    "persona_agent.adapters.importlib.import_module",
                    return_value=module,
                ):
                    with self.assertRaises(RuntimeError):
                        adapter.start(lambda incoming: None)
                self.assertEqual(adapter.health()["active_listener_count"], 0)
                self.assertTrue(adapter.health()["last_error"])

    def test_failed_add_listen_response_aborts_start(self) -> None:
        child = FakeChildChat()
        wx = FakeWeChat(child, listen_result=BoolOnlyResponse(False, "not found"))
        adapter = configured_adapter()
        module = PatchedWxModule(wx)

        with patch(
            "persona_agent.adapters.importlib.metadata.version",
            return_value="41.1.1.post1",
        ), patch(
            "persona_agent.adapters.importlib.import_module",
            return_value=module,
        ):
            with self.assertRaisesRegex(RuntimeError, "监听.*失败"):
                adapter.start(lambda incoming: None)

        self.assertEqual(adapter.health()["active_listener_count"], 0)
        self.assertEqual(wx.stop_calls, 1)

    def test_success_response_uses_get_subwindow_fallback(self) -> None:
        child = FakeChildChat()
        wx = FakeWeChat(child, listen_result=BoolOnlyResponse(True))
        adapter = configured_adapter()

        self.start_adapter(adapter, wx)

        self.assertIs(adapter._child_chats[CONTACT_ALIAS], child)

    def test_send_uses_retained_child_and_bool_response_semantics(self) -> None:
        child = FakeChildChat(send_result=BoolOnlyResponse(True))
        wx = FakeWeChat(child)
        adapter = configured_adapter()
        self.start_adapter(adapter, wx)

        adapter.send_text(
            "contact-1",
            "联系人显示名",
            "真实发送内容",
            "send-key-1",
        )

        self.assertEqual(child.sent, [{"msg": "真实发送内容"}])

    def test_pre_send_chat_drift_is_blocked_without_invocation(self) -> None:
        child = FakeChildChat()
        wx = FakeWeChat(child)
        adapter = configured_adapter()
        self.start_adapter(adapter, wx)
        child.info = {"chat_name": "同名群聊", "chat_type": "group"}
        child.chat_type = "group"

        with self.assertRaises(SendBlockedError):
            adapter.send_text(
                "contact-1",
                "联系人显示名",
                "不能发错",
                "send-key-2",
            )

        self.assertEqual(child.sent, [])

    def test_post_invocation_failure_is_uncertain_and_never_retried(self) -> None:
        child = FakeChildChat(send_result=BoolOnlyResponse(False))
        wx = FakeWeChat(child)
        adapter = configured_adapter()
        self.start_adapter(adapter, wx)

        with self.assertRaises(SendUncertainError):
            adapter.send_text(
                "contact-1",
                "联系人显示名",
                "结果未知",
                "send-key-3",
            )
        with self.assertRaises(SendBlockedError):
            adapter.send_text(
                "contact-1",
                "联系人显示名",
                "结果未知",
                "send-key-3",
            )

        self.assertEqual(len(child.sent), 1)

    def test_health_records_last_accepted_event(self) -> None:
        child = FakeChildChat()
        wx = FakeWeChat(child)
        received = []
        adapter = configured_adapter()
        self.start_adapter(adapter, wx, received.append)
        msg = SimpleNamespace(
            attr="friend",
            type="text",
            content="一条新消息",
            id="message-id-1",
            hash="message-hash-1",
            sender=CONTACT_ALIAS,
        )

        adapter._on_message(msg, child)

        self.assertEqual(len(received), 1)
        self.assertEqual(received[0].metadata["adapter_alias"], CONTACT_ALIAS)
        self.assertEqual(received[0].metadata["account_nickname"], ACCOUNT_NICKNAME)
        self.assertIsNotNone(adapter.health()["last_event"])


if __name__ == "__main__":
    unittest.main()
