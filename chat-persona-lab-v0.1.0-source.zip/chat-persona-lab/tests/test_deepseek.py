from __future__ import annotations

import io
import json
import tempfile
import unittest
import urllib.error
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from persona_agent.config import OPENCODE_GO_BASE_URL
from persona_agent.deepseek import DeepSeekClient, _redact, parse_model_draft
from persona_agent.models import ProfileItem, RiskDecision
from tests.test_service import test_config


class CapturingDeepSeekClient(DeepSeekClient):
    def __init__(self, config):
        super().__init__(config)
        self.requests: list[tuple[list[dict[str, str]], str | None]] = []

    def _request(
        self,
        messages: list[dict[str, str]],
        *,
        model_name: str | None = None,
    ) -> str:
        self.requests.append((messages, model_name))
        return '{"messages":["好"],"confidence":0.8,"needs_user_input":false,"uncertainties":[]}'


class DeepSeekTests(unittest.TestCase):
    @staticmethod
    def opencode_config(root: Path):
        return replace(
            test_config(root),
            send_enabled=False,
            model_provider="opencode_go",
            deepseek_base_url=OPENCODE_GO_BASE_URL,
            deepseek_api_key="direct-key-must-not-be-used",
            opencode_go_api_key="go-key-for-tests",
            cloud_provider_ack="opencode_go",
            allow_cloud_processing=True,
        )

    def test_custom_endpoint_omits_official_thinking_parameter(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            official = DeepSeekClient(test_config(Path(directory)))
            custom = DeepSeekClient(
                replace(
                    test_config(Path(directory)),
                    deepseek_base_url="https://relay.example/v1",
                    allow_custom_model_endpoint=True,
                )
            )
            self.assertIn("thinking", official._request_payload([]))
            self.assertNotIn("thinking", custom._request_payload([]))

    def test_opencode_go_has_fixed_endpoint_independent_key_and_v4_payload(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            client = DeepSeekClient(self.opencode_config(Path(directory)))
            payload = client._request_payload([])
            self.assertEqual(client.provider_name, "opencode_go")
            self.assertEqual(client.base_url, OPENCODE_GO_BASE_URL)
            self.assertEqual(client.api_key, "go-key-for-tests")
            self.assertTrue(client.api_key_configured)
            self.assertEqual(payload["model"], "deepseek-v4-flash")
            self.assertEqual(payload["thinking"], {"type": "disabled"})
            self.assertEqual(payload["response_format"], {"type": "json_object"})

    def test_model_selection_is_allowlisted_and_thread_safe_snapshot_is_recorded(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            client = CapturingDeepSeekClient(self.opencode_config(Path(directory)))
            self.assertEqual(
                client.available_models,
                ("deepseek-v4-flash", "deepseek-v4-pro"),
            )
            with self.assertRaises(ValueError):
                client.select_model("opencode-go/deepseek-v4-pro")

            original_request = client._request

            def switch_during_request(messages, *, model_name=None):
                client.select_model("deepseek-v4-pro")
                return original_request(messages, model_name=model_name)

            client._request = switch_during_request  # type: ignore[method-assign]
            draft = client.generate(
                contact_name="联系人",
                relationship="普通朋友",
                incoming_text="在吗",
                current_message_time="2026-08-10T12:00:00",
                recent_context=[],
                profile_items=[],
                examples=[],
                risk=RiskDecision("low", "draft", []),
                private_terms=[],
            )
            self.assertEqual(draft.used_model, "deepseek-v4-flash")
            self.assertEqual(client.requests[0][1], "deepseek-v4-flash")
            self.assertEqual(client.model_name, "deepseek-v4-pro")

    def test_anonymous_style_fingerprint_is_included_without_cross_contact_raw_text(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            client = CapturingDeepSeekClient(self.opencode_config(Path(directory)))
            style_payload = {
                "version": "style-fingerprint-v1",
                "source_contact_count": 6,
                "self_message_count": 120,
                "metrics": {"median_message_chars": 5},
                "safe_phrases": [{"phrase": "哈哈哈", "contact_count": 4}],
                "usage_rule": "只用于总体节奏",
            }
            client.generate(
                contact_name="demo_friend",
                relationship="待确认",
                incoming_text="哈喽",
                current_message_time="2026-08-10T12:00:00",
                recent_context=[],
                profile_items=[],
                examples=[],
                risk=RiskDecision("low", "draft", []),
                private_terms=["其他联系人唯一词"],
                style_fingerprint=style_payload,
            )

            sent_text = client.requests[0][0][1]["content"]
            self.assertIn("anonymous_global_style_fingerprint_all_chat_exports", sent_text)
            self.assertIn("120", sent_text)
            self.assertIn("哈哈哈", sent_text)
            self.assertNotIn("其他联系人唯一词", sent_text)

    def test_http_error_detail_redacts_all_configured_keys_and_bearer_tokens(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                self.opencode_config(Path(directory)),
                deepseek_api_key="direct-secret-123",
                opencode_go_api_key="go-secret-456",
            )
            client = DeepSeekClient(config)
            response_body = (
                '{"error":"Authorization: Bearer go-secret-456; '
                'api_key=direct-secret-123; access_token=sk-abcdefghijklmnop"}'
            ).encode("utf-8")
            http_error = urllib.error.HTTPError(
                client.base_url,
                401,
                "unauthorized",
                {},
                io.BytesIO(response_body),
            )
            with patch("urllib.request.urlopen", side_effect=http_error):
                with self.assertRaises(RuntimeError) as caught:
                    client._request([], model_name="deepseek-v4-flash")
            message = str(caught.exception)
            for secret in (
                "direct-secret-123",
                "go-secret-456",
                "sk-abcdefghijklmnop",
            ):
                self.assertNotIn(secret, message)
            self.assertIn("[API密钥已删除]", message)
            boundary_detail = "x" * 1995 + "go-secret-456"
            self.assertNotIn(
                "go-secret-456",
                client._sanitize_error_detail(boundary_detail),
            )

    def test_reports_reasoning_only_length_response(self) -> None:
        body = {
            "choices": [
                {
                    "finish_reason": "length",
                    "message": {"content": None, "reasoning_content": "思考中"},
                }
            ]
        }
        with self.assertRaisesRegex(RuntimeError, "DEEPSEEK_MAX_TOKENS"):
            DeepSeekClient._response_content(body)

    def test_redacts_common_identifiers_and_private_terms(self) -> None:
        raw = (
            "甲联系人让乙联系人访问 https://example.com，wxid_abc123，"
            "手机号13800138000，密码:abc123，验证码 654321，"
            "地址是虚构示例区域，key=sk-abcdefghijklmnop"
        )
        result = _redact(raw, "甲联系人", ["乙联系人"])
        for secret in (
            "甲联系人",
            "乙联系人",
            "example.com",
            "wxid_abc123",
            "13800138000",
            "abc123",
            "654321",
            "虚构示例区域",
            "sk-abcdefghijklmnop",
        ):
            self.assertNotIn(secret, result)

    def test_parses_structured_draft(self) -> None:
        draft = parse_model_draft(
            '{"messages":["好"],"confidence":0.9,'
            '"needs_user_input":false,"uncertainties":[]}'
        )
        self.assertEqual(draft.messages, ["好"])
        self.assertEqual(draft.confidence, 0.9)

    def test_merges_short_provider_fragments_to_one_in_order(self) -> None:
        source = ["甲段", "乙段", "丙段"]
        self.assertLessEqual(sum(map(len, source)), 24)

        draft = parse_model_draft(
            json.dumps(
                {
                    "messages": source,
                    "confidence": 0.9,
                    "needs_user_input": False,
                    "uncertainties": [],
                },
                ensure_ascii=False,
            )
        )

        self.assertEqual(len(draft.messages), 1)
        self.assertEqual(draft.messages[0].replace("，", ""), "".join(source))

    def test_compacts_four_to_six_long_provider_segments_in_order(self) -> None:
        for count in range(4, 7):
            with self.subTest(count=count):
                source = [f"第{index}段内容需要完整保留" for index in range(1, count + 1)]
                self.assertGreater(sum(map(len, source)), 24)
                draft = parse_model_draft(
                    json.dumps(
                        {
                            "messages": source,
                            "confidence": 0.9,
                            "needs_user_input": False,
                            "uncertainties": [],
                        },
                        ensure_ascii=False,
                    )
                )

                self.assertLessEqual(len(draft.messages), 3)
                flattened = "".join(draft.messages).replace("，", "")
                self.assertEqual(flattened, "".join(source))
                self.assertTrue(all(len(message) <= 500 for message in draft.messages))

    def test_redacts_separated_phone_passport_address_and_api_key(self) -> None:
        raw = (
            "微信号 demo_user_123456，电话 +86 138-0013-8000，护照 E12345678，"
            "我住在成都市武侯区测试路88号，api_key=abcdefghijklmnop"
        )
        result = _redact(raw)
        for secret in (
            "demo_user_123456",
            "138-0013-8000",
            "E12345678",
            "成都市武侯区测试路88号",
            "abcdefghijklmnop",
        ):
            self.assertNotIn(secret, result)

    def test_rejects_schema_coercion_and_silent_truncation(self) -> None:
        invalid_payloads = (
            '{"messages":[123],"needs_user_input":false,"uncertainties":[]}',
            '{"messages":["1","2","3","4","5","6","7"],"needs_user_input":false,"uncertainties":[]}',
            json.dumps(
                {
                    "messages": ["太长" * 151],
                    "needs_user_input": False,
                    "uncertainties": [],
                },
                ensure_ascii=False,
            ),
            '{"messages":["好"],"needs_user_input":"false","uncertainties":[]}',
        )
        for payload in invalid_payloads:
            with self.subTest(payload=payload[:80]):
                with self.assertRaises(ValueError):
                    parse_model_draft(payload)

    def test_total_prompt_respects_context_character_budget(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = replace(
                test_config(Path(directory)),
                send_enabled=False,
                api_context_char_budget=8000,
            )
            client = CapturingDeepSeekClient(config)
            client.generate(
                contact_name="当前联系人",
                relationship="普通朋友",
                incoming_text="今天怎么样" * 200,
                current_message_time="2026-08-03T12:00:00",
                recent_context=[
                    {"timestamp": "2026-08-03T11:00:00", "sender_role": "other", "content": "上下文" * 300}
                    for _ in range(10)
                ],
                profile_items=[
                    ProfileItem("04 语言与沟通指纹", index, ["规则", "短句" * 300])
                    for index in range(20)
                ],
                examples=[
                    {"id": str(index), "timestamp": "2026-07-01", "incoming": ["问" * 500], "reply": ["答" * 500]}
                    for index in range(10)
                ],
                risk=RiskDecision("low", "draft", ["测试"]),
                private_terms=[],
            )
            sent = client.requests[0][0]
            self.assertLessEqual(
                sum(len(message["content"]) for message in sent),
                config.api_context_char_budget,
            )


if __name__ == "__main__":
    unittest.main()
