from __future__ import annotations

import queue
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from persona_agent.adapters import MockAdapter, SendBlockedError
from persona_agent.config import AppConfig
from persona_agent.deepseek import FakeDraftModel
from persona_agent.models import IncomingMessage, ProfileItem
from persona_agent.retrieval import ProfileRetriever
from persona_agent.service import PersonaService
from persona_agent.store import Store


def test_config(root: Path, *, send_enabled: bool = True) -> AppConfig:
    return AppConfig(
        project_root=root,
        data_dir=root / "data",
        db_path=root / "data" / "test.sqlite3",
        profile_xlsx_path=root / "profile.xlsx",
        chat_export_files=(),
        profile_sheet_prefixes=(),
        deepseek_api_key="",
        deepseek_base_url="https://api.deepseek.com",
        deepseek_model="deepseek-v4-flash",
        deepseek_json_mode=True,
        temperature=0.5,
        max_tokens=512,
        host="127.0.0.1",
        port=8765,
        adapter_mode="mock",
        contact_whitelist=(),
        private_terms=(),
        send_enabled=send_enabled,
        allow_cloud_processing=False,
        api_context_char_budget=18_000,
        debounce_seconds=0,
        draft_ttl_seconds=1_800,
        wx_account_nickname="",
        wx_live_validated=False,
        wx_test_account_mode=False,
        wx_live_unlock="",
        wxauto4_expected_version="41.1.2",
        wxautox4_expected_version="41.1.1.post1",
        allow_custom_model_endpoint=False,
        inbox_path=root / "data" / "inbox.jsonl",
        outbox_path=root / "data" / "outbox.jsonl",
    )


def incoming(
    external_id: str,
    contact_key: str,
    text: str,
    *,
    contact_name: str = "同名联系人",
) -> IncomingMessage:
    return IncomingMessage(
        external_id=external_id,
        contact_name=contact_name,
        contact_key=contact_key,
        text=text,
        timestamp=datetime.now(),
        metadata={"source": "direct-test"},
    )


def service_for(
    root: Path,
    *,
    adapter: MockAdapter | None = None,
    model: FakeDraftModel | None = None,
    send_enabled: bool = True,
) -> tuple[PersonaService, Store, MockAdapter]:
    config = test_config(root, send_enabled=send_enabled)
    store = Store(config.db_path)
    selected_adapter = adapter or MockAdapter()
    service = PersonaService(
        config=config,
        store=store,
        model=model or FakeDraftModel(),
        profile_retriever=ProfileRetriever([]),
        adapter=selected_adapter,
    )
    return service, store, selected_adapter


class FailOnSecondSendAdapter(MockAdapter):
    def __init__(self) -> None:
        super().__init__()
        self.calls = 0

    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        self.calls += 1
        if self.calls == 2:
            raise RuntimeError("simulated uncertain second send")
        super().send_text(contact_key, contact_name, text, send_key)


class PreSendBlockedAdapter(MockAdapter):
    def send_text(
        self,
        contact_key: str,
        contact_name: str,
        text: str,
        send_key: str,
    ) -> None:
        raise SendBlockedError("simulated pre-send destination check failure")


class BlockingFirstDraftModel(FakeDraftModel):
    """Keep the first generation in flight while later events enter the FIFO."""

    def __init__(self) -> None:
        self.first_started = threading.Event()
        self.release_first = threading.Event()
        self.calls: list[str] = []

    def generate(self, **kwargs):
        incoming_text = str(kwargs["incoming_text"])
        self.calls.append(incoming_text)
        if len(self.calls) == 1:
            self.first_started.set()
            if not self.release_first.wait(timeout=2):
                raise RuntimeError("test did not release first model generation")
        return super().generate(**kwargs)


class SafetyRegressionTests(unittest.TestCase):
    def test_same_contact_messages_keep_independent_pending_drafts_without_auto_send(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, adapter = service_for(Path(directory))

            draft_ids = [
                service.process(incoming(f"evt-{index}", "contact-1", f"消息-{index}"))
                for index in range(3)
            ]

            self.assertTrue(all(draft_id is not None for draft_id in draft_ids))
            self.assertEqual(
                [store.get_draft(str(draft_id))["status"] for draft_id in draft_ids],
                ["pending", "pending", "pending"],
            )
            self.assertEqual(adapter.sent, [])

    def test_same_contact_burst_during_generation_is_processed_fifo_without_auto_send(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            model = BlockingFirstDraftModel()
            service, store, adapter = service_for(Path(directory), model=model)
            service.start()
            try:
                adapter.emit(incoming("evt-burst-1", "contact-1", "连续消息-1"))
                self.assertTrue(model.first_started.wait(timeout=1))
                adapter.emit(incoming("evt-burst-2", "contact-1", "连续消息-2"))
                adapter.emit(incoming("evt-burst-3", "contact-1", "连续消息-3"))
                self.assertEqual(adapter.sent, [])
                model.release_first.set()

                deadline = time.monotonic() + 2
                while len(store.list_drafts()) < 3 and time.monotonic() < deadline:
                    time.sleep(0.01)

                drafts = store.list_drafts()
                self.assertEqual(model.calls, ["连续消息-1", "连续消息-2", "连续消息-3"])
                self.assertEqual(len(drafts), 3)
                self.assertEqual([draft["status"] for draft in drafts], ["pending"] * 3)
                self.assertEqual(
                    [draft["incoming_text"] for draft in drafts],
                    ["连续消息-3", "连续消息-2", "连续消息-1"],
                )
                self.assertEqual(adapter.sent, [])
            finally:
                model.release_first.set()
                service.stop()

    def test_memory_queue_overflow_is_refilled_from_database_in_rowid_order(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            model = BlockingFirstDraftModel()
            service, store, adapter = service_for(Path(directory), model=model)
            service._queue = queue.Queue(maxsize=1)
            service.start()
            try:
                adapter.emit(incoming("evt-capacity-1", "contact-1", "容量消息-1"))
                self.assertTrue(model.first_started.wait(timeout=1))

                # One event occupies the sole memory slot; later events must be
                # durable in SQLite until the worker creates capacity again.
                adapter.emit(incoming("evt-capacity-2", "contact-1", "容量消息-2"))
                adapter.emit(incoming("evt-capacity-3", "contact-1", "容量消息-3"))
                adapter.emit(incoming("evt-capacity-4", "contact-1", "容量消息-4"))
                with store.connection() as connection:
                    received_ids = [
                        str(row["external_id"])
                        for row in connection.execute(
                            "SELECT external_id FROM incoming "
                            "WHERE status='received' ORDER BY rowid"
                        ).fetchall()
                    ]
                self.assertEqual(received_ids, ["evt-capacity-3", "evt-capacity-4"])
                self.assertEqual(adapter.sent, [])

                model.release_first.set()
                deadline = time.monotonic() + 2
                while len(store.list_drafts()) < 4 and time.monotonic() < deadline:
                    time.sleep(0.01)

                drafts = store.list_drafts()
                self.assertEqual(
                    model.calls,
                    ["容量消息-1", "容量消息-2", "容量消息-3", "容量消息-4"],
                )
                self.assertEqual(len(drafts), 4)
                self.assertEqual([draft["status"] for draft in drafts], ["pending"] * 4)
                self.assertEqual(
                    [draft["incoming_text"] for draft in drafts],
                    ["容量消息-4", "容量消息-3", "容量消息-2", "容量消息-1"],
                )
                self.assertEqual(adapter.sent, [])
            finally:
                model.release_first.set()
                service.stop()

    def test_older_pending_remains_manually_processable_after_newer_message(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, adapter = service_for(Path(directory), send_enabled=False)
            older_id = service.process(incoming("evt-older", "contact-1", "较早消息"))
            newer_id = service.process(incoming("evt-newer", "contact-1", "较新消息"))

            self.assertEqual(adapter.sent, [])
            result = service.approve(str(older_id), ["人工处理较早消息"])

            self.assertEqual(result["status"], "approved_not_sent")
            self.assertEqual(store.get_draft(str(newer_id))["status"], "pending")
            self.assertEqual(adapter.sent, [])

    def test_duplicate_external_id_still_creates_only_one_draft_and_never_auto_sends(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, adapter = service_for(Path(directory))
            repeated = incoming("evt-duplicate", "contact-1", "重复事件")

            first_id = service.process(repeated)
            second_id = service.process(repeated)

            self.assertIsNotNone(first_id)
            self.assertIsNone(second_id)
            self.assertEqual(len(store.list_drafts()), 1)
            self.assertEqual(store.get_draft(str(first_id))["status"], "pending")
            self.assertEqual(adapter.sent, [])

    def test_pending_draft_older_than_ttl_remains_manually_processable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, adapter = service_for(Path(directory), send_enabled=False)
            draft_id = service.process(incoming("evt-old-ttl", "contact-1", "稍后处理"))
            old_created_at = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
            with store.connection() as connection:
                connection.execute(
                    "UPDATE drafts SET created_at=? WHERE id=?",
                    (old_created_at, str(draft_id)),
                )

            self.assertEqual(adapter.sent, [])
            result = service.approve(str(draft_id), ["现在人工处理"])

            self.assertEqual(result["status"], "approved_not_sent")
            self.assertEqual(adapter.sent, [])

    def test_same_display_name_with_different_contact_keys_never_crosses(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, _ = service_for(Path(directory))
            store.ensure_contact("contact-a", "同名联系人")
            store.ensure_contact("contact-b", "同名联系人")

            with self.assertRaises(ValueError):
                store.contact_for_name("同名联系人")

            draft_a = service.process(incoming("evt-a", "contact-a", "A 的消息"))
            draft_b = service.process(incoming("evt-b", "contact-b", "B 的消息"))

            stored_a = store.get_draft(str(draft_a))
            stored_b = store.get_draft(str(draft_b))
            self.assertEqual(stored_a["contact_key"], "contact-a")
            self.assertEqual(stored_b["contact_key"], "contact-b")
            self.assertEqual(stored_a["status"], "pending")
            self.assertEqual(stored_b["status"], "pending")
            self.assertEqual(
                [item["content"] for item in store.recent_context("contact-a")],
                ["A 的消息"],
            )
            self.assertEqual(
                [item["content"] for item in store.recent_context("contact-b")],
                ["B 的消息"],
            )

    def test_high_risk_user_edit_cannot_be_approved(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, adapter = service_for(Path(directory))
            draft_id = service.process(incoming("evt-safe", "contact-1", "最近怎么样"))

            with self.assertRaises(ValueError):
                service.approve(str(draft_id), ["我同意签署合同并立即付款"])

            draft = store.get_draft(str(draft_id))
            self.assertEqual(draft["status"], "pending")
            self.assertEqual(draft["send_attempts"], [])
            self.assertEqual(adapter.sent, [])

    def test_second_segment_failure_records_partial_sent_and_never_retries(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            adapter = FailOnSecondSendAdapter()
            service, store, _ = service_for(Path(directory), adapter=adapter)
            draft_id = service.process(incoming("evt-two-part", "contact-1", "分两段回复"))

            draft = service.approve(str(draft_id), ["第一段", "第二段"])

            self.assertEqual(draft["status"], "partial_sent")
            self.assertEqual(
                [attempt["status"] for attempt in draft["send_attempts"]],
                ["confirmed", "uncertain"],
            )
            self.assertEqual([item["text"] for item in adapter.sent], ["第一段"])
            self.assertEqual(
                [item["content"] for item in store.recent_context("contact-1")],
                ["分两段回复", "第一段"],
            )

    def test_explicit_pre_send_block_is_not_recorded_as_uncertain(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            adapter = PreSendBlockedAdapter()
            service, _, _ = service_for(Path(directory), adapter=adapter)
            draft_id = service.process(incoming("evt-pre-block", "contact-1", "你好"))

            draft = service.approve(str(draft_id), ["这一条不会调用外部发送"])

            self.assertEqual(draft["status"], "send_blocked")
            self.assertEqual(
                [attempt["status"] for attempt in draft["send_attempts"]],
                ["blocked"],
            )

    def test_recovery_quarantines_approved_sending_and_attempting(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service, store, _ = service_for(Path(directory))

            approved_id = service.process(
                incoming("evt-approved", "contact-approved", "待恢复一")
            )
            sending_id = service.process(
                incoming("evt-sending", "contact-sending", "待恢复二")
            )
            self.assertTrue(
                store.transition_draft(str(approved_id), ("pending",), "approved")
            )
            self.assertTrue(
                store.transition_draft(str(sending_id), ("pending",), "sending")
            )
            sending = store.get_draft(str(sending_id))
            store.prepare_send_attempts(
                str(sending_id), str(sending["send_key"]), ["正在发送"]
            )
            self.assertTrue(
                store.transition_send_attempt(
                    str(sending_id), 0, "prepared", "attempting"
                )
            )

            recovered = store.recover_incomplete()

            self.assertEqual(recovered["drafts"], 2)
            self.assertEqual(recovered["send_attempts"], 1)
            self.assertEqual(store.get_draft(str(approved_id))["status"], "uncertain")
            recovered_sending = store.get_draft(str(sending_id))
            self.assertEqual(recovered_sending["status"], "uncertain")
            self.assertEqual(
                [attempt["status"] for attempt in recovered_sending["send_attempts"]],
                ["uncertain"],
            )

    def test_pending_relationship_never_retrieves_scoped_or_unconfirmed_sheets(self) -> None:
        items = [
            ProfileItem("02 核心人格与价值", 1, ["共同关键词", "全局规则"]),
            ProfileItem("08 工作沟通代理", 1, ["共同关键词", "工作私有"]),
            ProfileItem("09 朋友与日常聊天", 1, ["共同关键词", "朋友私有"]),
            ProfileItem("10 亲密关系代理", 1, ["共同关键词", "亲密私有"]),
            ProfileItem("11 交易与陌生人代理", 1, ["共同关键词", "交易私有"]),
            ProfileItem("15 待确认问题", 1, ["共同关键词", "未经确认"]),
        ]
        selected = ProfileRetriever(items).search(
            "共同关键词", relationship="待确认", limit=20
        )

        self.assertTrue(any(item.sheet.startswith("02") for item in selected))
        self.assertFalse(
            any(item.sheet.startswith(("08", "09", "10", "11", "15")) for item in selected)
        )


if __name__ == "__main__":
    unittest.main()
