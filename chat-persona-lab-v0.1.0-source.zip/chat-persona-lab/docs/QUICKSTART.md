# 快速上手

## 离线演示

1. 安装 Python 3.11 或以上版本，终端运行 `python --version` 确认。
2. 下载并解压源码，用终端进入包含 `README.md` 的项目目录。
3. 运行 `python scripts/create_demo.py`，生成虚构人格档案及本地 `.env`。
4. 运行 `python -m persona_agent --analyze-only`。应解析两份聊天、12 条消息。
5. 运行 `python -m persona_agent --offline-fake-model`，保持终端开启。
6. 打开 http://127.0.0.1:8765，在测试来信区选择虚构朋友，输入“早上好”。
7. 生成后检查草稿，尝试编辑、确认和拒绝；确认默认只记录状态。

离线模式不调用云端模型。网页中的模型名称或固定回复不代表真实模型已完成连接。退出时在启动终端按 `Ctrl+C`。

Windows 双击入口要求 `python` 可在 PATH 中找到。如果安装了虚拟环境，请先激活环境后运行命令。本项目不依赖任何特定 AI 桌面应用的内置 Python。

## 导入真实资料

先停止服务，把档案和符合格式的聊天文本放进本地 `private/`，修改 `.env`：

```dotenv
PROFILE_XLSX_PATH=private/profile.xlsx
CHAT_EXPORT_DIR=private/chats
CHAT_EXPORT_FILES=
```

重新运行分析命令核对会话、本人账号和消息数量，再启动离线页面检查联系人。导入会保存聊天原文到 SQLite；过滤示例并不等于删除原文。更换资料时建议使用新的 `DATA_DIR`，避免混用历史索引。

## JSONL 收件测试

在页面为对应联系人打开自动读取，将 `examples/inbox.example.jsonl` 中的一行追加到 `data/inbox.jsonl`。一行一个 JSON 对象，末尾必须换行。每条真实上游事件应提供稳定、唯一的 `external_id`。

如果仅想测试 outbox，在 `CHAT_ADAPTER=jsonl` 时临时设置 `SEND_ENABLED=true`，重启后逐条确认。结果为 `outbox_written`，只写本地文件；测试完恢复 `false`。云端开关与发送开关互相独立。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 找不到人格档案 | 先执行演示生成器，或检查 `PROFILE_XLSX_PATH` |
| 分析退出码 2 | 没有配置聊天文件、目录未匹配到文件，或文件不存在 |
| 导出缺少本人账号/会话 | 对照数据格式补充头部，不要随意猜测本人身份 |
| 缺少 API Key / 云端未授权 | 演示使用 `--offline-fake-model`；云端使用需自行配置 |
| 端口被占用 | 停止旧进程，或将 `APP_PORT` 改为其他本地端口 |
| 网页提示令牌无效 | 刷新页面；每次重启服务会轮换本地令牌 |
| 草稿需人工处理 | 可能触发风险规则或信息不足，直接手动回复，不强行绕过 |
| 微信适配器不可用 | 核查 Windows、第三方版本、授权、账号和备注名绑定 |

环境变量优先于 `.env`。如果修改配置没有生效，检查启动终端是否仍设置了同名环境变量。默认路径相对项目工作目录，建议始终在项目根目录启动；使用 `--project-root` 指向其他目录时优先填写绝对资料路径。
