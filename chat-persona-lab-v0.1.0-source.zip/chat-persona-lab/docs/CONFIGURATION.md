# 配置参考

`.env` 只在本地使用，复制自 `.env.example`。进程环境变量优先。路径相对启动工作目录；可使用绝对路径。没有填写 API Key 时仍可运行离线分析和固定模型演示。

| 配置项 | 默认 / 用途 |
| --- | --- |
| `PROFILE_XLSX_PATH` | 演示模板指向 `examples/profile.xlsx`，核心缺省为 `profile.xlsx` |
| `CHAT_EXPORT_DIR` | 扫描该目录下的 `*_messages.txt` |
| `CHAT_EXPORT_FILES` | 用分号分隔具体文件；有值时优先于目录 |
| `DATA_DIR` / `DB_PATH` | 默认 `data/` 与其中的 SQLite 文件 |
| `INBOX_PATH` / `OUTBOX_PATH` | 默认 `data/inbox.jsonl` / `data/outbox.jsonl` |
| `APP_HOST` / `APP_PORT` | `127.0.0.1` / `8765`；只支持回环地址 |
| `CHAT_ADAPTER` | `jsonl`；另有 `mock` 与三个实验性微信模式 |
| `SEND_ENABLED` | `false`，发送与云端处理分别授权 |
| `ALLOW_CLOUD_PROCESSING` | `false`，生成时是否允许向云端发送选定资料 |
| `PRIVATE_TERMS` | 逗号分隔的私人词语，模型请求中尽力替换 |
| `CONTACT_WHITELIST` | 逗号分隔的精确微信唯一备注名；免费轮询仅一位 |
| `API_CONTEXT_CHAR_BUDGET` | `18000`，允许范围 `8000–60000` 字符 |
| `DEBOUNCE_SECONDS` | `2.5`，允许范围 `0–30`；不会合并独立来信 |

## 模型供应商

DeepSeek 官方配置：

```dotenv
MODEL_PROVIDER=deepseek_official
DEEPSEEK_API_KEY=在本地填写
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-flash
ALLOW_CLOUD_PROCESSING=true
```

OpenCode Go 配置：

```dotenv
MODEL_PROVIDER=opencode_go
OPENCODE_GO_API_KEY=在本地填写
CLOUD_PROVIDER_ACK=opencode_go
DEEPSEEK_MODEL=deepseek-v4-flash
ALLOW_CLOUD_PROCESSING=true
```

Go 请求使用固定 `https://opencode.ai/zen/go/v1` 基址，不复用官方密钥。当前代码允许两种模型 ID：`deepseek-v4-flash`、`deepseek-v4-pro`；不要加客户端供应商前缀。供应商当时是否支持、账户是否有权限，需自行核查。可在页面中切换的模型仅影响后续新请求。

`DEEPSEEK_JSON_MODE=true`、`DEEPSEEK_TEMPERATURE=0.55`、`DEEPSEEK_MAX_TOKENS=700` 控制请求参数。`ALLOW_CUSTOM_MODEL_ENDPOINT` 是显式开发逃生口，不等于通用模型兼容承诺，也不会取消模型 ID 白名单。

云端隐私和 API 信息应向对应供应商核实；本仓库不保存实际密钥，也不宣称任何供应商永久零保留。

## 微信参数

账号昵称、白名单、测试模式、验收开关、发送目标 ID、专用解锁短语及精确依赖版本详见 [WECHAT](WECHAT.md)。所有账号和目标由使用者本地配置，项目没有预置真实账号。默认空值会阻止误用真实发送。
