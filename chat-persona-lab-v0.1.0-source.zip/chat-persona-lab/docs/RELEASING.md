# 发布与公开检查

本仓库从独立清理后的源代码开始，不继承私人项目的 Git 历史。发布内容只包含程序、虚构文本示例、测试、配置模板、文档和维护脚本。

## 开发者发布步骤

1. 审阅变更，确认例子是虚构的；`.env`、真实聊天、XLSX、数据库、运行日志和截图不进入暂存区。
2. 执行 `python -m unittest discover -s tests -v` 和 `python scripts/smoke_test.py`。
3. 在独立仓库暂存已审核源文件，运行 `python scripts/check_public.py`。
4. 运行 `python scripts/build_release.py`，在 `dist/` 获取源码 ZIP、源文件哈希清单与 SHA256SUMS。
5. 解压到新的空目录，重新运行演示生成、分析和离线服务，再上传该 ZIP 或推送已审查提交。

已有独立 `.git` 时，检查和打包读取 `git ls-files` 列出的文件，再校验允许的目录、扩展名、敏感路径和常见凭据模式。未建立 Git 仓库时使用同样的允许清单选择源文件。打包会读取工作树中相应文件的当前内容，因此正式发布前必须确认工作树与提交一致。

脚本不会整目录打包，不会带上 `.git` 历史、`.env`、`data/`、`private/`、生成的 XLSX、虚拟环境或缓存。源码白名单不等于隐私保证：真实消息若被手工写进允许的 Python/Markdown 文件仍可能漏过，必须人工审查。检查器不代替专业密钥扫描。

## 仓库介绍建议

**名称：** `chat-persona-lab`

**简介：** Local-first chat analysis, communication-style memory, and human-reviewed reply drafts. 本地聊天分析、个人表达风格记忆与人工审阅回复草稿。

**主题：** `chat-analysis`, `persona`, `python`, `privacy`, `wechat`, `human-in-the-loop`, `reply-assistant`

**首次提交：** `Initial public release: Chat Persona Lab v0.1.0`

遵循 [MIT License](../LICENSE)；单独安装的第三方软件仍按各自许可使用。不要把真实账号的成功演示或隐私样本数量作为公开版本的普遍能力声明。
