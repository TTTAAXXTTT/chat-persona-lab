# 实验性微信桌面适配器

核心分析、JSONL 和网页无需微信。以下功能依赖 Windows、独立安装的第三方自动化包及兼容的已登录客户端。当前公开版没有在新的账号/客户端上完成真实收发验收；自动化测试使用替身，不能代表实机成功。

## 三种模式

| `CHAT_ADAPTER` | 用途 / 限制 |
| --- | --- |
| `wxauto4_polling` | 免费轮询；只允许一个精确备注名的一对一联系人 |
| `wxautox4` | 可选 Plus 适配器；使用者自行取得所需授权，不保证后台或全量监听 |
| `wxauto4_global_readonly` | 实验性全局只读；按可靠未读标记切换会话，未知身份隔离 |

可选依赖使用 `python -m pip install -r requirements-live.txt`；精确版本与配置中的版本检查需一致。项目不分发微信客户端，不提供降级安装器，也不承诺客户端兼容范围。

## 先只读

先在离线页面中导入/建立联系人，填入精确且唯一的微信备注名，并开启该联系人的自动读取。停止服务，在本地 `.env` 配置：

```dotenv
CHAT_ADAPTER=wxauto4_polling
CONTACT_WHITELIST=自己专用测试联系人的唯一备注名
WX_ACCOUNT_NICKNAME=自己测试账号的精确昵称
SEND_ENABLED=false
```

先验证账号、联系人身份、连续消息、同文消息、窗口变化、重启回放及失效处理。昵称逐字符比对；适配器能取得账号稳定 ID 时会核对会话内账号漂移。免费接口无法提供收件人的稳定平台 ID，不能把备注名当作完全可靠身份。

可加 `--offline-fake-model` 验证读取与草稿流程，避免测试时调用云端。即使不发送，桌面读取也可能激活和切换微信窗口。

## 真实发送的额外条件

只在专用测试账号/设备和明确目标完成验收后，在本地配置：

```dotenv
SEND_ENABLED=true
WX_TEST_ACCOUNT_MODE=true
WX_LIVE_VALIDATED=true
WX_LIVE_UNLOCK=ENABLE_REAL_WECHAT_SEND
WX_SEND_CONTACT_KEY=本地页面对应的精确联系人键
WX_POLLING_SEND_UNLOCK=ENABLE_WXAUTO4_SEND_TO_CONFIGURED_CONTACT
```

其中后两项用于免费单联系人适配器。解锁短语是主动启用提示，不是密码或认证凭据。项目没有预置可发送的真实账号；`WX_SEND_CONTACT_KEY` 必须与数据库中的白名单联系人绑定一致。

启动后页面的真实发送开关仍关闭。手动开启后，每张来自真实适配器的草稿仍需审阅，并准确输入目标备注名；手工模拟来信不能直接转为真实外发。错误账号、会话、绑定或停用目标会阻断。发送结果不确定时必须人工核对，不要自动重试。

## 全局只读

必须使用专用 Windows 虚拟机或副机，清零可见可计数的未读，再启动。该模式会抢占微信前台并切换会话。它不是官方消息事件接口，不支持可靠处理免打扰会话，可能漏读。

```dotenv
CHAT_ADAPTER=wxauto4_global_readonly
CONTACT_WHITELIST=
WX_ACCOUNT_NICKNAME=自己专用测试账号的精确昵称
SEND_ENABLED=false
WX_GLOBAL_PARKING_CHAT=文件传输助手
```

推荐通过专用入口启动，它会要求确认专用设备与清零未读，并在数据库存在时先创建一致性备份；备份失败会停止：

```sh
python -m persona_agent.global_launcher --offline-fake-model
```

入口在当前进程中强制清空发送权限及白名单，不改写 `.env`。也可单独运行 `python -m persona_agent.db_backup .` 创建一致性备份。新发现身份先进入隔离区；绑定只影响后续来信，旧隔离消息必须逐条释放。每次重启轮换 UI 身份代次，不能静默复用旧绑定。中断缓存会辅助恢复，但微信 UI 在读取计数和清零之间的竞争窗口仍可能丢消息，不能承诺 exactly-once。

第三方桌面自动化不是官方个人聊天 API。客户端变化、系统锁屏、窗口切换、许可失效均可能使功能停止或误判。日常主账号或无人监管生产场景不属于本版本的实机验证范围。
