@echo off
cd /d "%~dp0"
python -X utf8 -m persona_agent
if errorlevel 1 pause
