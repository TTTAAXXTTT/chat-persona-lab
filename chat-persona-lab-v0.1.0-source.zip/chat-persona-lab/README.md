# 聊语实验室 · Chat Persona Lab

**从聊天记录了解自己的表达习惯，用自己的风格写出可以亲自审阅的回复草稿。**

一个以本地处理为起点的 Python 项目：导入聊天文本与结构化人格档案，建立按联系人隔离的历史索引，统计本人消息的表达风格，再根据当前对话生成候选回复。你可以先完全离线体验，再自行配置云端模型。

[English](README.en.md) · [快速上手](docs/QUICKSTART.md) · [数据格式](docs/DATA_FORMAT.md) · [配置说明](docs/CONFIGURATION.md) · [隐私说明](docs/PRIVACY.md) · [开发说明](docs/ARCHITECTURE.md)

**当前版本：0.1.0 / 实验阶段。** 仓库只提供代码和虚构示例。离线演示使用固定测试模型，只验证流程，不代表真实 AI 的回复质量。默认不联网生成、不控制微信、不发送消息。

## 可以做什么

| 功能 | 当前实现 |
| --- | --- |
| 聊天导入 | 解析约定格式的 UTF-8 文本，保留时间、说话方、会话与来源信息 |
| 人格档案 | 本地读取 XLSX 工作表，按用途、关系类型与确认状态选取条目 |
| 聊天分析 | 输出消息数量、本人/对方占比、示例对数量、时间范围及风格统计 |
| 风格记忆 | 根据本人历史消息统计长度、标点、节奏和经过筛选的常用表达 |
| 联系人隔离 | 回复示例和会话上下文按联系人选择；关系类型由本人标注 |
| 草稿工作台 | 本地中文网页：输入测试来信、修改草稿、确认或拒绝、查看状态 |
| 云端生成 | 可选 DeepSeek 官方或 OpenCode Go，需自行提供密钥并明确启用 |
| 本地适配器 | JSONL inbox/outbox；确认写入文件可用于集成测试 |
| 微信实验适配器 | 可选 Windows 桌面自动化；单联系人读取、受控发送、全局只读隔离 |

这套实现不包含微信数据库解密、自动提取历史聊天、语音识别或模型训练。聊天分析是统计与检索；人格档案需要自己填写，系统不会把推测自动当作个人事实。

## 三步体验

安装 **Python 3.11+**，下载源码并进入项目根目录。核心功能只使用 Python 标准库，无需安装第三方运行依赖。

```sh
python scripts/create_demo.py
python -m persona_agent --analyze-only
python -m persona_agent --offline-fake-model
```

打开 **http://127.0.0.1:8765**，选择虚构联系人，输入“早上好”，生成草稿后尝试修改、确认或拒绝。默认确认结果为 `approved_not_sent`，不会向微信发送。

Windows 也可在生成演示资料后双击 `run-offline.cmd`；`analyze.cmd` 输出分析，`run.cmd` 使用配置的云端模型。退出服务按 `Ctrl+C`。

`create_demo.py` 会生成虚构 XLSX，并在 `.env` 不存在时复制配置模板；不会覆盖已有配置或档案。更详细的步骤与常见问题见[快速上手](docs/QUICKSTART.md)。

## 工作流程

```mermaid
flowchart LR
    A[聊天文本与人格档案] --> B[本地解析与 SQLite 索引]
    B --> C[本人风格统计]
    B --> D[当前联系人上下文与示例]
    E[新来信] --> F[风险检查与检索]
    C --> F
    D --> F
    F --> G[离线测试模型 / 可选云端模型]
    G --> H[人工审阅与编辑]
    H --> I[确认 / 拒绝]
    I --> J[默认只记录审批结果]
```

每条来信独立排队，同一联系人连续消息不会覆盖已有待审草稿。生成结果最多三条消息；短回复会合并以减少碎片化。高风险内容转为人工处理。遇到可能已经发送的结果，不会自动重试。

## 使用自己的资料

1. 把自己的聊天导出和人格档案放在被忽略的 `private/` 目录或仓库外。
2. 修改本地 `.env` 中的 `PROFILE_XLSX_PATH`、`CHAT_EXPORT_DIR` 或 `CHAT_EXPORT_FILES`。
3. 先运行 `--analyze-only` 检查解析数量；目录导入只识别 `*_messages.txt`。
4. 在页面中标注联系人关系、核对绑定；接入云端前阅读[隐私说明](docs/PRIVACY.md)。

聊天导出必须匹配[约定格式](docs/DATA_FORMAT.md)。本项目不会直接解析任意聊天应用的原生数据库。XLSX、聊天导出和 SQLite 中可能保存原始隐私内容，请自己管理访问权限。

## 可选：云端草稿

在本地 `.env` 配置：

```dotenv
MODEL_PROVIDER=deepseek_official
DEEPSEEK_API_KEY=替换为自己在本地填写的密钥
ALLOW_CLOUD_PROCESSING=true
```

然后运行 `python -m persona_agent`。当前代码允许的模型 ID 为 `deepseek-v4-flash`、`deepseek-v4-pro`；是否有调用权限，以供应商实际返回为准。另一供应商的设置见[配置说明](docs/CONFIGURATION.md)。

云端开启后，选中的当前消息、相关人格条目、当前联系人的上下文与示例、风格统计可能会发送给所选供应商。正则过滤只是尽力处理，不能保证匿名化。项目不承诺供应商的数据保留、训练政策或价格。

## 项目结构

```text
persona_agent/       Python 核心、适配器、本地 HTTP 服务
  web/index.html    中文草稿工作台
examples/           虚构聊天、JSONL 输入；XLSX 由脚本生成
scripts/            演示生成、HTTP 冒烟测试、公开检查、发布打包
tests/              自动化回归测试（微信使用测试替身）
docs/               上手、格式、配置、架构、隐私与发布文档
.github/            CI 与 issue / PR 模板
.env.example        空密钥、安全默认值的配置模板
```

## 开发与验证

```sh
python -m unittest discover -s tests -v
python scripts/check_public.py
python scripts/smoke_test.py
python scripts/build_release.py
```

CI 配置覆盖 Windows / Linux、Python 3.11 / 3.13。实际测试结果以对应提交的运行记录为准。真实微信和在线供应商不在自动化测试覆盖范围内。可选打包安装：`python -m pip install .`，之后在资料工作目录运行 `chat-persona-lab --project-root .`。

## 使用边界与后续方向

本地界面只绑定回环地址，数据默认明文存储。请勿开放到公网。真实微信接入依赖第三方桌面自动化，受客户端、窗口状态和授权条件影响；[微信适配说明](docs/WECHAT.md)列出了限制，不能视为跨版本已验证的生产方案。

后续方向包括更多导出格式、分析报告可视化、通用模型接口、加密存储和更完整的平台验证。这些是规划，未作为本版已完成能力宣传。

欢迎使用虚构数据提交问题和改进。阅读 [CONTRIBUTING](CONTRIBUTING.md)、[SECURITY](SECURITY.md) 与[第三方说明](NOTICE.md)。本项目采用 [MIT License](LICENSE)。
