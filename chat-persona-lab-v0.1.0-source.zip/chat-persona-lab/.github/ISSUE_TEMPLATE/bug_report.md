---
name: Bug report
about: Report a reproducible problem using fictional data
title: ''
labels: bug
assignees: ''
---

## What happened?

## Steps to reproduce with fictional data

## Expected behavior

## Environment

- Operating system:
- Python version:
- Application version / commit:
- Adapter mode:

Before posting, remove keys, personal names, account IDs, local paths, and chat
content. Do not upload `.env` or a database.
