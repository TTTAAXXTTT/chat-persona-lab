## Behavior changed

## Validation

## Privacy / recipient-isolation impact

- [ ] Examples and test fixtures are fictional.
- [ ] No credentials, private files, or real chat excerpts are included.
