"""Generate a fictional XLSX fixture using only the Python standard library."""
from pathlib import Path
from xml.sax.saxutils import escape
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SHEETS = [
    ('00 使用说明', [('模块', '内容'), ('示例性质', '所有资料均为虚构，仅用于演示。')]),
    ('01 身份边界', [('字段', '内容', '披露策略'), ('个人身份', '虚构演示者', '仅供本人')]),
    ('02 表达原则', [('原则', '内容'), ('诚实', '不知道的事情直接说明，不编造事实。')]),
    ('03 沟通目标', [('维度', '内容'), ('目标', '先回应对方的问题，再补充必要信息。')]),
    ('04 语言风格', [('维度', '内容'), ('整体风格', '自然、简洁，一次表达一个完整意思。')]),
    ('05 决策习惯', [('原则', '内容'), ('安排确认', '未确认的时间只作为建议。')]),
    ('06 当前状态', [('状态', '内容'), ('示例状态', '没有真实行程信息。')]),
    ('07 情绪表达', [('维度', '内容'), ('表达', '保持温和，不替对方判断情绪。')]),
    ('08 工作沟通', [('原则', '内容'), ('进度', '只汇报已有证据的进度。')]),
    ('09 朋友日常', [('原则', '内容'), ('约定', '先确认时间，不随意替别人承诺。')]),
    ('10 亲密沟通', [('原则', '内容'), ('边界', '不根据历史对话假设当前关系状态。')]),
    ('11 陌生交流', [('原则', '内容'), ('隐私', '不主动分享私人身份信息。')]),
    ('12 风格锚点', [('维度', '内容'), ('长度', '简单确认用一条短消息。')]),
    ('13 回复边界', [('原则', '内容'), ('承诺', '不编造金额、地点或承诺。')]),
    ('14 本地策略', [('原则', '内容'), ('本地策略', '此表不进入模型上下文。')]),
    ('15 待确认问题', [('字段', '回答', '状态'), ('偏好称呼', '暂未提供', '待确认')]),
]


def create_workbook(path: Path) -> None:
    ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    rel = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    pkg = 'http://schemas.openxmlformats.org/package/2006/relationships'
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        overrides = ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(SHEETS)+1))
        z.writestr('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+overrides+'</Types>')
        z.writestr('_rels/.rels', f'<Relationships xmlns="{pkg}"><Relationship Id="rId1" Type="{rel}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', f'<workbook xmlns="{ns}" xmlns:r="{rel}"><sheets>'+''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_) in enumerate(SHEETS,1))+'</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', f'<Relationships xmlns="{pkg}">'+''.join(f'<Relationship Id="rId{i}" Type="{rel}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(SHEETS)+1))+'</Relationships>')
        for i,(_,rows) in enumerate(SHEETS,1):
            body = ''.join(f'<row r="{r}">'+''.join(f'<c r="{chr(65+c)}{r}" t="inlineStr"><is><t>{escape(value)}</t></is></c>' for c,value in enumerate(row))+'</row>' for r,row in enumerate(rows,1))
            z.writestr(f'xl/worksheets/sheet{i}.xml', f'<worksheet xmlns="{ns}"><sheetData>{body}</sheetData></worksheet>')


def main() -> None:
    profile = ROOT / 'examples/profile.xlsx'
    if not profile.exists():
        create_workbook(profile)
    if not (ROOT / '.env').exists():
        shutil.copyfile(ROOT / '.env.example', ROOT / '.env')
    print('Fictional demo prepared. Existing profile and .env files were preserved.')
    print('Analyze: python -m persona_agent --analyze-only')
    print('Offline UI: python -m persona_agent --offline-fake-model')


if __name__ == '__main__':
    main()
