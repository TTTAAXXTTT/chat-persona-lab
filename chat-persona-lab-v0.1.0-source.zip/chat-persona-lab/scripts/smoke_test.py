"""Exercise startup, CSRF, a fictional draft, and approval over real local HTTP."""
from pathlib import Path
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        shutil.copytree(ROOT / 'examples', root / 'examples', ignore=shutil.ignore_patterns('*.xlsx'))
        sys.path.insert(0, str(ROOT / 'scripts'))
        from create_demo import create_workbook
        create_workbook(root / 'examples/profile.xlsx')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        (root / '.env').write_text(f'PROFILE_XLSX_PATH={root / "examples/profile.xlsx"}\nCHAT_EXPORT_DIR={root / "examples/chats"}\nAPP_PORT={port}\nCHAT_ADAPTER=jsonl\nSEND_ENABLED=false\nALLOW_CLOUD_PROCESSING=false\n', encoding='utf-8')
        env = {k:v for k,v in os.environ.items() if k not in {'DATA_DIR','DB_PATH','PROFILE_XLSX_PATH','CHAT_EXPORT_DIR','CHAT_EXPORT_FILES','APP_PORT','APP_HOST','CHAT_ADAPTER','SEND_ENABLED','ALLOW_CLOUD_PROCESSING','INBOX_PATH','OUTBOX_PATH'}}
        process = subprocess.Popen([sys.executable,'-m','persona_agent','--project-root',str(root),'--offline-fake-model'], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        base = f'http://127.0.0.1:{port}'
        try:
            deadline = time.monotonic()+15
            while True:
                try:
                    page = urllib.request.urlopen(base, timeout=1).read().decode()
                    break
                except (OSError, urllib.error.URLError):
                    if process.poll() is not None or time.monotonic()>deadline:
                        raise RuntimeError('Offline server did not start')
                    time.sleep(.1)
            token = re.search(r"const csrfToken = '([^']+)'", page)
            if token is None:
                raise AssertionError('CSRF token was not rendered')
            headers = {'X-Local-CSRF':token.group(1),'Content-Type':'application/json','Origin':base}

            def request(path, payload=None):
                req = urllib.request.Request(base+path, data=None if payload is None else json.dumps(payload).encode(),headers=headers)
                with urllib.request.urlopen(req, timeout=3) as response:
                    return json.load(response)

            try:
                urllib.request.urlopen(base+'/api/state', timeout=2)
                raise AssertionError('Missing CSRF token was accepted')
            except urllib.error.HTTPError as e:
                assert e.code == 403
            deadline = time.monotonic()+10
            while request('/api/state')['state']['service']['status'] != 'running':
                if time.monotonic()>deadline:
                    raise AssertionError('Service was not ready')
                time.sleep(.1)
            request('/api/incoming',{'contact_key':'demo_friend','contact_name':'虚构朋友甲','text':'早上好'})
            deadline = time.monotonic()+10
            while True:
                drafts = request('/api/drafts')['drafts']
                if drafts:
                    break
                if time.monotonic()>deadline:
                    raise AssertionError('No draft produced')
                time.sleep(.1)
            draft = drafts[0]
            result = request('/api/drafts/'+draft['id']+'/approve',{'messages':['早呀']})
            assert result['draft']['status'] == 'approved_not_sent'
            assert not (root/'data/outbox.jsonl').exists()
            print('HTTP smoke passed: startup, CSRF rejection, fictional draft, approval without sending.')
        finally:
            process.terminate()
            process.wait(timeout=10)


if __name__ == '__main__':
    main()
