"""Build a checked source ZIP from curated tracked files, never from all files."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

from check_public import ROOT, check, source_paths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'dist')
    args = parser.parse_args()
    paths = source_paths()
    errors = check(paths)
    if errors:
        raise SystemExit('\n'.join(errors))
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = output / 'chat-persona-lab-v0.1.0-source.zip'
    manifest = []
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in paths:
            data = (ROOT / rel).read_bytes()
            z.writestr('chat-persona-lab/' + rel, data)
            manifest.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or len(z.namelist()) != len(paths):
            raise RuntimeError('Archive verification failed')
    (output / 'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output / 'SHA256SUMS.txt').write_text(f'{digest}  {archive.name}\n', encoding='utf-8')
    print(f'Built and verified {archive.name}: {len(paths)} files; SHA256 {digest}')


if __name__ == '__main__':
    main()
