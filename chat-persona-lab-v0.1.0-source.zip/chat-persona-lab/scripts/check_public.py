"""Check only publishable source paths; never print matched secret values."""
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
TOP_FILES = {'.gitignore', '.gitattributes', '.env.example', 'README.md', 'README.en.md',
             'LICENSE', 'NOTICE.md', 'CONTRIBUTING.md', 'SECURITY.md', 'CHANGELOG.md',
             'pyproject.toml', 'requirements.txt', 'requirements-live.txt',
             'run.cmd', 'run-offline.cmd', 'analyze.cmd'}
FOLDERS = {'persona_agent', 'tests', 'docs', 'scripts', '.github', 'examples'}
EXTENSIONS = {'.py', '.html', '.md', '.yml', '.yaml', '.txt', '.json', '.jsonl', '.toml', '.cmd'}
FORBIDDEN_PARTS = {'.env', 'data', 'private', '.analysis', '.venv', '__pycache__', 'wxauto_logs'}
SECRET_PATTERNS = [
    ('provider token', re.compile(r'\b(?:sk-[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b')),
    ('private key', re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
    ('absolute user path', re.compile(r'(?:[A-Za-z]:[\\/](?:Users|OneDrive)[\\/]|/' + r'Users/|/' + r'home/)[^\s"\']+', re.I)),
    ('personal email', re.compile(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}')),
]


def publishable(rel: str) -> bool:
    p = PurePosixPath(rel)
    if any(part in FORBIDDEN_PARTS for part in p.parts):
        return False
    if p.name.startswith('.env') and rel != '.env.example':
        return False
    if len(p.parts) == 1:
        return rel in TOP_FILES
    if p.parts[0] not in FOLDERS or p.suffix not in EXTENSIONS:
        return False
    if p.parts[0] == 'examples':
        return rel in {'examples/chats/demo_friend_messages.txt', 'examples/chats/demo_colleague_messages.txt', 'examples/inbox.example.jsonl'}
    return True


def source_paths() -> list[str]:
    # Git is used only if ROOT itself is the repository root, never its parent.
    if (ROOT / '.git').exists():
        result = subprocess.run(['git', '-C', str(ROOT), 'ls-files', '-z'], capture_output=True, check=True)
        return sorted(p for p in result.stdout.decode('utf-8').split('\0') if p)
    return sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and publishable(p.relative_to(ROOT).as_posix()))


def check(paths: list[str]) -> list[str]:
    errors = []
    if not paths:
        return ['No source files selected. Stage the reviewed source before release.']
    for rel in paths:
        p = ROOT / rel
        if not publishable(rel) or p.is_symlink() or not p.is_file():
            errors.append(f'{rel}: forbidden or missing source path')
            continue
        try:
            content = p.read_text(encoding='utf-8-sig')
        except (UnicodeError, OSError):
            errors.append(f'{rel}: non-text or unreadable content')
            continue
        for label, pattern in SECRET_PATTERNS:
            for m in pattern.finditer(content):
                if label == 'personal email' and m.group().endswith(('@example.com', '@example.org', '@example.test')):
                    continue
                errors.append(f'{rel}:{content.count(chr(10),0,m.start())+1}: possible {label}')
    return errors


def main() -> None:
    paths = source_paths()
    errors = check(paths)
    if errors:
        print('\n'.join(errors))
        raise SystemExit(1)
    print(f'Public source check passed: {len(paths)} text files. Heuristics do not prove anonymity.')


if __name__ == '__main__':
    main()
